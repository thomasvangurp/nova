"""Is a design's score affected by the batch size it was folded at?

Three independent repeats per batch size give a within-condition spread (pure
run-to-run non-determinism, the floor) to compare the between-condition spread
against. If batching were biasing a metric, the batch-4 values would sit
consistently off the batch-1 values by more than the floor.

  bt_stats.py --groups 1:t1_1,t1_2,t1_3 2:t2_1,... --designs A,B,...
"""
from __future__ import annotations
import argparse, glob, os
import numpy as np

ROOT = "/root/fastscore/bt"
KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def best(path):
    d = dict(np.load(path, allow_pickle=True))
    conf = 0.8 * np.asarray(d["design_to_target_iptm"], float) \
         + 0.2 * np.asarray(d["design_ptm"], float)
    i = int(np.argmax(conf))
    return {k: float(np.asarray(d[k], float)[i]) for k in KEYS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--groups", nargs="+", required=True)
    ap.add_argument("--designs", required=True)
    a = ap.parse_args()

    groups = {}
    for g in a.groups:
        label, runs = g.split(":")
        groups[label] = runs.split(",")
    designs = a.designs.split(",")

    vals = {}   # (design, label) -> list of dicts
    for label, runs in groups.items():
        for r in runs:
            for name in designs:
                p = os.path.join(ROOT, r, "fold_out_npz", f"{name}.npz")
                if os.path.exists(p):
                    vals.setdefault((name, label), []).append(best(p))

    labels = list(groups)
    for k in KEYS:
        print(f"\n=== {k} ===")
        print(f"  {'design':8s}" + "".join(f"{'bs=' + l:>26s}" for l in labels)
              + f"{'floor':>10s}{'shift':>10s}")
        floors, shifts = [], []
        for name in designs:
            cells, means, spreads = [], [], []
            for l in labels:
                v = [d[k] for d in vals.get((name, l), [])]
                if not v:
                    cells.append(f"{'-':>26s}")
                    continue
                means.append(np.mean(v))
                spreads.append(max(v) - min(v))
                cells.append(f"{np.mean(v):12.4f} +-{(max(v)-min(v))/2:<11.4f}")
            if not means:
                continue
            floor = max(spreads)            # widest within-condition spread
            shift = max(means) - min(means)  # spread of the condition means
            floors.append(floor); shifts.append(shift)
            print(f"  {name:8s}" + "".join(cells) + f"{floor:10.4f}{shift:10.4f}")
        if floors:
            print(f"  {'WORST':8s}" + " " * (26 * len(labels))
                  + f"{max(floors):10.4f}{max(shifts):10.4f}")

    print("\nfloor = widest spread among 3 repeats at one batch size (non-determinism)")
    print("shift = spread of the per-batch-size means (what batching would bias)")


if __name__ == "__main__":
    main()
