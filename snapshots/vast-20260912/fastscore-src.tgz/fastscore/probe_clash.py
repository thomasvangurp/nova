import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, "/root/fastscore")
from synth_fullatom import CifDoc, read_residues

f = Path(sys.argv[1])
doc = CifDoc(f.read_text())
res = read_residues(doc, f.name)
xyz = np.concatenate([r.coords() for r in res])
owner = np.concatenate([np.full(len(r.names), i) for i, r in enumerate(res)])
lab = [(r.asym, r.seq_id, r.name, a) for r in res for a in r.names]
D = np.linalg.norm(xyz[:, None] - xyz[None], axis=-1)
np.fill_diagonal(D, np.inf)
D = np.where(np.abs(owner[:, None] - owner[None]) > 1, D, np.inf)
ii, jj = np.where(D < 2.2)
seen = set()
for i, j in zip(ii, jj):
    if (j, i) in seen: continue
    seen.add((i, j))
    print(f"{D[i,j]:.3f}  {lab[i]}  <->  {lab[j]}")
