#!/usr/bin/env python3
"""Per-worker duty cycle from in-process phase timings.

nvidia-smi cannot attribute utilisation on a GPU with several tenants, and
this box has several. These numbers come from inside the worker, so the
*structure* of the duty cycle (which phases use the GPU at all) is exact; only
the absolute durations are inflated by whatever else is on the device.
"""
import json, os, sys, glob

GPU_PHASES = {"design_predict", "folding_predict"}
# model load does touch the GPU (weights -> device) but is dominated by
# deserialisation; counted separately.
LOAD_PHASES = {"design_model_load", "folding_model_load"}

for tag in sys.argv[1:]:
    b = f"/root/fastscore/mw/runs/{tag}"
    shards = sorted(glob.glob(os.path.join(b, "shards", "out*.json")),
                    key=lambda p: int(os.path.basename(p)[3:-5]))
    if not shards:
        print(f"{tag}: no shard outputs"); continue
    meta = dict(kv.split("=", 1) for kv in open(os.path.join(b, "meta.txt")).read().split())
    wall = float(meta["wall"])
    print(f"\n=== {tag}  K={meta['K']}  wall={wall:.0f}s  shards={len(shards)} ===")
    allev = []
    tot = {}
    for p in shards:
        d = json.load(open(p))
        t0 = d["t_spawn"]
        ph = d["phases"]
        spawn_import = d["t_imports"] - d["t_spawn"]
        gpu = sum(s for n, _t, s in ph if n in GPU_PHASES)
        load = sum(s for n, _t, s in ph if n in LOAD_PHASES)
        other = sum(s for n, _t, s in ph if n not in GPU_PHASES | LOAD_PHASES)
        life = d["t_end"] - d["t_spawn"]
        acc = {"spawn+imports": spawn_import}
        for n, _t, s in ph:
            acc[n] = acc.get(n, 0.0) + s
        acc["unaccounted"] = life - spawn_import - sum(s for _n, _t, s in ph)
        for k, v in acc.items():
            tot[k] = tot.get(k, 0.0) + v
        print(f" shard{d['shard']}: n={d['n']} life={life:.0f}s "
              f"peak_alloc={d['peak_alloc_MiB']:.0f}MiB "
              f"peak_reserved={d['peak_reserved_MiB']:.0f}MiB")
        print("   " + "  ".join(f"{k}={v:.0f}s" for k, v in acc.items()))
        print(f"   GPU-forward phases = {gpu:.0f}s = {gpu/life*100:.1f}% of worker life"
              f"   (model load {load:.0f}s = {load/life*100:.1f}%)")
        allev.append((t0, ph, d))
    nsh = len(shards)
    print(f" AGGREGATE over {nsh} shard(s), per shard-second:")
    tl = sum(tot.values())
    for k, v in sorted(tot.items(), key=lambda kv: -kv[1]):
        print(f"   {k:20s} {v/nsh:7.1f}s  {v/tl*100:5.1f}%")
    gpu_tot = sum(v for k, v in tot.items() if k in GPU_PHASES)
    print(f"   -> GPU-forward fraction of worker lifetime: {gpu_tot/tl*100:.1f}%")
    print(f"   -> theoretical packing ceiling 1/frac      : {tl/gpu_tot:.2f}x")
