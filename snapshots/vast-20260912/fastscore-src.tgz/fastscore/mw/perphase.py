import json
print(f"{'K':>2} {'fold s/seq':>10} {'design s/seq':>12} {'analysis s/seq':>14} "
      f"{'modelload tot':>13} {'wall':>6} {'seq/min':>8} {'speedup':>8}")
base = None
for t, k in (("k1r1", 1), ("k2r1", 2), ("k3r1", 3)):
    d = json.load(open(f"/root/fastscore/mw/runs/{t}/out.json"))
    ss = d["shard_stats"]; n = sum(s["n"] for s in ss); w = d["wall_seconds"]
    g = lambda key: sum(s["phase_totals"][key] for s in ss)
    ml = g("design_model_load") + g("folding_model_load")
    spm = n / (w / 60)
    if base is None: base = spm
    print(f"{k:>2} {g('folding_predict')/n:>10.1f} {g('design_predict')/n:>12.1f} "
          f"{g('analysis')/n:>14.2f} {ml:>13.0f} {w:>6.0f} {spm:>8.2f} {spm/base:>7.2f}x")
