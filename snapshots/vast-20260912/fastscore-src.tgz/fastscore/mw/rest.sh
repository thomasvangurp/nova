#!/usr/bin/env bash
set -u
cd /root/fastscore/mw
while pgrep -f "run_k.sh 1 k1r1" > /dev/null; do sleep 5; done
echo "=== $(date +%H:%M:%S) starting K=2 tag=k2r1 ==="
./run_k.sh 2 k2r1 /root/fastscore/mw/seqs24.json 1 keep
echo "=== $(date +%H:%M:%S) starting K=3 tag=k3r1 ==="
./run_k.sh 3 k3r1 /root/fastscore/mw/seqs24.json 1 keep
echo "=== ALLDONE $(date +%H:%M:%S) ==="
