#!/usr/bin/env python3
"""Prove shard isolation for a --keep-work-dir run.

Checks, for run <base>:
  1. every shard has its own shard<N>/chunk<M> tree, no shared parent below
     shard_root other than shard_root itself;
  2. the input yamls in each shard are exactly that shard's sequences
     (filename is sha256(seq)), and the input sets are pairwise DISJOINT;
  3. each shard's own aggregate_metrics_analyze.csv contains exactly that
     shard's ids and nothing else -> no shard SAW another shard's designs;
  4. every metric value in the merged out.json for a sequence equals the row in
     the CSV of the shard that OWNED that sequence.  This is the anti-
     contamination test that a plain "all 10 metrics present" check cannot do.
"""
import csv, hashlib, json, os, sys, glob

METRICS = ["design_iiptm","design_ptm","design_to_target_iptm",
           "min_design_to_target_pae","interaction_pae","plip_hbonds_refolded",
           "plip_saltbridge_refolded","delta_sasa_refolded","liability_score",
           "liability_num_violations"]
TARGET = "P20809"

seqs_path, base = sys.argv[1], sys.argv[2]
seqs = json.load(open(seqs_path))
h2s = {hashlib.sha256(s.encode("ascii")).hexdigest(): s for s in seqs}
root = os.path.join(base, "shards")

shard_dirs = sorted(glob.glob(os.path.join(root, "shard*")),
                    key=lambda p: int(os.path.basename(p)[5:]))
print(f"shard_root={root}")
print(f"shard dirs: {[os.path.basename(d) for d in shard_dirs]}")

fail = []
inputs, outputs, rows = {}, {}, {}
for d in shard_dirs:
    sid = int(os.path.basename(d)[5:])
    chunks = sorted(glob.glob(os.path.join(d, "chunk*")))
    yamls, csvrows = set(), {}
    for c in chunks:
        for y in glob.glob(os.path.join(c, "inputs", "*_input.yaml")):
            yamls.add(os.path.basename(y).split("_")[0])
        p = os.path.join(c, "outputs", "intermediate_designs",
                         "aggregate_metrics_analyze.csv")
        if os.path.exists(p):
            for r in csv.DictReader(open(p)):
                csvrows[r["id"].split("_")[0]] = r
    inputs[sid] = yamls; outputs[sid] = set(csvrows); rows[sid] = csvrows
    print(f"  shard{sid}: chunks={[os.path.basename(c) for c in chunks]} "
          f"inputs={len(yamls)} csv_rows={len(csvrows)} "
          f"inputs==csv_ids={yamls==set(csvrows)}")
    if yamls != set(csvrows):
        fail.append(f"shard{sid}: csv ids != input ids "
                    f"(extra in csv: {set(csvrows)-yamls})")

ids = list(inputs)
for i in range(len(ids)):
    for j in range(i+1, len(ids)):
        ov_in = inputs[ids[i]] & inputs[ids[j]]
        ov_out = outputs[ids[i]] & outputs[ids[j]]
        if ov_in: fail.append(f"INPUT OVERLAP shard{ids[i]}/shard{ids[j]}: {ov_in}")
        if ov_out: fail.append(f"OUTPUT OVERLAP shard{ids[i]}/shard{ids[j]}: {ov_out}")
print(f"pairwise input overlap  : {'NONE' if not any('INPUT OVERLAP' in f for f in fail) else 'FOUND'}")
print(f"pairwise output overlap : {'NONE' if not any('OUTPUT OVERLAP' in f for f in fail) else 'FOUND'}")

allin = set().union(*inputs.values()) if inputs else set()
print(f"union of shard inputs == submitted set : {allin == set(h2s)} "
      f"({len(allin)} vs {len(h2s)})")
if allin != set(h2s): fail.append("union of shard inputs != submitted set")

# 4. merged values must come from the owning shard's csv
merged = json.load(open(os.path.join(base, "out.json")))["per_nanobody_components"]
flat = {}
for uid, by in merged.items():
    for s, bt in by.items(): flat[s] = bt[TARGET]
owner = {h: sid for sid, hs in inputs.items() for h in hs}
mismatch, checked = [], 0
for h, s in h2s.items():
    sid = owner.get(h)
    if sid is None: continue
    row = rows[sid].get(h)
    got = flat.get(s)
    if row is None or got is None:
        mismatch.append((h[:8], "missing")); continue
    for m in METRICS:
        if abs(float(row[m]) - float(got[m])) > 1e-6:
            mismatch.append((h[:8], m, row[m], got[m]))
    checked += 1
print(f"merged values traced to owning shard's CSV: {checked}/{len(h2s)} seqs, "
      f"{len(mismatch)} mismatches")
if mismatch: fail.append(f"value mismatches: {mismatch[:5]}")

# cross-shard sanity: would a swap have been detectable?
distinct = len({tuple(round(float(r[m]),5) for m in METRICS)
                for cr in rows.values() for r in cr.values()})
print(f"distinct metric vectors across all shards: {distinct} "
      f"(a silent swap would be detectable: {distinct == sum(len(v) for v in rows.values())})")

print()
if fail:
    print("ISOLATION: FAIL"); [print("  -", f) for f in fail]
else:
    print("ISOLATION: PASS")
