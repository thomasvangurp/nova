#!/usr/bin/env python3
import json, os, sys, glob, csv, hashlib

METRICS = ["design_iiptm","design_ptm","design_to_target_iptm",
           "min_design_to_target_pae","interaction_pae","plip_hbonds_refolded",
           "plip_saltbridge_refolded","delta_sasa_refolded","liability_score",
           "liability_num_violations"]
RUNS = "/root/fastscore/mw/runs"

def gpustats(p):
    us, ms, la, apps = [], [], [], 0
    for line in open(p):
        q = line.split()
        if not q: continue
        if q[0] == "S" and len(q) >= 4:
            try:
                u, m = q[2].split(","); us.append(int(u)); ms.append(int(m))
                la.append(float(q[3].split(",")[0]))
            except Exception: pass
        elif q[0] == "A" and len(q) > 2:
            apps = max(apps, len([x for x in q[2].split(";") if x.strip()]))
    return us, ms, la, apps

rows = []
for tag in sys.argv[1:]:
    b = os.path.join(RUNS, tag)
    meta = dict(kv.split("=", 1) for kv in open(os.path.join(b, "meta.txt")).read().split())
    us, ms, la, apps = gpustats(os.path.join(b, "gpu.log"))
    op = os.path.join(b, "out.json")
    if os.path.exists(op):
        d = json.load(open(op)); n = d["n"]; wall = d["wall_seconds"]
        flat = {s: v for by in d["per_nanobody_components"].values() for s, v in by.items()}
        bad = sum(1 for v in flat.values()
                  if not v.get("P20809") or any(m not in v["P20809"] for m in METRICS))
        got = len(flat)
    else:
        n = wall = 0; got = -1; bad = -1
    busy = sum(us) / 100.0
    rows.append(dict(tag=tag, K=int(meta["K"]), rc=int(meta["rc"]),
                     wall=float(meta["wall"]), n=n, got=got, bad=bad,
                     spm=n / (float(meta["wall"]) / 60) if n else 0,
                     gpu_s_seq=float(meta["wall"]) / n if n else 0,
                     busy_s_seq=busy / n if n else 0,
                     util=sum(us) / len(us) if us else 0,
                     base_mem=ms[0] if ms else 0, peak=max(ms) if ms else 0,
                     la_mean=sum(la)/len(la) if la else 0, la_max=max(la) if la else 0,
                     apps=apps))

hdr = (f"{'tag':7} {'K':>2} {'rc':>3} {'wall_s':>7} {'seq':>4} {'ret':>4} {'bad':>4} "
       f"{'seq/min':>8} {'GPUs/seq':>9} {'busyS/seq':>10} {'util%':>6} "
       f"{'baseMiB':>8} {'peakMiB':>8} {'load':>6} {'loadmx':>7} {'procs':>6}")
print(hdr); print("-" * len(hdr))
for r in rows:
    print(f"{r['tag']:7} {r['K']:>2} {r['rc']:>3} {r['wall']:>7.0f} {r['n']:>4} "
          f"{r['got']:>4} {r['bad']:>4} {r['spm']:>8.2f} {r['gpu_s_seq']:>9.1f} "
          f"{r['busy_s_seq']:>10.1f} {r['util']:>6.1f} {r['base_mem']:>8} "
          f"{r['peak']:>8} {r['la_mean']:>6.1f} {r['la_max']:>7.1f} {r['apps']:>6}")
