"""Drop-in replacement for score_boltzgen_batch.py with resident models.

Same CLI, same output JSON, same scoring path -- the only difference is that
the checkpoints are loaded once per worker instead of once per chunk.

Why
---
`boltzgen execute` runs each pipeline step as its own `python main.py
<step>.yaml` subprocess, and `Predict.run` loads the checkpoint, predicts, then
`del`s the model. Measured on this box: of a 345 s four-sequence chunk, ~176 s
(51%) is process start + checkpoint load, and the live producer runs chunks of
TWO, so it pays ~175 s of loading for ~50 s of work. Folding one design costs
52.9 s as a subprocess step and 11.4 s against a resident model.

What is preserved exactly
-------------------------
* `configure` still runs upstream's `configure_command`, so the per-chunk
  step configs are the ones BoltzGen itself emits -- not hand-written ones that
  could drift.
* The model is built by `Predict.run(cfg, run_prediction=False)`, the same code
  path production uses, with the same weights and the same predict_args.
* Ranking is still deferred: this fills `per_nanobody_components` from the
  analysis CSV exactly as `run_nanobody_inference` does.

What changes
------------
* Models stay resident across chunks within a worker.
* The datamodule, writer and Trainer are rebuilt per chunk (they carry the
  per-chunk paths); only the LightningModule is reused.
* `matmul_precision` for the folding step is configurable. Upstream leaves it
  null, which disables TF32 and puts 45.6% of folding's CUDA time in
  non-tensor-core `ampere_sgemm`. Measured: 44.3 -> 34.4 ms per denoising step,
  with a metric perturbation the same size as rerunning the identical config
  (the scorer is not bit-reproducible even at a fixed seed).
* Thread caps are set. Production sets none, and 43 torch processes x ~71
  threads drive a 128-core box to load 299.

ISOLATION IS STILL LOAD-BEARING, for the same reason as the original: the
wrapper derives its input/output dirs from a module global, so two shards in
one tree would silently read each other's results.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import shutil
import time
from pathlib import Path

# Cap threads BEFORE torch is imported anywhere in this process.
for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "4")


REQUIRED_SUBNET_KEYS = (
    "nanobody_target",
    "nanobody_target_clip_interval",
    "nanobody_structure",
    "nanobody_structure_chain",
    "nanobody_structure_res_index",
    "nanobody_structure_binding_site",
    "boltzgen_rank_by",
    "boltzgen_rank_mode",
)


def _flatten_config(cfg: dict, target: str) -> dict:
    """Flatten upstream config.yaml into the flat keys BoltzgenWrapper reads.

    Identical to score_boltzgen_batch.py: derived from the upstream file rather
    than hand-written, so the epitope and residue range stay tied to upstream.
    """
    nb = (cfg.get("protein_selection") or {}).get("nanobody") or {}
    flat = dict(cfg)
    flat["nanobody_target"] = [target]
    flat["nanobody_target_clip_interval"] = nb.get("clip_interval")
    for k in ("structure", "structure_chain", "structure_res_index",
              "structure_binding_site"):
        if k in nb:
            flat[f"nanobody_{k}"] = nb[k]
    for k, v in (cfg.get("boltzgen_config") or {}).items():
        flat.setdefault(k, v)

    missing = [k for k in REQUIRED_SUBNET_KEYS if flat.get(k) is None]
    if missing:
        raise SystemExit(
            "config.yaml cannot supply these keys BoltzgenWrapper requires: "
            f"{missing}. Check protein_selection.nanobody and boltzgen_config."
        )
    return flat


# --------------------------------------------------------------------------
# worker
# --------------------------------------------------------------------------

def _worker(args):
    (shard_id, gpu, seqs, subnet_config, out_path, batch_size, keep_work_dir,
     shard_root, fold_matmul, fold_steps, fold_samples, design_steps) = args

    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu)

    # MEASUREMENT ONLY (mw copy). nvidia-smi cannot attribute utilisation or
    # memory to a process when the GPU has other tenants, and this box has
    # them. Timing the stages from inside the worker gives a duty cycle that
    # does not depend on who else is on the device.
    t_spawn = time.time()

    import hydra
    import rdkit.Chem
    from omegaconf import OmegaConf
    import boltzgen.boltzgen_wrapper as bw

    # The CCD mols carry per-atom properties ("name") that the featurizer looks
    # up, and RDKit drops them when a Mol is pickled unless this is set. It
    # never bit upstream because every pipeline step is its own fresh process
    # whose DataLoader workers fork; here the stages run inside a spawned
    # worker, so the mols get pickled and arrive stripped:
    #   KeyError: 'name' at featurizer.py:1022
    # analyze.py sets exactly this, for exactly this reason (analyze.py:243).
    rdkit.Chem.SetDefaultPickleProperties(rdkit.Chem.PropertyPickleOptions.AllProps)
    from boltzgen.cli.boltzgen import build_parser, configure_command
    from boltzgen.task.task import Task

    from resident import ResidentStage

    import torch  # measurement only: per-worker peak GPU memory

    stages: dict[str, ResidentStage] = {}
    t_imports = time.time()
    phases: list = []          # (phase, t_start_epoch, seconds)

    def _ph(name, t0):
        phases.append((name, t0, time.time() - t0))
        return time.time()

    def run_chunk(chunk_dir: Path, chunk_seqs: list[str]) -> dict:
        t_chunk0 = time.time()
        bw.BOLTZGEN_TMP_FILES_DIR = str(chunk_dir)
        shutil.rmtree(chunk_dir, ignore_errors=True)
        (chunk_dir / "inputs").mkdir(parents=True, exist_ok=True)
        (chunk_dir / "outputs").mkdir(parents=True, exist_ok=True)

        w = bw.BoltzgenWrapper()
        w.tmp_dir = str(chunk_dir)
        w.input_dir = str(chunk_dir / "inputs")
        w.output_dir = str(chunk_dir / "outputs")
        w.subnet_config = subnet_config
        w.unique_sequences = w._deduplicate_nanobodies({0: {"sequences": chunk_seqs}})
        w._write_yaml_files()

        # upstream configure: materializes outputs/config/*.yaml + steps.yaml
        parser = build_parser()
        argv = ["configure", w.input_dir, "--output", w.output_dir,
                "--protocol", w.boltzgen_config["protocol"],
                "--num_designs", str(w.boltzgen_config["num_designs"])]
        if w.boltzgen_config["skip_inverse_folding"]:
            argv.append("--skip_inverse_folding")
        if w.boltzgen_config.get("step_scale") is not None:
            argv += ["--step_scale", str(w.boltzgen_config["step_scale"])]
        if w.boltzgen_config.get("noise_scale") is not None:
            argv += ["--noise_scale", str(w.boltzgen_config["noise_scale"])]
        configure_command(parser.parse_args(argv))

        cfg_dir = Path(w.output_dir) / "config"
        designs_dir = Path(w.output_dir) / "intermediate_designs"
        t = _ph("configure", t_chunk0)

        # ---- design (resident) -------------------------------------------
        design_cfg = cfg_dir / "design.yaml"
        yaml_paths = sorted(str(p) for p in Path(w.input_dir).glob("*.yaml"))
        if "design" not in stages:
            stages["design"] = ResidentStage(design_cfg)
            print(f"  shard {shard_id}: design model loaded in "
                  f"{stages['design'].load_seconds:.1f}s", flush=True)
            t = _ph("design_model_load", t)
        stages["design"].run_batch(
            {"data.cfg.yaml_path": yaml_paths, "output": str(designs_dir)},
            predict_args=({"sampling_steps": design_steps} if design_steps else None),
        )
        t = _ph("design_predict", t)

        # ---- folding (resident) ------------------------------------------
        fold_cfg = cfg_dir / "folding.yaml"
        if "folding" not in stages:
            overrides = {}
            if fold_matmul:
                overrides["matmul_precision"] = fold_matmul
            stages["folding"] = ResidentStage(fold_cfg, overrides=overrides)
            print(f"  shard {shard_id}: folding model loaded in "
                  f"{stages['folding'].load_seconds:.1f}s", flush=True)
            t = _ph("folding_model_load", t)
        predict_args = {}
        if fold_steps:
            predict_args["sampling_steps"] = fold_steps
        if fold_samples:
            predict_args["diffusion_samples"] = fold_samples
        stages["folding"].run_batch(
            {"data.design_dir": str(designs_dir), "output": str(designs_dir)},
            predict_args=predict_args or None,
        )
        t = _ph("folding_predict", t)

        # ---- analysis (CPU, no model to keep resident) --------------------
        acfg = OmegaConf.load(cfg_dir / "analysis.yaml")
        OmegaConf.update(acfg, "design_dir", str(designs_dir), merge=False)
        # distribute_tasks runs serially in-process at num_processes==1;
        # above that it spawns a pool whose every worker re-imports torch +
        # boltzgen (~7s) to do ~1.2s of work. Chunks here hold 1-2 designs.
        OmegaConf.update(acfg, "num_processes", 1, merge=False)
        task = hydra.utils.instantiate(acfg)
        if not isinstance(task, Task):
            raise TypeError("analysis config is not a Task")
        task.run(acfg)
        t = _ph("analysis", t)

        results = w._collect_local_results()
        w._populate_per_nanobody_components(results)
        _ph("collect", t)
        return w.per_nanobody_components

    started = time.time()
    components: dict = {}
    for start in range(0, len(seqs), batch_size):
        chunk = seqs[start:start + batch_size]
        chunk_dir = Path(shard_root) / f"shard{shard_id}" / f"chunk{start // batch_size}"
        try:
            got = run_chunk(chunk_dir, chunk)
        except Exception as exc:  # noqa: BLE001 - one bad chunk must not lose the rest
            import traceback
            print(f"  shard {shard_id} chunk {start // batch_size} raised "
                  f"({type(exc).__name__}: {exc}); continuing", flush=True)
            traceback.print_exc()
            got = {}
        for uid, by_seq in (got or {}).items():
            components.setdefault(uid, {}).update(by_seq)
        if not keep_work_dir:
            shutil.rmtree(chunk_dir, ignore_errors=True)
        print(f"  shard {shard_id}: {min(start + batch_size, len(seqs))}/{len(seqs)}",
              flush=True)

    elapsed = time.time() - started
    try:
        peak_alloc = torch.cuda.max_memory_allocated() / 2**20
        peak_resv = torch.cuda.max_memory_reserved() / 2**20
    except Exception:
        peak_alloc = peak_resv = -1.0
    agg: dict = {}
    for name, _t0, secs in phases:
        agg[name] = agg.get(name, 0.0) + secs
    gpu_phases = ("design_predict", "folding_predict")
    on_gpu = sum(v for k, v in agg.items() if k in gpu_phases)
    print(f"  shard {shard_id} PHASES "
          f"spawn_to_import={t_imports - t_spawn:.1f}s " +
          " ".join(f"{k}={v:.1f}s" for k, v in agg.items()) +
          f" | gpu_phase_frac={on_gpu / max(elapsed, 1e-9) * 100:.1f}%"
          f" peak_alloc={peak_alloc:.0f}MiB peak_reserved={peak_resv:.0f}MiB",
          flush=True)
    json.dump({"shard": shard_id, "gpu": gpu, "n": len(seqs),
               "seconds": elapsed, "t_spawn": t_spawn, "t_imports": t_imports,
               "t_end": time.time(), "phases": phases, "phase_totals": agg,
               "peak_alloc_MiB": peak_alloc, "peak_reserved_MiB": peak_resv,
               "components": components},
              open(out_path, "w"), default=str)


# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sequences", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--target", default="P20809")
    ap.add_argument("--gpus", default="0,1")
    ap.add_argument("--shards-per-gpu", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=24,
                    help="sequences per chunk. With resident models the model "
                         "load is no longer amortised over the chunk, so this "
                         "is now only about work-dir size and failure blast "
                         "radius, not throughput.")
    ap.add_argument("--shard-root", default="/root/bgen_shards_fast")
    ap.add_argument("--design-sampling-steps", type=int, default=100,
                    help="design-stage sampling_steps (config default 500). The "
                         "folding step consumes only the TARGET chain's geometry "
                         "from the design output, as an SE(3)-invariant template. "
                         "Measured over 4 designs: at 100 steps that template is "
                         "reproduced to 0.122 A, inside the 0.145 A spread of "
                         "independent 500-step runs, and downstream scores move "
                         "<0.5 sd on design_to_target_iptm. At 50 steps one design "
                         "of four moved 2.3 sd, so 100 is the floor.")
    ap.add_argument("--fold-matmul-precision", default="high",
                    help="TF32 for the folding step. Upstream leaves this null; "
                         "measured 44.3 -> 34.4 ms per denoising step with a "
                         "perturbation the size of rerunning the same config.")
    ap.add_argument("--fold-sampling-steps", type=int, default=None,
                    help="override folding sampling_steps (default: config, 200)")
    ap.add_argument("--fold-diffusion-samples", type=int, default=None,
                    help="override folding diffusion_samples (default: config, 5). "
                         "NOTE the score is a MAX over samples, so lowering this "
                         "biases scores downward, it does not merely add noise.")
    ap.add_argument("--keep-work-dir", action="store_true")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    raw = json.load(open(a.sequences))
    items = raw if isinstance(raw, list) else (raw.get("cases") or raw.get("sequences") or [])
    seqs = [it["sequence"] if isinstance(it, dict) else it for it in items]
    seqs = [s for s in seqs if isinstance(s, str) and s]
    if not seqs:
        raise SystemExit(f"no sequences parsed from {a.sequences}")

    import yaml
    subnet_config = _flatten_config(yaml.safe_load(open(a.config)), a.target)

    gpus = [g.strip() for g in a.gpus.split(",") if g.strip()]
    n_shards = max(1, len(gpus) * a.shards_per_gpu)
    buckets = [[] for _ in range(n_shards)]
    for i, s in enumerate(seqs):
        buckets[i % n_shards].append(s)

    os.makedirs(a.shard_root, exist_ok=True)
    jobs = [(i, gpus[i % len(gpus)], b, subnet_config,
             os.path.join(a.shard_root, f"out{i}.json"), a.batch_size,
             a.keep_work_dir, a.shard_root, a.fold_matmul_precision,
             a.fold_sampling_steps, a.fold_diffusion_samples,
             a.design_sampling_steps)
            for i, b in enumerate(buckets) if b]
    print(f"{len(seqs)} sequences over {len(jobs)} shards on GPUs {gpus}", flush=True)

    started = time.time()
    # spawn, never fork, because these processes initialise CUDA -- and
    # NON-daemonic, because the predict DataLoaders (num_workers >= 1) spawn
    # children of their own and `mp.Pool` workers are daemonic, which fails as
    # "daemonic processes are not allowed to have children".
    ctx = mp.get_context("spawn")
    procs = []
    for job in jobs:
        pr = ctx.Process(target=_worker, args=(job,), daemon=False)
        pr.start()
        procs.append((pr, job))
    results = []
    for pr, job in procs:
        pr.join()
        shard_id, _gpu, bucket, _sc, out_path = job[0], job[1], job[2], job[3], job[4]
        if pr.exitcode != 0 or not os.path.exists(out_path):
            raise SystemExit(
                f"shard {shard_id} exited {pr.exitcode} without writing "
                f"{out_path}. Refusing to report a partial result."
            )
        results.append((out_path, len(bucket), json.load(open(out_path))["seconds"]))
    wall = time.time() - started

    # Merge at the SEQUENCE level: every shard uses uid 0, so a plain
    # dict.update() would drop whole shards.
    merged: dict = {}
    shard_stats = []
    for path, n, secs in results:
        d = json.load(open(path))
        for uid, by_seq in d["components"].items():
            merged.setdefault(uid, {}).update(by_seq)
        shard_stats.append({k: d.get(k) for k in
                            ("shard", "gpu", "n", "seconds", "t_spawn",
                             "t_imports", "t_end", "phase_totals",
                             "peak_alloc_MiB", "peak_reserved_MiB")})
        print(f"  shard {d['shard']} gpu {d['gpu']}: {n} seqs in {secs:.1f}s "
              f"({secs/max(n,1):.1f}s/seq)", flush=True)
    n_out = sum(len(v) for v in merged.values())
    print(f"TOTAL {len(seqs)} sequences in {wall:.1f}s "
          f"({wall/max(len(seqs),1):.1f}s per sequence wall-clock)", flush=True)
    if n_out != len(seqs):
        raise SystemExit(f"MERGE LOST SEQUENCES: submitted {len(seqs)}, "
                         f"merged {n_out}. Refusing to write a partial result.")
    json.dump({"target": a.target, "n": len(seqs), "wall_seconds": wall,
               "shards_per_gpu": a.shards_per_gpu, "gpus": gpus,
               "t_launch": started, "shard_stats": shard_stats,
               "per_nanobody_components": merged}, open(a.out, "w"),
              indent=2, default=str)
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
