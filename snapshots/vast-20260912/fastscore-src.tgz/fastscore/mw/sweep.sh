#!/usr/bin/env bash
# Serial K-sweep on ONE gpu. rep1 ascending, rep2 descending so any drift in
# box load partially cancels between reps.
set -u
GPU=${1:-0}
SEQ=/root/fastscore/mw/seqs24.json
cd /root/fastscore/mw
for spec in "1 k1r1 no" "2 k2r1 no" "3 k3r1 no" "4 k4r1 keep" \
            "4 k4r2 no" "3 k3r2 no" "2 k2r2 no" "1 k1r2 no"; do
  set -- $spec
  echo "=== $(date +%H:%M:%S) starting K=$1 tag=$2 ==="
  ./run_k.sh "$1" "$2" "$SEQ" "$GPU" "$3"
  sleep 10
done
echo "=== sweep done $(date +%H:%M:%S) ==="
