#!/usr/bin/env bash
set -u
GPU=1
cd /root/fastscore/mw
echo "=== $(date +%H:%M:%S) duty cycle, K=1, 8 seqs, gpu $GPU ==="
./run_k.sh 1 duty2 /root/fastscore/mw/seqs8.json $GPU keep
sleep 5
for spec in "1 k1r1 no" "2 k2r1 no" "3 k3r1 no" "4 k4r1 keep" \
            "4 k4r2 no" "3 k3r2 no" "2 k2r2 no" "1 k1r2 no"; do
  set -- $spec
  echo "=== $(date +%H:%M:%S) starting K=$1 tag=$2 ==="
  ./run_k.sh "$1" "$2" /root/fastscore/mw/seqs24.json $GPU "$3"
  sleep 5
done
echo "=== ALLDONE $(date +%H:%M:%S) ==="
