#!/usr/bin/env python3
"""Verify a fast_score_batch output: every submitted sequence present with all
ten metrics, and no cross-shard contamination in the merged result."""
import json, sys, os

METRICS = ["design_iiptm","design_ptm","design_to_target_iptm",
           "min_design_to_target_pae","interaction_pae","plip_hbonds_refolded",
           "plip_saltbridge_refolded","delta_sasa_refolded","liability_score",
           "liability_num_violations"]

seqs_path, out_path = sys.argv[1], sys.argv[2]
submitted = json.load(open(seqs_path))
d = json.load(open(out_path))
comp = d["per_nanobody_components"]

flat = {}
dupes = []
for uid, by_seq in comp.items():
    for seq, by_target in by_seq.items():
        if seq in flat:
            dupes.append(seq)
        flat[seq] = by_target

missing_seq, missing_metric, null_metric = [], [], []
for s in submitted:
    if s not in flat:
        missing_seq.append(s[:20]); continue
    bt = flat[s]
    tgt = bt.get("P20809")
    if not tgt:
        missing_seq.append(s[:20] + "(no target)"); continue
    absent = [m for m in METRICS if m not in tgt]
    if absent:
        missing_metric.append((s[:20], absent))
    nulls = [m for m in METRICS if tgt.get(m) in (None, "", "nan") or
             (isinstance(tgt.get(m), float) and tgt[m] != tgt[m])]
    if nulls:
        null_metric.append((s[:20], nulls))

extra = [s[:20] for s in flat if s not in submitted]

print(f"file            : {out_path}")
print(f"submitted       : {len(submitted)}  (unique {len(set(submitted))})")
print(f"returned        : {len(flat)}")
print(f"wall_seconds    : {d.get('wall_seconds'):.1f}")
print(f"missing seqs    : {len(missing_seq)} {missing_seq}")
print(f"missing metrics : {len(missing_metric)} {missing_metric}")
print(f"null metrics    : {len(null_metric)} {null_metric}")
print(f"unsubmitted seqs: {len(extra)} {extra}")
print(f"dup seq keys    : {len(dupes)}")
ok = not (missing_seq or missing_metric or null_metric or extra or dupes) and len(flat)==len(set(submitted))
print("VERDICT         :", "PASS" if ok else "FAIL")
