#!/usr/bin/env python3
"""Summarise a gpu.log from run_k.sh.  'S ts util,mem load1,load5,load15'
and every 15th sample an 'A ts pid,mem;pid,mem;' compute-app snapshot."""
import sys
rows=[]; apps=[]
for line in open(sys.argv[1]):
    p=line.split()
    if not p: continue
    if p[0]=="S" and len(p)>=4:
        try:
            ts=int(p[1]); util,mem=p[2].split(","); la=p[3].split(",")[0]
            rows.append((ts,int(util),int(mem),float(la)))
        except Exception: pass
    elif p[0]=="A":
        apps.append(" ".join(p[2:]) if len(p)>2 else "")
if not rows: sys.exit("no rows")
n=len(rows); utils=[r[1] for r in rows]; mems=[r[2] for r in rows]
base=mems[0]
print(f"samples={n}  span={rows[-1][0]-rows[0][0]+1}s")
print(f"baseline_mem_MiB={base}  peak_mem_MiB={max(mems)}  peak_minus_baseline={max(mems)-base}")
maxproc=max((len([x for x in a.split(';') if x.strip()]) for a in apps), default=0)
print(f"max concurrent compute apps on this GPU during run = {maxproc}")
print(f"mean_util={sum(utils)/n:.1f}%  median_util={sorted(utils)[n//2]}%")
for th in (1,25,50,75,90,99):
    c=sum(1 for u in utils if u>=th)
    print(f"  frac(util>={th:3d}%) = {c/n*100:5.1f}%  ({c} samples)")
print(f"  util==0          = {sum(1 for u in utils if u==0)/n*100:5.1f}%")
la=[r[3] for r in rows]
print(f"load1: min={min(la):.1f} mean={sum(la)/n:.1f} max={max(la):.1f}")
print("timeline (5s/char, digit=round(util/10)):")
b="".join(str(min(9,int(round(sum(utils[i:i+5])/len(utils[i:i+5])/10)))) for i in range(0,n,5))
for i in range(0,len(b),60):
    print(f"  t={i*5:5d}s {b[i:i+60]}")
print("mem timeline (5s/char, digit=round(GiB)):")
m="".join(str(min(9,int(round(max(mems[i:i+5])/1024)))) for i in range(0,n,5))
for i in range(0,len(m),60):
    print(f"  t={i*5:5d}s {m[i:i+60]}")
