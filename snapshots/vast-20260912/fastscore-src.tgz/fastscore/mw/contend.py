#!/usr/bin/env python3
"""Per-run contention audit from the global contention.log.

Another agent in this container runs jobs with --gpus 0,1,2,3 (and 0..9). Those
jobs put a near-identical footprint on every GPU in their list at the same
instant, so GPU 2 and GPU 3 -- which I never touch -- are a clean proxy for
"the foreign multi-GPU job is running right now, and therefore is also on my
GPU 1".
"""
import sys, os, json

LOG = "/root/fastscore/mw/contention.log"
MYGPU = 1
PROXY = (2, 3)

G = {}
A = {}
for line in open(LOG):
    p = line.split(None, 2)
    if len(p) < 3: continue
    kind, ts = p[0], int(p[1])
    if kind == "G":
        d = {}
        for rec in p[2].strip().split(";"):
            if not rec: continue
            i, u, m = rec.split(",")
            d[int(i)] = (int(u), int(m))
        G[ts] = d
    elif kind == "A":
        per = {}
        for rec in p[2].strip().split(";"):
            if not rec: continue
            uuid, pid, mem = rec.split(",")
            per.setdefault(uuid, []).append((pid, mem))
        A[ts] = per

uuid_of = {}
for ts, d in list(G.items())[:1]:
    pass

for tag in sys.argv[1:]:
    b = f"/root/fastscore/mw/runs/{tag}"
    meta = dict(kv.split("=", 1) for kv in open(os.path.join(b, "meta.txt")).read().split())
    t0, t1 = int(meta["start"]), int(meta["end"])
    ts = [t for t in sorted(G) if t0 <= t <= t1]
    if not ts:
        print(f"{tag}: no contention samples in window"); continue
    mine = [G[t][MYGPU] for t in ts if MYGPU in G[t]]
    prox_busy = [t for t in ts if any(G[t].get(g, (0, 0))[0] > 20 for g in PROXY)]
    prox_mem = [t for t in ts if any(G[t].get(g, (0, 0))[1] > 500 for g in PROXY)]
    napps = []
    for t in ts:
        best = min(A, key=lambda x: abs(x - t)) if A else None
        if best is not None and abs(best - t) <= 2:
            # count apps on the gpu whose uuid carries my gpu's memory value
            napps.append(sum(len(v) for v in A[best].values()))
    print(f"{tag:7} K={meta['K']} window={t1-t0}s samples={len(ts)}")
    print(f"    my gpu{MYGPU}: mean_util={sum(u for u,_ in mine)/len(mine):5.1f}%  "
          f"peak_mem={max(m for _,m in mine):6d}MiB  min_mem={min(m for _,m in mine):6d}MiB")
    print(f"    foreign proxy (gpu2/3 util>20%): {len(prox_busy)/len(ts)*100:5.1f}% of window"
          f"   (mem>500MiB: {len(prox_mem)/len(ts)*100:5.1f}%)")
