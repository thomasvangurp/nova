#!/usr/bin/env bash
# Global contention log. Another agent shares this container and this box, so
# every run has to be auditable after the fact for GPU tenancy.
while true; do
  T=$(date +%s)
  echo "G $T $(nvidia-smi --query-gpu=index,utilization.gpu,memory.used --format=csv,noheader,nounits | tr -d ' ' | tr '\n' ';')"
  echo "A $T $(nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader | tr -d ' ' | tr '\n' ';')"
  echo "L $T $(cut -d' ' -f1-3 /proc/loadavg | tr ' ' ',')"
  # other agents' scoring processes inside this container (not mine, which live
  # under /root/fastscore/mw)
  echo "P $T $(pgrep -af 'fast_score_batch|score_boltzgen|boltzgen' | grep -v '/root/fastscore/mw' | grep -v pgrep | sed 's/.*--gpus/GPUS/' | cut -c1-40 | tr '\n' ';')"
  sleep 2
done
