#!/usr/bin/env bash
# usage: run_k.sh <K> <tag> <seqs.json> <gpu> [keepwork]
set -u
K=$1; TAG=$2; SEQS=$3; GPU=$4; KEEP=${5:-no}
BASE=/root/fastscore/mw/runs/${TAG}
rm -rf "$BASE"; mkdir -p "$BASE"

# Record who else is on this GPU before we start. A foreign tenant makes the
# whole measurement worthless, so it is recorded, not assumed away.
nvidia-smi --id=$GPU --query-compute-apps=pid,used_memory --format=csv,noheader \
  > "$BASE/apps_before.txt" 2>&1
nvidia-smi --id=$GPU --query-gpu=utilization.gpu,memory.used --format=csv,noheader,nounits \
  > "$BASE/gpu_before.txt" 2>&1

( i=0
  while true; do
    echo "S $(date +%s) $(nvidia-smi --id=$GPU --query-gpu=utilization.gpu,memory.used --format=csv,noheader,nounits | tr -d ' ') $(cut -d' ' -f1-3 /proc/loadavg | tr ' ' ',')"
    i=$((i+1))
    if [ $((i % 15)) -eq 0 ]; then
      echo "A $(date +%s) $(nvidia-smi --id=$GPU --query-compute-apps=pid,used_memory --format=csv,noheader | tr '\n' ';' | tr -d ' ')"
    fi
    sleep 1
  done ) > "$BASE/gpu.log" 2>/dev/null &
SPID=$!

EXTRA=""
if [ "$KEEP" = "keep" ]; then EXTRA="--keep-work-dir"; fi

START=$(date +%s)
cd /root/fastscore/mw
/root/fastscore/release/release_python.sh /root/fastscore/mw/fast_score_batch.py \
  --sequences "$SEQS" --config /root/config/config.yaml --target P20809 \
  --gpus "$GPU" --shards-per-gpu "$K" --batch-size 24 \
  --shard-root "$BASE/shards" --out "$BASE/out.json" $EXTRA \
  > "$BASE/run.log" 2>&1
RC=$?
END=$(date +%s)
kill $SPID 2>/dev/null
nvidia-smi --id=$GPU --query-compute-apps=pid,used_memory --format=csv,noheader \
  > "$BASE/apps_after.txt" 2>&1
echo "K=$K tag=$TAG gpu=$GPU rc=$RC start=$START end=$END wall=$((END-START))" > "$BASE/meta.txt"
cat "$BASE/meta.txt"
