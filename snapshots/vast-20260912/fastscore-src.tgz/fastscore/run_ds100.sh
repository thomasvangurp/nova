#!/usr/bin/env bash
# 100 steps is the setting the four-design chain-A comparison supports
# (worst drift 0.122 A vs a 0.145 A floor). 50 steps moved one design ~2 sd
# downstream, and that was the design whose template drifted most.
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=5
./fast_python.sh sweep_budget.py fold_res.yaml \
  --source-dir design_sweep/steps100 --work-root /root/fastscore/ds_work100 \
  --variants 200x5 --repeats 4 --out /root/fastscore/ds100.json > run_ds100.log 2>&1
touch ds100.done
