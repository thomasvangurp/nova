"""Sweep the folding sampler's budget: does a cheaper scorer still rank the same?

This is the experiment that decides whether 100x is reachable. Everything
cheaper than "make the same computation faster" has to come out of the folding
sampler, which is 200 denoising steps x 5 diffusion samples and ~79% of the
folding step's GPU time.

Cutting it is NOT free and is not claimed to be. Two distinct effects:

  * fewer STEPS  -> a less converged structure. Unbiased in no particular
    direction; shows up as extra spread.
  * fewer SAMPLES -> the reported score is a MAX over the samples
    (analyze_utils.get_best_folding_sample), so dropping 5 -> 2 lowers the
    score systematically, not just noisily. Any comparison to archive or field
    numbers has to be recalibrated, and only RANKING can be expected to carry
    over.

So the quantities reported here are (a) seconds per design, (b) the spread
across repeats at fixed settings, and (c) per-design score, so ranking across
designs can be correlated against the reference setting afterwards. The useful
figure of merit is variance per GPU-second, not agreement with the reference.

One model load serves the whole sweep: predict_step reads predict_args at call
time, so the budget can change between batches.
"""
from __future__ import annotations

import argparse, json, shutil, time
from pathlib import Path

import numpy as np

from resident import ResidentStage, seed_all

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def best_sample(npz) -> dict:
    conf = (0.8 * np.asarray(npz["design_to_target_iptm"], float)
            + 0.2 * np.asarray(npz["design_ptm"], float))
    i = int(np.argmax(conf))
    return {k: float(np.asarray(npz[k], float)[i]) for k in KEYS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--source-dir", required=True,
                    help="directory of design .cif/.npz to score")
    ap.add_argument("--work-root", required=True)
    ap.add_argument("--variants", default="200x5,100x5,50x5,200x2,100x2,50x2",
                    help="comma separated STEPSxSAMPLES, optionally xRECYCLES "
                         "(e.g. 200x5x3). recycling_steps=3 means FOUR trunk "
                         "passes and is most of the ~3.3s fixed cost per design "
                         "that survives any sampler-step reduction.")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    src = Path(a.source_dir)
    designs = sorted(p.stem for p in src.glob("*.cif"))
    print(f"{len(designs)} designs from {src}", flush=True)

    variants = []
    for tok in a.variants.split(","):
        parts = tok.lower().split("x")
        s, m = int(parts[0]), int(parts[1])
        rec = int(parts[2]) if len(parts) > 2 else None
        variants.append((s, m, rec))

    stage = ResidentStage(a.config)
    print(f"model load: {stage.load_seconds:.1f}s", flush=True)

    root = Path(a.work_root)
    results = []
    for steps, samples, rec in variants:
        for rep in range(a.repeats):
            d = root / f"s{steps}_m{samples}_c{rec}_r{rep}"
            shutil.rmtree(d, ignore_errors=True)
            d.mkdir(parents=True, exist_ok=True)
            for p in list(src.glob("*.cif")) + list(src.glob("*.npz")):
                shutil.copyfile(p, d / p.name)

            # a distinct seed per repeat: repeats are meant to sample the
            # scorer's own randomness, not to re-measure one draw
            seed_all(1000 + rep)
            secs = stage.run_batch(
                {"data.design_dir": str(d), "output": str(d)},
                predict_args=(
                    {"sampling_steps": steps, "diffusion_samples": samples}
                    | ({"recycling_steps": rec} if rec is not None else {})
                ),
            )

            for npz_path in sorted((d / "fold_out_npz").glob("*.npz")):
                m = best_sample(np.load(npz_path, allow_pickle=True))
                m.update(design=npz_path.stem, steps=steps, samples=samples,
                         recycles=rec, repeat=rep,
                         seconds=secs / max(len(designs), 1))
                results.append(m)
            print(f"  steps={steps:3d} samples={samples} recycles={rec} rep={rep}: "
                  f"{secs:.1f}s for {len(designs)} designs "
                  f"({secs/max(len(designs),1):.1f}s/design)", flush=True)
            shutil.rmtree(d, ignore_errors=True)
            json.dump(results, open(a.out, "w"), indent=1)

    json.dump(results, open(a.out, "w"), indent=1)
    print(f"wrote {a.out} ({len(results)} rows)", flush=True)


if __name__ == "__main__":
    main()
