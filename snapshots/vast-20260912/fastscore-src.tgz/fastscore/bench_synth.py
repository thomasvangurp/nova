"""Per-sequence synthesis cost, with the template library built once."""
import sys, time, random
from pathlib import Path
sys.path.insert(0, "/root/fastscore")
from synth_fullatom import TemplateLibrary, synthesize, sequence_of, ONE_TO_THREE

D = Path("/root/fastscore/work_base4/outputs/intermediate_designs")
cifs = sorted(D.glob("*_input.cif"))
out = Path("/tmp/bench_synth"); out.mkdir(exist_ok=True)

t0 = time.perf_counter()
lib = TemplateLibrary.from_cifs(cifs)
t_lib = time.perf_counter() - t0
print(f"library build (once): {t_lib*1e3:.0f} ms, {sum(lib.coverage().values())} rotamers")

ref = cifs[0]
base = sequence_of(ref)
rng = random.Random(0)
alphabet = list(ONE_TO_THREE)

for passes in (1, 2):
    ts = []
    for n in range(20):
        # a fresh random-mutant sequence each time, so no caching can help
        s = list(base)
        for _ in range(12):
            s[rng.randrange(len(s))] = rng.choice(alphabet)
        t0 = time.perf_counter()
        synthesize(ref, "".join(s), out / "x.cif", lib, seed=n, passes=passes)
        ts.append(time.perf_counter() - t0)
    ts = sorted(ts)
    print(f"passes={passes}: median {ts[len(ts)//2]*1e3:.0f} ms, "
          f"min {ts[0]*1e3:.0f} ms, max {ts[-1]*1e3:.0f} ms  (n=20)")
