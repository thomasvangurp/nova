"""Synthesize the `design` step's output for a new nanobody sequence.

The 45 s/design design stage exists only to emit a .cif + .npz for the folding
stage. A coordinate-perturbation trace established that folding consumes, from
that .cif, the TARGET chain's geometry (as an SE(3)-invariant template) and
both chains' SEQUENCES -- and nothing at all from the designed chain's
coordinates, which the checkpoint has no module to read (no token-distance
weights, strict=True load).

So a reference design output for the same target can be retargeted to any new
sequence by rewriting chain B's residue names. Chain A is copied byte-for-byte,
which is stronger than regenerating it: across 4 real designs chain A's internal
CA distance matrices agree to 0.13 A, so copying removes even that drift.

Modes for chain B's atoms:
  backbone   keep only N, CA, C, O -- present in every amino acid, so the same
             atom records are valid whatever the new residue name is
  keepall    keep the reference atoms unchanged (only valid when the new
             sequence has the same residue at that position; used as a control)

This writes plausible, non-degenerate geometry (the reference backbone), never
zeros or collinear atoms: the mmCIF parser runs a KDTree radius query over all
atoms and degenerate frames take a different code path.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import numpy as np

# three-letter codes, indexed the way the one-letter sequence is written
ONE_TO_THREE = {
    "A": "ALA", "R": "ARG", "N": "ASN", "D": "ASP", "C": "CYS",
    "Q": "GLN", "E": "GLU", "G": "GLY", "H": "HIS", "I": "ILE",
    "L": "LEU", "K": "LYS", "M": "MET", "F": "PHE", "P": "PRO",
    "S": "SER", "T": "THR", "W": "TRP", "Y": "TYR", "V": "VAL",
}
BACKBONE = {"N", "CA", "C", "O"}


def parse_atom_line(line: str) -> list[str]:
    return line.split()


def retarget(ref_cif: Path, sequence: str, out_cif: Path,
             design_asym: str = "B", mode: str = "backbone") -> None:
    text = ref_cif.read_text()
    lines = text.splitlines()

    # locate the atom_site column order rather than assuming it
    cols: list[str] = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("_atom_site."):
            cols.append(s.split(".", 1)[1])
    idx = {name: i for i, name in enumerate(cols)}
    c_atom, c_comp = idx["label_atom_id"], idx["label_comp_id"]
    c_asym, c_seq, c_id = idx["label_asym_id"], idx["label_seq_id"], idx["id"]

    three = [ONE_TO_THREE[c] for c in sequence]

    out: list[str] = []
    serial = 0
    n_design_res = 0
    seen_seq_ids: dict[str, int] = {}

    for ln in lines:
        if not ln.startswith(("ATOM", "HETATM")):
            out.append(ln)
            continue
        f = parse_atom_line(ln)
        if f[c_asym] != design_asym:
            serial += 1
            f[c_id] = str(serial)
            out.append(" ".join(f))
            continue

        # designed chain
        if mode == "backbone" and f[c_atom] not in BACKBONE:
            continue
        seq_id = f[c_seq]
        if seq_id not in seen_seq_ids:
            seen_seq_ids[seq_id] = len(seen_seq_ids)
            n_design_res += 1
        pos = seen_seq_ids[seq_id]
        if pos >= len(three):
            continue                      # reference longer than the new sequence
        new_comp = three[pos]
        if mode == "backbone" and new_comp == "GLY" and f[c_atom] not in BACKBONE:
            continue
        f[c_comp] = new_comp
        serial += 1
        f[c_id] = str(serial)
        out.append(" ".join(f))

    if n_design_res != len(sequence):
        raise SystemExit(
            f"reference design chain has {n_design_res} residues but the new "
            f"sequence has {len(sequence)}; retargeting needs a same-length "
            f"reference (or a builder that can add/remove residues)"
        )

    # the one-letter sequence block must agree with the ATOM records: the
    # parser reads residue names from ATOM, but a mismatched entity_poly is a
    # trap for anything downstream that trusts it
    joined = "\n".join(out)
    ref_seq = None
    for ln in lines:
        s = ln.strip()
        if s.startswith("2 polypeptide(L) ?"):
            ref_seq = s.rsplit(" ", 1)[-1]
    if ref_seq and len(ref_seq) == len(sequence):
        joined = joined.replace(f"2 polypeptide(L) ? {ref_seq}",
                                f"2 polypeptide(L) ? {sequence}")
    out_cif.write_text(joined + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref-cif", required=True)
    ap.add_argument("--ref-npz", required=True)
    ap.add_argument("--sequence", required=True)
    ap.add_argument("--out-prefix", required=True,
                    help="written as <prefix>.cif and <prefix>.npz")
    ap.add_argument("--mode", default="backbone", choices=["backbone", "keepall"])
    a = ap.parse_args()

    out = Path(a.out_prefix)
    retarget(Path(a.ref_cif), a.sequence, out.with_suffix(".cif"), mode=a.mode)
    # folding reads only ss_type / binding_type out of the npz and the model
    # consumes neither; copying the reference keeps it byte-valid
    shutil.copyfile(a.ref_npz, out.with_suffix(".npz"))
    print(f"wrote {out.with_suffix('.cif')} and {out.with_suffix('.npz')}")


if __name__ == "__main__":
    main()
