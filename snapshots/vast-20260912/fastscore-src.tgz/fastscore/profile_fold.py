"""Profile ONE boltzgen pipeline step, with no edit to the boltzgen source.

Everything here is a runtime monkeypatch applied in this process only, so the
live vendored tree under /root/external_tools/boltzgen is never touched and a
concurrent mining run cannot pick up a half-applied patch.

Usage:
    fast_python.sh profile_fold.py <path to outputs/config/folding.yaml> [--torch-profiler]

Reports, per forward():
  trunk        the recycling loop (msa + template + pairformer)
  sample       the diffusion sampler, plus its per-denoise-step network time
  confidence   the confidence head that actually produces iptm/pae
CUDA events are used rather than wall clock: launches are async, so wall clock
around a python line attributes the queue drain to whoever synchronises next.
"""
from __future__ import annotations
import argparse, collections, sys, time

import torch


TOT = collections.defaultdict(list)   # name -> list of (start_event, end_event)
COUNT = collections.Counter()


def _ev():
    a = torch.cuda.Event(enable_timing=True)
    b = torch.cuda.Event(enable_timing=True)
    return a, b


def wrap(obj, attr, name):
    orig = getattr(obj, attr)

    def inner(*a, **kw):
        s, e = _ev()
        s.record()
        out = orig(*a, **kw)
        e.record()
        TOT[name].append((s, e))
        COUNT[name] += 1
        return out

    setattr(obj, attr, inner)
    return orig


def report(tag=""):
    torch.cuda.synchronize()
    if not TOT:
        return
    print(f"\n==== CUDA time {tag} ====", flush=True)
    rows = []
    for name, evs in TOT.items():
        tot = sum(a.elapsed_time(b) for a, b in evs)
        rows.append((tot, name, len(evs)))
    for tot, name, n in sorted(rows, reverse=True):
        print(f"  {name:34s} n={n:6d}  total={tot/1000:8.3f}s  each={tot/max(n,1):9.3f}ms",
              flush=True)
    TOT.clear()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--torch-profiler", action="store_true")
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--seed", type=int, default=None,
                    help="seed torch/numpy/random in THIS process. The step runs\n                         in-process here, so one seed controls the whole run and\n                         an A/B differs only in the variable under test. Unlike the\n                         bgen_shim diagnostic seed this does NOT disable TF32 or\n                         force deterministic algorithms -- those are what we are\n                         trying to measure.")
    a = ap.parse_args()

    if a.seed is not None:
        import random, numpy as np
        random.seed(a.seed)
        np.random.seed(a.seed)
        torch.manual_seed(a.seed)
        torch.cuda.manual_seed_all(a.seed)
        print(f'seeded with {a.seed}', flush=True)

    import omegaconf, hydra
    from boltzgen.task.task import Task
    from boltzgen.model.models.boltz import Boltz
    from boltzgen.model.modules.diffusion import AtomDiffusion, DiffusionModule
    from boltzgen.model.modules.confidence import ConfidenceModule
    from boltzgen.model.layers.pairformer import PairformerModule

    wrap(Boltz, "forward", "Boltz.forward (whole)")
    wrap(AtomDiffusion, "sample", "  diffusion.sample")
    wrap(DiffusionModule, "forward", "    denoise net forward")
    wrap(ConfidenceModule, "forward", "  confidence_module")
    wrap(PairformerModule, "forward", "  pairformer (trunk)")

    cfg = omegaconf.OmegaConf.load(a.config)
    task = hydra.utils.instantiate(cfg)
    assert isinstance(task, Task)

    t0 = time.time()
    if a.torch_profiler:
        from torch.profiler import profile, ProfilerActivity
        with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
                     record_shapes=False) as prof:
            task.run(cfg)
        print(prof.key_averages().table(sort_by="self_cuda_time_total",
                                        row_limit=a.top), flush=True)
    else:
        task.run(cfg)
    wall = time.time() - t0

    report("(whole step)")
    print(f"\nstep wall clock: {wall:.1f}s", flush=True)


if __name__ == "__main__":
    main()
