"""Drive folding runs at several batch sizes from ONE resident model.

Each run gets its own design_dir (the folding writer writes fold_out_npz/ and
refold_cif/ *inside* design_dir), populated by copying from bt/pool.  The
model is loaded once, so the reported seconds are predict-only and comparable
across batch sizes.

  bt_run.py <cfg.yaml> --runs NAME:A+B+C+D:4 ... --seed 7

batch_size is overridden per run, so one model load serves the whole sweep and
the seconds are directly comparable across batch sizes.
"""
from __future__ import annotations

import argparse, json, os, shutil, sys, time

import torch
from pathlib import Path

sys.path.insert(0, "/root/fastscore")
from resident import ResidentStage, seed_all

POOL = Path("/root/fastscore/bt/pool")
ROOT = Path("/root/fastscore/bt")


def make_dir(name: str, labels: list[str]) -> Path:
    d = ROOT / name
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for ch in labels:
        shutil.copyfile(POOL / f"{ch}.cif", d / f"{ch}.cif")
        shutil.copyfile(POOL / f"{ch}.npz", d / f"{ch}.npz")
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--runs", nargs="+", required=True,
                    help="NAME:L1+L2+...:BATCH, e.g. b4:A+B+C+D:4")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--sampling-steps", type=int, default=None)
    ap.add_argument("--diffusion-samples", type=int, default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    pa = {}
    if a.sampling_steps is not None:
        pa["sampling_steps"] = a.sampling_steps
    if a.diffusion_samples is not None:
        pa["diffusion_samples"] = a.diffusion_samples

    stage = ResidentStage(a.config)
    print(f"model load: {stage.load_seconds:.1f}s", flush=True)

    results = []
    for spec in a.runs:
        parts = spec.split(":")
        name, label_str, bs = parts[:3]
        labels = label_str.split("+")
        # optional 4th/5th field: sampling steps / diffusion samples for this
        # run only, so a phase attribution needs one model load, not four
        run_pa = dict(pa)
        if len(parts) > 3 and parts[3]:
            run_pa["sampling_steps"] = int(parts[3])
        if len(parts) > 4 and parts[4]:
            run_pa["diffusion_samples"] = int(parts[4])
        d = make_dir(name, labels)
        # same seed for every run: the sampler's randn stream must start from
        # the same place or the comparison measures seed, not batching
        seed_all(a.seed)
        t0 = time.time()
        try:
            stage.run_batch({"data.design_dir": str(d), "output": str(d),
                             "data.cfg.batch_size": int(bs)}, predict_args=run_pa)
            err = None
        except Exception as e:  # keep going: a failed variant is a datapoint
            import traceback; traceback.print_exc()
            err = f"{type(e).__name__}: {e}"
        secs = time.time() - t0
        n = len(labels)
        got = len(list((d / "fold_out_npz").glob("*.npz"))) if (d / "fold_out_npz").exists() else 0
        peak = torch.cuda.max_memory_allocated() / 2**30
        torch.cuda.reset_peak_memory_stats()
        print(f"RUN {name:14s} bs={bs} n={n} {secs:7.1f}s  {secs/n:6.2f}s/design  "
              f"peak={peak:5.1f}GiB npz={got}/{n}  {err or 'ok'}", flush=True)
        results.append(dict(name=name, labels=labels, batch_size=int(bs), n=n,
                            secs=secs, per_design=secs / n, peak_gib=peak,
                            npz=got, err=err))

    if a.out:
        Path(a.out).write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
