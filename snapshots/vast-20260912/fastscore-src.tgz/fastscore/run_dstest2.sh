#!/usr/bin/env bash
# 100 steps is the setting the four-design chain-A comparison actually supports;
# fold it too so the downstream check covers the setting we would ship.
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=5
./fast_python.sh sweep_budget.py fold_res.yaml \
  --source-dir design_sweep/steps100 --work-root /root/fastscore/ds_work100 \
  --variants 200x5 --repeats 4 --out /root/fastscore/ds100.json > run_ds100.log 2>&1
touch dstest2.done
