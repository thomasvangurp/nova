"""Compare folding outputs using the VALIDATOR's own aggregation.

analyze_utils.get_best_folding_sample picks ONE of the diffusion samples --
argmax(0.8 * design_to_target_iptm + 0.2 * design_ptm) -- and every confidence
metric the validator scores is that sample's value. Comparing per-sample means
(as an earlier version of this script did) measures something the validator
never looks at, and it hides the selection effect: with diffusion_samples=5 the
score is a MAX over 5 draws, so changing the sample count shifts the score
systematically even if each draw's distribution is unchanged.

  cmp_fold.py <dirA> <dirB>
"""
from __future__ import annotations
import argparse, glob, os, sys
import numpy as np

VALIDATOR_KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
                  "min_design_to_target_pae", "interaction_pae"]


def best_sample(d: dict) -> dict:
    conf = 0.8 * np.asarray(d["design_to_target_iptm"], float) \
         + 0.2 * np.asarray(d["design_ptm"], float)
    i = int(np.argmax(conf))
    return {k: float(np.asarray(d[k], float)[i]) for k in VALIDATOR_KEYS}, i


def load(path):
    out = {}
    for f in sorted(glob.glob(os.path.join(path, "*.npz"))):
        out[os.path.basename(f)] = dict(np.load(f, allow_pickle=True))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("a")
    ap.add_argument("b")
    ap.add_argument("--label-a", default="A")
    ap.add_argument("--label-b", default="B")
    args = ap.parse_args()

    A, B = load(args.a), load(args.b)
    common = sorted(set(A) & set(B))
    if not common:
        sys.exit(f"no overlapping npz ({len(A)} vs {len(B)})")

    for name in common:
        ba, ia = best_sample(A[name])
        bb, ib = best_sample(B[name])
        print(f"{name[:24]}   best sample: {args.label_a}=#{ia}  {args.label_b}=#{ib}")
        print(f"  {'metric':26s} {args.label_a:>10s} {args.label_b:>10s} "
              f"{'diff':>10s}  {'A spread over 5':>18s}")
        for k in VALIDATOR_KEYS:
            va = np.asarray(A[name][k], float)
            spread = f"{va.min():.3f}..{va.max():.3f}"
            print(f"  {k:26s} {ba[k]:10.4f} {bb[k]:10.4f} "
                  f"{bb[k]-ba[k]:+10.4f}  {spread:>18s}")
        print()


if __name__ == "__main__":
    main()
