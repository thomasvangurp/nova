"""Single-chunk exact BoltzGen scorer with per-step timing.

Runs the SAME path the validator uses (BoltzgenWrapper.run_nanobody_inference)
on an isolated tmp dir, on one GPU, and records:
  * wall time for the whole chunk
  * the per-step times BoltzGen itself prints
  * the full metric vector per sequence

Isolation mirrors score_boltzgen_batch.py: BOLTZGEN_TMP_FILES_DIR is a module
global that __init__ copies into self.tmp_dir, so it is rebound BEFORE the
wrapper is constructed and the wrapper attributes are overwritten afterwards.
"""
from __future__ import annotations
import argparse, json, os, shutil, sys, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sequences", required=True)
    ap.add_argument("--config", default="/root/config/config.yaml")
    ap.add_argument("--target", default="P20809")
    ap.add_argument("--gpu", default="0")
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--label", default="baseline")
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = str(a.gpu)

    sys.path.insert(0, "/root")
    from score_boltzgen_batch import _flatten_config
    import yaml
    subnet_config = _flatten_config(yaml.safe_load(open(a.config)), a.target)

    raw = json.load(open(a.sequences))
    items = raw if isinstance(raw, list) else (raw.get("cases") or raw.get("sequences") or [])
    seqs = [it["sequence"] if isinstance(it, dict) else it for it in items]
    seqs = [s for s in seqs if isinstance(s, str) and s]
    if not seqs:
        raise SystemExit("no sequences")

    import boltzgen.boltzgen_wrapper as bw
    shutil.rmtree(a.workdir, ignore_errors=True)
    os.makedirs(os.path.join(a.workdir, "inputs"), exist_ok=True)
    os.makedirs(os.path.join(a.workdir, "outputs"), exist_ok=True)
    bw.BOLTZGEN_TMP_FILES_DIR = a.workdir
    w = bw.BoltzgenWrapper()
    w.tmp_dir = a.workdir
    w.input_dir = os.path.join(a.workdir, "inputs")
    w.output_dir = os.path.join(a.workdir, "outputs")

    t0 = time.time()
    comps = w.run_nanobody_inference({0: {"sequences": seqs}}, subnet_config)
    wall = time.time() - t0

    json.dump({"label": a.label, "gpu": a.gpu, "n": len(seqs),
               "wall_seconds": wall, "seconds_per_seq": wall / len(seqs),
               "components": comps}, open(a.out, "w"), indent=2, default=str)
    print(f"BENCH {a.label}: {len(seqs)} seqs in {wall:.1f}s = {wall/len(seqs):.2f}s/seq", flush=True)
    if not a.keep:
        shutil.rmtree(a.workdir, ignore_errors=True)

if __name__ == "__main__":
    main()
