"""Dump the dtypes/shapes the confidence module actually sees. CPU only."""
import sys, hydra
from omegaconf import OmegaConf
sys.path.insert(0, "/root/fastscore")
cfg = OmegaConf.load(sys.argv[1])
OmegaConf.update(cfg, "data.design_dir", sys.argv[2], merge=False)
data = hydra.utils.instantiate(cfg.data)
data.setup("predict")
dl = data.predict_dataloader()
b = next(iter(dl))
for k in ["design_mask", "chain_design_mask", "asym_id", "atom_to_token",
          "atom_pad_mask", "token_pad_mask", "mol_type", "coords", "id"]:
    v = b.get(k)
    print(f"{k:20s} {type(v).__name__:12s} "
          f"{getattr(v,'dtype',None)} {getattr(v,'shape',len(v) if v is not None else None)}")
print("n tokens per design:", b["token_pad_mask"].sum(-1).tolist())
print("n atoms  per design:", b["atom_pad_mask"].sum(-1).tolist())
print("ids:", b["id"])
