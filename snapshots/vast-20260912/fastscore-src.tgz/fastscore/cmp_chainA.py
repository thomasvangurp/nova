"""Compare the TARGET chain's geometry across design-stage settings.

The folding step consumes the design .cif only as an SE(3)-invariant template
of the target chain, so what has to survive a cheaper design stage is the
target's INTERNAL geometry, not its placement. CA-CA distance matrices are
invariant to the arbitrary global frame each diffusion run lands in.

Every design is compared, matched by filename across directories -- an earlier
version of this script compared only the first file in each directory, which is
a single design and says nothing about spread.

Reference bar: four INDEPENDENT 500-step designs agree with each other to
0.13 A, and agree with the 6O4O crystal chain A to 0.15-0.19 A. A cheaper
setting has to stay inside that band.
"""
from __future__ import annotations
import argparse, glob, itertools, os
import numpy as np


def ca_coords(cif_path: str, asym: str = "A") -> np.ndarray:
    cols: list[str] = []
    out = []
    for line in open(cif_path):
        s = line.strip()
        if s.startswith("_atom_site."):
            cols.append(s.split(".", 1)[1])
            continue
        if not line.startswith(("ATOM", "HETATM")):
            continue
        f = line.split()
        i = {n: k for k, n in enumerate(cols)}
        if f[i["label_asym_id"]] != asym or f[i["label_atom_id"]] != "CA":
            continue
        out.append([float(f[i["Cartn_x"]]), float(f[i["Cartn_y"]]),
                    float(f[i["Cartn_z"]])])
    return np.asarray(out)


def dmat(x: np.ndarray) -> np.ndarray:
    return np.linalg.norm(x[:, None, :] - x[None, :, :], axis=-1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dirs", nargs="+")
    ap.add_argument("--asym", default="A")
    ap.add_argument("--ref", default=None, help="reference dir (default: first)")
    a = ap.parse_args()

    per_dir: dict[str, dict[str, np.ndarray]] = {}
    for d in a.dirs:
        per_dir[d] = {}
        for p in sorted(glob.glob(os.path.join(d, "*.cif"))):
            per_dir[d][os.path.basename(p)] = dmat(ca_coords(p, a.asym))
        print(f"{os.path.basename(d):12s}: {len(per_dir[d])} designs, "
              f"{int(np.sqrt(next(iter(per_dir[d].values())).size))} CA")

    ref = a.ref or a.dirs[0]

    print(f"\n--- WITHIN {os.path.basename(ref)}: independent designs vs each "
          f"other (this is the noise floor) ---")
    names = sorted(per_dir[ref])
    for na, nb in itertools.combinations(names, 2):
        d = np.abs(per_dir[ref][na] - per_dir[ref][nb])
        print(f"  {na[:12]} vs {nb[:12]}   max {d.max():6.3f} A  rms {np.sqrt((d**2).mean()):6.3f} A")

    print(f"\n--- EACH SETTING vs {os.path.basename(ref)}, matched per design ---")
    print(f"{'setting':12s} {'n':>3s} {'max|dD| (per design)':>34s} {'worst':>8s} {'mean rms':>9s}")
    for d in a.dirs:
        if d == ref:
            continue
        maxes, rmss = [], []
        for name in names:
            if name not in per_dir[d]:
                continue
            diff = np.abs(per_dir[ref][name] - per_dir[d][name])
            maxes.append(diff.max())
            rmss.append(np.sqrt((diff**2).mean()))
        shown = " ".join(f"{m:6.3f}" for m in maxes)
        print(f"{os.path.basename(d):12s} {len(maxes):3d} {shown:>34s} "
              f"{max(maxes):8.3f} {np.mean(rmss):9.3f}")


if __name__ == "__main__":
    main()
