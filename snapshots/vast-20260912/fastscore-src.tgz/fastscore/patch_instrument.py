"""Add opt-in timing instrumentation to the SHADOW boltzgen tree.

Gated on BGEN_PROFILE so the instrumented tree stays byte-equivalent in
behaviour when the variable is unset -- an A/B where the "fast" tree also
carries always-on timing code would measure the instrumentation.

Two probes:
  Boltz.forward          -> trunk / structure-module / confidence split
  AtomDiffusion.sample   -> the 200-step denoise loop in isolation
Both use CUDA events, because wall-clock around an async launch queue
attributes the wait to whichever python line happens to synchronise.
"""
import re, sys, pathlib

SRC = pathlib.Path("/root/fastscore/bgen_fast/src/boltzgen")

PROBE = 
