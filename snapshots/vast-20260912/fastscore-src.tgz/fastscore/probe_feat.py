"""Featurize a design .cif through the FOLDING dataset and report atom counts.

Two design outputs with byte-identical atom identity and identical .npz
sidecars fold to different atom counts (2272 vs 2247). 2272 is 2247 rounded up
to the 32-atom window; 2247 is unpadded. Something is taking a different branch
in process_atom_features, so print what the dataset actually produces rather
than reasoning about which flag it might be.
"""
from __future__ import annotations
import sys
from pathlib import Path

import hydra
from omegaconf import OmegaConf


def main():
    cfg_path, *design_dirs = sys.argv[1:]
    base = OmegaConf.load(cfg_path)

    for d in design_dirs:
        cfg = base.copy()
        OmegaConf.update(cfg, "data.design_dir", d, merge=False)
        OmegaConf.update(cfg, "output", d, merge=False)
        dm = hydra.utils.instantiate(cfg.data)
        dm.setup("predict")
        ds = dm.predict_set
        print(f"\n{d}  ({len(ds)} items)")
        for k in ("atom14", "atom37", "max_atoms", "disulfide_on", "disulfide_prob"):
            print(f"    cfg.{k:14s} = {getattr(ds.cfg, k, '<absent>')}"
                  if hasattr(ds, "cfg") else f"    (no ds.cfg)")
        feat = ds[0]
        for key in ("ref_pos", "atom_pad_mask", "atom_resolved_mask",
                    "token_pad_mask", "atom_to_token"):
            v = feat.get(key)
            if v is not None:
                print(f"    {key:20s} {tuple(v.shape)}")


if __name__ == "__main__":
    main()
