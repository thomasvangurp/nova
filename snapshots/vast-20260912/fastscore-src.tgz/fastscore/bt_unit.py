"""CPU equivalence tests for the batched-confidence rewrites.

Two properties per rewrite:
  (a) at batch 1 it reproduces the ORIGINAL expression bit-for-bit -- the
      correctness bar is "batch N matches batch 1", so a rewrite that drifts
      at batch 1 has already failed;
  (b) at batch N, row b equals the batch-1 answer for design b, whatever the
      other rows contain.
"""
import torch
torch.manual_seed(0)

fails = []
def check(name, ok, extra=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name} {extra}")
    if not ok:
        fails.append(name)


# ---------------------------------------------------------------- interact
def orig_interact(x_preds, feats):
    x_pred_half = x_preds.float()
    interact_mask = torch.zeros_like(feats["design_mask"])
    atom_chain_design_mask = (torch.bmm(feats["atom_to_token"].float(),
        feats["chain_design_mask"].float().unsqueeze(-1)).squeeze(-1).bool())
    x_target = x_pred_half[~atom_chain_design_mask]
    x_design = x_pred_half[atom_chain_design_mask]
    dists = torch.cdist(x_target, x_design)
    atom_interact_mask = torch.zeros_like(atom_chain_design_mask)
    atom_interact_mask[atom_chain_design_mask] = (dists.min(0)[0] < 8).unsqueeze(0)
    index = torch.argmax(feats["atom_to_token"].int(), dim=-1)
    interact_mask.scatter_(dim=1, index=index, src=atom_interact_mask)
    return interact_mask


def new_interact(x_preds, feats, multiplicity=1):
    x_pred_half = x_preds.float()
    interact_mask = torch.zeros_like(
        feats["design_mask"].repeat_interleave(multiplicity, 0))
    atom_pad_mask = feats["atom_pad_mask"].bool()
    atom_is_design = (torch.bmm(feats["atom_to_token"].float(),
        feats["chain_design_mask"].float().unsqueeze(-1)).squeeze(-1).bool()) & atom_pad_mask
    atom_is_target = (~atom_is_design) & atom_pad_mask
    if atom_is_design.any() and atom_is_target.any():
        def _compact(sel):
            width = int(sel.sum(dim=1).max().item())
            idx = sel.int().argsort(dim=1, descending=True, stable=True)[:, :width]
            return idx.repeat_interleave(multiplicity, 0), sel.gather(1, idx)
        design_idx, design_ok = _compact(atom_is_design)
        target_idx, target_ok = _compact(atom_is_target)
        design_ok = design_ok.repeat_interleave(multiplicity, 0)
        target_ok = target_ok.repeat_interleave(multiplicity, 0)
        def _gather(idx):
            return x_pred_half.gather(1, idx.unsqueeze(-1).expand(-1, -1, 3))
        dists = torch.cdist(_gather(target_idx), _gather(design_idx))
        dists = dists.masked_fill(~target_ok.unsqueeze(-1), torch.inf)
        close = (dists.amin(dim=1) < 8) & design_ok
        atom_interact_mask = torch.zeros_like(
            atom_is_design.repeat_interleave(multiplicity, 0)
        ).scatter_(dim=1, index=design_idx, src=close)
        num_tokens = interact_mask.shape[1]
        index = torch.argmax(feats["atom_to_token"].int(), dim=-1)
        index = torch.where(atom_pad_mask, index, num_tokens).repeat_interleave(multiplicity, 0)
        interact_mask = (torch.zeros(index.shape[0], num_tokens + 1, dtype=torch.bool,
            device=index.device).scatter_(dim=1, index=index, src=atom_interact_mask)
            [:, :num_tokens].to(interact_mask.dtype))
    return interact_mask


def make_design(n_tok, atoms_per_tok, n_design_tok, scale=6.0, pad_to_tok=None, pad_to_atom=None):
    """A toy design: n_design_tok design tokens then target tokens."""
    counts = torch.randint(2, atoms_per_tok + 1, (n_tok,))
    n_atom = int(counts.sum())
    a2t = torch.zeros(n_atom, n_tok)
    r = 0
    for t, c in enumerate(counts):
        a2t[r:r + c, t] = 1
        r += c
    design_mask = torch.zeros(n_tok, dtype=torch.bool); design_mask[:n_design_tok] = True
    chain_design = design_mask.clone()
    coords = torch.randn(n_atom, 3) * scale
    feats = dict(atom_to_token=a2t, chain_design_mask=chain_design,
                 design_mask=design_mask, atom_pad_mask=torch.ones(n_atom))
    return feats, coords, n_tok, n_atom


def pad_stack(items, mult):
    """Collate like boltzgen's pad_to_max, then expand to batch*multiplicity."""
    T = max(i[2] for i in items); A = max(i[3] for i in items)
    feats = {}
    for k in ["atom_to_token", "chain_design_mask", "design_mask", "atom_pad_mask"]:
        rows = []
        for f, c, t, a in items:
            v = f[k]
            if k == "atom_to_token":
                p = torch.zeros(A, T); p[:a, :t] = v.float()
            elif k == "atom_pad_mask":
                p = torch.zeros(A); p[:a] = v
            else:
                p = torch.zeros(T, dtype=v.dtype); p[:t] = v
            rows.append(p)
        feats[k] = torch.stack(rows)
    xs = []
    for f, c, t, a in items:
        p = torch.randn(A, 3) * 6.0   # padded slots hold junk, as the sampler leaves them
        p[:a] = c
        xs.append(p)
    x = torch.stack(xs).repeat_interleave(mult, 0)
    # give each sample its own coordinates so per-sample behaviour is exercised
    x = x + torch.randn_like(x) * 0.3
    return feats, x


items = [make_design(40, 5, 12), make_design(40, 5, 12),
         make_design(31, 5, 9), make_design(37, 4, 15)]

# (a) batch 1, multiplicity 1: new == original
ok = True
for it in items:
    f1, x1 = pad_stack([it], 1)
    ok &= torch.equal(orig_interact(x1, f1), new_interact(x1, f1, 1))
check("interact_mask: batch1 == original", ok)

# (b) uniform-length batch of 2 identical-shape designs, mult 3
for mult in (1, 3):
    f4, x4 = pad_stack(items[:2], mult)
    got = new_interact(x4, f4, mult)
    ref = []
    for b in range(2):
        f1 = {k: v[b:b+1] for k, v in f4.items()}
        x1 = x4[b*mult:(b+1)*mult]
        ref.append(new_interact(x1, f1, mult))
    check(f"interact_mask: batch2 rows == alone (mult={mult})",
          torch.equal(got, torch.cat(ref, 0)))

# (c) MIXED lengths, mult 2 -- the padding path
mult = 2
fm, xm = pad_stack(items, mult)
got = new_interact(xm, fm, mult)
ref = []
for b, it in enumerate(items):
    f1, _ = pad_stack([it], mult)
    t, a = it[2], it[3]
    f1 = {k: (fm[k][b:b+1, :a, :t] if k == "atom_to_token" else
              fm[k][b:b+1, :a] if k == "atom_pad_mask" else fm[k][b:b+1, :t])
          for k in fm}
    x1 = xm[b*mult:(b+1)*mult, :a]
    r = new_interact(x1, f1, mult)
    pad = torch.zeros(mult, fm["design_mask"].shape[1], dtype=r.dtype)
    pad[:, :t] = r
    ref.append(pad)
check("interact_mask: MIXED-length batch rows == alone",
      torch.equal(got, torch.cat(ref, 0)))

# (d) composition independence: same design, different partners
mult = 2
a_alone = None
for partners in ([0], [0, 1, 2], [0, 3]):
    sub = [items[p] for p in partners]
    f, x = pad_stack(sub, mult)
    # force design 0's coordinates identical across compositions
    torch.manual_seed(99)
    f0, x0 = pad_stack([items[0]], mult)
    a = items[0][3]
    x[:mult, :a] = x0[:, :a]
    got = new_interact(x, f, mult)[:mult, :items[0][2]]
    if a_alone is None:
        a_alone = got
    else:
        check(f"interact_mask: design0 with partners {partners} unchanged",
              torch.equal(a_alone, got))


# (e) the bug this replaces: the original mixes designs in one distance matrix
mult = 1
f2, x2 = pad_stack(items[:2], mult)
try:
    contaminated = orig_interact(x2, f2)
    solo = torch.cat([new_interact(x2[b:b+1], {k: v[b:b+1] for k, v in f2.items()}, 1)
                      for b in range(2)], 0)
    check("ORIGINAL at batch 2 disagrees with per-design (the bug)",
          not torch.equal(contaminated, solo),
          f"differing tokens={int((contaminated != solo).sum())}")
except RuntimeError as e:
    check("ORIGINAL at batch 2 raises", True, f"({e})")


# ------------------------------------------------- slots_to_atoms (dead branch)
def orig_slots(logits, feats, max_atoms):
    from torch.nn.functional import pad
    B, N, _ = logits.shape
    lg = logits.reshape(B, N, max_atoms, -1)
    ar = torch.arange(max_atoms).reshape(1, 1, -1)
    m = feats["atom_to_token"].sum(1).unsqueeze(-1) > ar
    lg = lg[:, m.squeeze(0)]
    return pad(lg, (0, 0, 0, int(feats["atom_pad_mask"].shape[1] - feats["atom_pad_mask"].sum().item())), value=0)


def new_slots(logits, feats, max_atoms, multiplicity=1):
    BM, N, _ = logits.shape
    ar = torch.arange(max_atoms).reshape(1, 1, -1)
    slot_mask = ((feats["atom_to_token"].sum(1).unsqueeze(-1) > ar)
                 .repeat_interleave(multiplicity, 0).flatten(1))
    atom_slot = slot_mask.cumsum(1) - 1
    num_atoms = feats["atom_pad_mask"].shape[1]
    rows = torch.arange(BM).unsqueeze(-1).expand_as(atom_slot)
    flat = logits.reshape(BM, N, max_atoms, -1).flatten(1, 2)
    out = flat.new_zeros(BM, num_atoms, flat.shape[-1])
    out[rows[slot_mask], atom_slot[slot_mask]] = flat[slot_mask]
    return out


MA = 5
f1, _ = pad_stack([items[0]], 1)
N = f1["design_mask"].shape[1]
lg = torch.randn(1, N, MA * 2)
check("slots_to_atoms: batch1 == original",
      torch.equal(orig_slots(lg, f1, MA), new_slots(lg, f1, MA, 1)))

fm2, _ = pad_stack(items, 1)
Nm = fm2["design_mask"].shape[1]
lgm = torch.randn(4, Nm, MA * 2)
got = new_slots(lgm, fm2, MA, 1)
ok = True
for b, it in enumerate(items):
    t, a = it[2], it[3]
    f1b = {"atom_to_token": fm2["atom_to_token"][b:b+1, :a, :t],
           "atom_pad_mask": fm2["atom_pad_mask"][b:b+1, :a]}
    r = orig_slots(lgm[b:b+1, :t], f1b, MA)
    ok &= torch.equal(got[b:b+1, :a], r)
check("slots_to_atoms: MIXED-length rows == alone", ok)


# ------------------------------------------------------------- min reductions
pae = torch.rand(4, 12, 12) * 30
msk = (torch.rand(4, 12, 12) > 0.5).float()
new_min = (pae + (1 - msk) * 100000).amin(dim=(1, 2))
ok = all(torch.equal(torch.min(pae[b:b+1] + (1 - msk[b:b+1]) * 100000)[None],
                     new_min[b:b+1]) for b in range(4))
check("min pae: per-row amin == batch1 torch.min", ok)
check("min pae: old global min collapses the batch",
      len(set(torch.min(pae + (1 - msk) * 100000)[None].tolist())) == 1
      and len(set(new_min.tolist())) == 4)


# ------------------------------------------------------------- writer helpers
def _split_design(value, b, n_designs, n_samples):
    shape = getattr(value, "shape", None)
    if not shape:
        return value
    if shape[0] == n_designs * n_samples:
        return value.reshape(n_designs, n_samples, *shape[1:])[b]
    if shape[0] == n_designs:
        return value[b:b+1]
    return value

B, M = 4, 5
conf = torch.arange(B * M).float()          # design-major repeat_interleave order
feat = torch.arange(B).float()[:, None]
check("_split_design: BM rows", all(
    torch.equal(_split_design(conf, b, B, M), torch.arange(b*M, (b+1)*M).float())
    for b in range(B)))
check("_split_design: B rows", all(
    torch.equal(_split_design(feat, b, B, M), feat[b:b+1]) for b in range(B)))
check("_split_design: batch1 identity",
      torch.equal(_split_design(torch.arange(M).float(), 0, 1, M), torch.arange(M).float()))

print()
print("FAILURES:", fails if fails else "none")
raise SystemExit(1 if fails else 0)
