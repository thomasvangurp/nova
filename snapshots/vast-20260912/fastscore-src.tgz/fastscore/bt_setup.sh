#!/bin/bash
# Build the design-dir layout for the batching experiments.
# Every run needs its OWN design_dir because the folding writer writes
# fold_out_npz/ and refold_cif/ inside design_dir.
set -e
SRC=/root/fastscore/work_base4/outputs/intermediate_designs
ROOT=/root/fastscore/bt
rm -rf $ROOT
mkdir -p $ROOT

i=0
for f in $SRC/*_input.cif; do
  b=$(basename $f _input.cif)
  NAMES[$i]=$b
  i=$((i+1))
done
echo "designs: ${NAMES[@]}" | tr ' ' '\n'

# label them A B C D by order
L=(A B C D)
mkdir -p $ROOT/pool
for i in 0 1 2 3; do
  cp $SRC/${NAMES[$i]}_input.cif $ROOT/pool/${L[$i]}.cif
  cp $SRC/${NAMES[$i]}_input.npz $ROOT/pool/${L[$i]}.npz
done
ls -la $ROOT/pool
