"""Geometry and parse sanity for a synthesized design .cif.

Three things can go wrong that folding will not report as an error:
  * a residue missing a CCD atom -- the parser silently sets is_present=False
    and zeroes the coordinate, which is the failure mode that sank the
    backbone-only attempt;
  * degenerate geometry -- coincident or collinear atoms send the KDTree radius
    query and the frame construction down a different path;
  * a sequence table that disagrees with the ATOM records -- an assert, but only
    once folding is already running.

So check all three directly, and additionally run boltzgen's own parser.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from synth_fullatom import (CifDoc, REF_ATOMS, TemplateLibrary, read_residues,
                            sequence_of, THREE_TO_ONE)

# bonds created by grafting (everything else is copied rigidly and therefore
# has exactly the template's / reference's own internal geometry)
GRAFT_BONDS = {t: [("CA", REF_ATOMS[t][4])] for t in REF_ATOMS if len(REF_ATOMS[t]) > 4}
GRAFT_BONDS["PRO"].append(("N", "CD"))


def coverage(paths):
    print("=== template library coverage ===")
    per = {}
    for p in paths:
        doc = CifDoc(Path(p).read_text())
        for res in read_residues(doc, Path(p).name):
            per.setdefault(res.asym, {}).setdefault(res.name, 0)
            per[res.asym][res.name] += 1
    types = [t for t in sorted(REF_ATOMS) if len(REF_ATOMS[t]) > 4]
    print(f"{'type':5s} {'chainA':>7s} {'chainB':>7s} {'total':>7s}")
    for t in types:
        a, b = per.get("A", {}).get(t, 0), per.get("B", {}).get(t, 0)
        flag = "  <-- MISSING" if a + b == 0 else ""
        print(f"{t:5s} {a:7d} {b:7d} {a+b:7d}{flag}")
    missA = [t for t in types if per.get("A", {}).get(t, 0) == 0]
    missB = [t for t in types if per.get("B", {}).get(t, 0) == 0]
    print(f"types absent from chain A: {missA or 'none'}")
    print(f"types absent from chain B: {missB or 'none'}")
    for p in paths:
        lib = TemplateLibrary.from_cifs([Path(q) for q in paths],
                                        exclude_source=Path(p).name)
        m = lib.missing()
        print(f"leave-one-out excluding {Path(p).name[:12]}: "
              f"{sum(lib.coverage().values())} templates, missing {m or 'none'}")


def geometry(cif: Path, asym: str = "B"):
    doc = CifDoc(cif.read_text())
    res = read_residues(doc, cif.name, asym=asym)
    seq = sequence_of(cif, asym)

    print(f"=== {cif.name} chain {asym}: {len(res)} residues ===")

    # 1. atom sets vs the CCD list the parser walks
    bad_count, bad_name, bad_dup = [], [], []
    for i, r in enumerate(res):
        want = REF_ATOMS.get(r.name)
        if want is None:
            bad_name.append((i, r.name)); continue
        if len(r.names) != len(set(r.names)):
            bad_dup.append((i, r.name))
        if sorted(r.names) != sorted(want):
            bad_count.append((i, r.name, len(r.names), len(want),
                              sorted(set(want) - set(r.names)),
                              sorted(set(r.names) - set(want))))
    print(f"residues with wrong atom set : {len(bad_count)}")
    for b in bad_count[:5]:
        print(f"   idx {b[0]} {b[1]}: have {b[2]} want {b[3]} missing={b[4]} extra={b[5]}")
    print(f"residues with duplicate atoms: {len(bad_dup)}")
    n_atoms = sum(len(r.names) for r in res)
    want_atoms = sum(len(REF_ATOMS[r.name]) for r in res)
    print(f"chain {asym} atoms: {n_atoms} (CCD expects {want_atoms})")

    # 2. sequence tables agree with the ATOM records
    atom_seq = "".join(THREE_TO_ONE[r.name] for r in res)
    print(f"_entity_poly == ATOM comp_ids : {atom_seq == seq}")
    eps_e = doc.col("_entity_poly_seq", "entity_id")
    eps_m = doc.col("_entity_poly_seq", "mon_id")
    ent = None
    ca_id, ca_e = doc.col("_struct_asym", "id"), doc.col("_struct_asym", "entity_id")
    for r in doc.rows("_struct_asym"):
        if r[ca_id] == asym:
            ent = r[ca_e]
    eps = [r[eps_m] for r in doc.rows("_entity_poly_seq") if r[eps_e] == ent]
    print(f"_entity_poly_seq == ATOM      : {eps == [r.name for r in res]}")

    # 3. bond lengths
    def d(a, b):
        return float(np.linalg.norm(a - b))

    stats = {}
    for i, r in enumerate(res):
        for nm, pair in (("N-CA", ("N", "CA")), ("CA-C", ("CA", "C")),
                         ("C-O", ("C", "O"))):
            p, q = r.get(pair[0]), r.get(pair[1])
            if p is not None and q is not None:
                stats.setdefault(nm, []).append(d(p, q))
        for a, b in GRAFT_BONDS.get(r.name, []):
            p, q = r.get(a), r.get(b)
            if p is not None and q is not None:
                stats.setdefault(f"graft {a}-{b}", []).append(d(p, q))
        if i + 1 < len(res):
            p, q = r.get("C"), res[i + 1].get("N")
            if p is not None and q is not None:
                stats.setdefault("C-N(i+1)", []).append(d(p, q))
    print(f"{'bond':16s} {'n':>4s} {'min':>7s} {'mean':>7s} {'max':>7s}")
    for nm in sorted(stats):
        v = np.array(stats[nm])
        print(f"{nm:16s} {len(v):4d} {v.min():7.3f} {v.mean():7.3f} {v.max():7.3f}")

    # 4. degeneracy / clashes over the WHOLE model, chain A included
    all_res = read_residues(doc, cif.name)
    xyz = np.concatenate([r.coords() for r in all_res])
    owner = np.concatenate([np.full(len(r.names), i) for i, r in enumerate(all_res)])
    # pairwise over ~2250 atoms is 5M distances: fine, and avoids a KD-tree dep
    D = np.linalg.norm(xyz[:, None, :] - xyz[None, :, :], axis=-1)
    np.fill_diagonal(D, np.inf)
    print(f"all-atom min pairwise distance: {D.min():.3f} A "
          f"(coincident pairs <0.5 A: {int((D < 0.5).sum() // 2)})")
    nonlocal_mask = np.abs(owner[:, None] - owner[None, :]) > 1
    Dn = np.where(nonlocal_mask, D, np.inf)
    for cut in (1.5, 2.0, 2.5):
        print(f"  non-adjacent-residue contacts < {cut} A: {int((Dn < cut).sum() // 2)}")

    # 5. collinearity of every backbone frame
    ang = []
    for r in res:
        n, ca, c = r.get("N"), r.get("CA"), r.get("C")
        if n is None or ca is None or c is None:
            continue
        u, v = n - ca, c - ca
        ang.append(np.degrees(np.arccos(np.clip(
            u @ v / (np.linalg.norm(u) * np.linalg.norm(v)), -1, 1))))
    ang = np.array(ang)
    print(f"N-CA-C angle: min {ang.min():.1f} mean {ang.mean():.1f} max {ang.max():.1f} deg")

    ok = (not bad_count and not bad_dup and not bad_name and atom_seq == seq
          and eps == [r.name for r in res] and D.min() > 0.5)
    print(f"VERDICT: {'PASS' if ok else 'FAIL'}")
    return ok


def parse_check(cif: Path, moldir: str):
    from boltzgen.data.mol import load_canonicals
    from boltzgen.data.parse import mmcif
    mols = load_canonicals(moldir)
    st = mmcif.parse_mmcif(cif, mols, moldir=moldir, use_original_res_idx=False).data
    present = np.asarray([a["is_present"] for a in st.atoms])
    print(f"boltzgen parse OK: {len(st.atoms)} atoms, "
          f"{int((~present).sum())} not present, {len(st.chains)} chains")
    for ch in st.chains:
        s, n = ch["atom_idx"], ch["atom_num"]
        print(f"  chain {ch['name']}: {n} atoms, "
              f"{int((~present[s:s+n]).sum())} not present")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--coverage", nargs="+")
    ap.add_argument("--geometry", nargs="+")
    ap.add_argument("--parse", nargs="+")
    ap.add_argument("--moldir", default=None)
    a = ap.parse_args()
    if a.coverage:
        coverage(a.coverage)
    ok = True
    for f in a.geometry or []:
        ok &= geometry(Path(f))
        print()
    for f in a.parse or []:
        parse_check(Path(f), a.moldir)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
