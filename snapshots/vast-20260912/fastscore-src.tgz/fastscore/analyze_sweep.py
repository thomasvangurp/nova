"""Turn the sampler-budget sweep into the numbers that decide the trade.

Three questions, in the order they matter:

1. COST      seconds per design at each setting.
2. BIAS      does the setting shift scores systematically? Fewer diffusion
             samples must, because the reported score is a MAX over samples
             (analyze_utils.get_best_folding_sample), so this is expected and
             the size of it is what matters.
3. PRECISION spread across repeats at fixed settings -- and then the figure of
             merit, standard error per GPU-second. A cheaper, noisier scorer
             WINS if you can average enough of its draws in the same time:
             se_per_sqrt_gpu_second = sd / sqrt(1/seconds) = sd * sqrt(seconds).
             Lower is better. This is the number that decides whether a reduced
             budget buys real throughput or just a worse estimate.

4. RANKING   Spearman of each setting's per-design scores against the reference
             setting. With only a handful of designs this is indicative, not
             conclusive, and is labelled as such.
"""
from __future__ import annotations
import argparse, itertools, json
from collections import defaultdict

import numpy as np

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    d = np.sqrt((ra**2).sum() * (rb**2).sum())
    return float((ra * rb).sum() / d) if d else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sweep_json")
    ap.add_argument("--ref", default="200x5")
    a = ap.parse_args()

    rows = json.load(open(a.sweep_json))
    by_setting = defaultdict(list)
    for r in rows:
        rec = r.get("recycles")
        key = f"{r['steps']}x{r['samples']}" + (f"x{rec}" if rec is not None else "")
        by_setting[key].append(r)

    settings = sorted(by_setting, key=lambda s: -np.mean([r["seconds"] for r in by_setting[s]]))
    ref = a.ref

    print(f"{len(rows)} observations, {len(settings)} settings, "
          f"reference = {ref}\n")

    # ---- cost ------------------------------------------------------------
    print(f"{'setting':10s} {'s/design':>9s} {'speedup':>8s}   n")
    ref_s = np.mean([r["seconds"] for r in by_setting[ref]])
    for s in settings:
        sec = np.mean([r["seconds"] for r in by_setting[s]])
        print(f"{s:10s} {sec:9.2f} {ref_s/sec:7.2f}x  {len(by_setting[s]):3d}")
    print()

    # ---- bias, precision, and precision per unit compute -----------------
    for key in KEYS:
        print(f"--- {key} ---")
        print(f"{'setting':10s} {'mean':>9s} {'bias':>9s} "
              f"{'sd(rep)':>9s} {'sd*sqrt(s)':>11s} {'rho vs ref':>11s}")
        ref_mean = np.mean([r[key] for r in by_setting[ref]])
        # per-design mean at the reference, for the rank comparison
        ref_by_design = defaultdict(list)
        for r in by_setting[ref]:
            ref_by_design[r["design"]].append(r[key])
        designs = sorted(ref_by_design)
        ref_vec = [np.mean(ref_by_design[d]) for d in designs]

        for s in settings:
            vals = [r[key] for r in by_setting[s]]
            # within-design spread across repeats, pooled
            per_design = defaultdict(list)
            for r in by_setting[s]:
                per_design[r["design"]].append(r[key])
            sds = [np.std(v, ddof=1) for v in per_design.values() if len(v) > 1]
            sd = float(np.mean(sds)) if sds else float("nan")
            sec = np.mean([r["seconds"] for r in by_setting[s]])
            vec = [np.mean(per_design[d]) if d in per_design else np.nan for d in designs]
            rho = spearman(ref_vec, vec)
            print(f"{s:10s} {np.mean(vals):9.4f} {np.mean(vals)-ref_mean:+9.4f} "
                  f"{sd:9.4f} {sd*np.sqrt(sec):11.4f} {rho:11.3f}")
        print()

    print("sd*sqrt(s) is the standard error you get per unit of GPU time "
          "(lower is better):\na setting with a larger sd still wins if it is "
          "cheap enough to repeat more often.")
    print(f"NOTE: rho is over only {len(designs)} designs -- indicative, not conclusive.")


if __name__ == "__main__":
    main()
