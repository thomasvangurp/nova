#!/usr/bin/env bash
# Clean serial timing sweep. Nothing else of mine runs during this; the live
# miner still shares the box, so every variant is measured under the same
# conditions and only relative numbers are claimed.
cd /root/fastscore
rm -f batch6.done
export CUDA_VISIBLE_DEVICES=2

for v in B1 B4 B8; do
  rm -rf four_$v && mkdir -p four_$v
  cp work_base4/outputs/intermediate_designs/*.cif work_base4/outputs/intermediate_designs/*.npz four_$v/
done
/usr/bin/python3 mkcfg.py fold_one.yaml fold_B8.yaml \
  design_dir=/root/fastscore/four_B8 output=/root/fastscore/four_B8 \
  matmul_precision=high batch_size=8 num_workers=2 >/dev/null

./fast_python.sh profile_fold.py fold_B1.yaml --seed 909 > run_B1.log 2>&1
./fast_python.sh profile_fold.py fold_B4.yaml --seed 909 > run_B4.log 2>&1
./fast_python.sh profile_fold.py fold_B8.yaml --seed 909 > run_B8.log 2>&1

touch batch6.done
