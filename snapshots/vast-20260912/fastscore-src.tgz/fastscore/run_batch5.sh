#!/usr/bin/env bash
# 1. REPRODUCIBILITY CONTROL, run first because every other A/B depends on it.
#    Same config, same seed, twice. torch.use_deterministic_algorithms is NOT
#    set (it would disable TF32, which is one of the things under test), so
#    non-deterministic reductions may put a floor under every comparison. If
#    R1 vs R2 differs by as much as "TF32 on vs off" did, then that TF32
#    number measured nothing.
# 2. The bf16 sampler, against a matched fp32 run at the same seed.
cd /root/fastscore
rm -f batch5.done
export CUDA_VISIBLE_DEVICES=2

BOLTZGEN_NO_HOIST=1 ./fast_python.sh profile_fold.py fold_R1.yaml --seed 777 > run_R1.log 2>&1
BOLTZGEN_NO_HOIST=1 ./fast_python.sh profile_fold.py fold_R2.yaml --seed 777 > run_R2.log 2>&1

BOLTZGEN_SAMPLER_BF16=1 ./fast_python.sh profile_fold.py fold_F.yaml --seed 4242 > run_F.log 2>&1

./fast_python.sh profile_fold.py fold_B1.yaml --seed 909 > run_B1.log 2>&1
./fast_python.sh profile_fold.py fold_B4.yaml --seed 909 > run_B4.log 2>&1

touch batch5.done
