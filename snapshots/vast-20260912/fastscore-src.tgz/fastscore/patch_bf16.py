"""Run the diffusion sampler's NETWORK in bf16; keep its COORDINATES in fp32.

Motivation, from the kernel profile of one folding call (11.54s CUDA):

    ampere_sgemm_128x64_tn   5.265s  45.6%   70,200 calls
    ampere_bf16_s1688gemm    0.141s   1.2%    3,844 calls

Almost every GEMM in the 200-step loop runs on CUDA cores in fp32. That is not
an accident of shape -- boltz.py wraps the whole sampler in
`torch.autocast("cuda", enabled=False)` and casts its inputs with `.float()`,
so autocast is off for all 1000 network evaluations. Turning it back on moves
those GEMMs to tensor cores and lets SDPA reach a fused kernel (fp32 forces the
cutlass mem-efficient path: fmha_cutlassF_f32_aligned, another 0.835s).

What deliberately stays fp32:
  * the coordinate state itself. 200 sequential update steps accumulate, and
    the update is a small difference of larger numbers; bf16 has 8 mantissa
    bits, so the trajectory -- not the layer arithmetic -- is where precision
    would actually be lost. `r_update` is cast back before it touches coords.
  * `weighted_rigid_align` (already under its own autocast-disable) -- an SVD.

This CHANGES numerics. It is not offered as bit-exact; it is offered against a
measured noise floor. Seed-to-seed on an identical config, the same design
moves design_iiptm 0.353 -> 0.311 and interaction_pae 18.23 -> 19.51, so the
bar a numerics change has to clear is "small compared to that", established by
repeat runs rather than by inspection.

Gated on BOLTZGEN_SAMPLER_BF16=1; off by default.
"""
import pathlib, sys

SRC = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(
    "/root/fastscore/bgen_fast/src/boltzgen")

# ---------------------------------------------------------------- boltz.py
p = SRC / "model/models/boltz.py"
t = p.read_text()
assert "_SAMPLER_BF16" not in t, "already patched"

t = t.replace(
    "class Boltz(LightningModule):",
    'import os as _os\n'
    '_SAMPLER_BF16 = _os.environ.get("BOLTZGEN_SAMPLER_BF16") == "1"\n'
    '_sampler_autocast = (\n'
    '    (lambda: torch.autocast("cuda", dtype=torch.bfloat16, enabled=True))\n'
    '    if _SAMPLER_BF16\n'
    '    else (lambda: torch.autocast("cuda", enabled=False))\n'
    ')\n\n\n'
    "class Boltz(LightningModule):",
    1,
)

old = """                with torch.autocast("cuda", enabled=False):
                    if not self.inverse_fold:
                        struct_out = self.structure_module.sample(
                            s_trunk=s.float(),
                            s_inputs=s_inputs.float(),"""
assert t.count(old) == 1
new = """                with _sampler_autocast():
                    if not self.inverse_fold:
                        struct_out = self.structure_module.sample(
                            s_trunk=s if _SAMPLER_BF16 else s.float(),
                            s_inputs=s_inputs if _SAMPLER_BF16 else s_inputs.float(),"""
t = t.replace(old, new, 1)
p.write_text(t)
print("patched", p)

# ------------------------------------------------------------ diffusion.py
p = SRC / "model/modules/diffusion.py"
t = p.read_text()
assert "_SAMPLER_BF16" not in t

t = t.replace(
    "_HOIST = _os.environ.get(\"BOLTZGEN_NO_HOIST\") != \"1\"",
    "_HOIST = _os.environ.get(\"BOLTZGEN_NO_HOIST\") != \"1\"\n"
    "_SAMPLER_BF16 = _os.environ.get(\"BOLTZGEN_SAMPLER_BF16\") == \"1\"",
    1,
)

# keep the conditioning in bf16 when the network runs in bf16: casting it to
# fp32 only to have autocast cast every matmul input back down is pure traffic
t = t.replace(
    "    out[k] = v.float() if torch.is_tensor(v) and v.is_floating_point() else v",
    "    if torch.is_tensor(v) and v.is_floating_point():\n"
    "            out[k] = v.to(torch.bfloat16) if _SAMPLER_BF16 else v.float()\n"
    "        else:\n"
    "            out[k] = v",
    1,
)
t = t.replace(
    "    out = {}\n    for k, v in cond.items():\n        ",
    "    out = {}\n    for k, v in cond.items():\n        ",
    1,
)

# the coordinate update must stay fp32 regardless of the network's dtype
old = """        denoised_coords = (
            self.c_skip(padded_sigma) * noised_atom_coords
            + self.c_out(padded_sigma) * net_out["r_update"]
        )"""
assert t.count(old) == 1
new = """        # r_update may be bf16 under BOLTZGEN_SAMPLER_BF16; the coordinate
        # trajectory is accumulated over 200 steps and stays fp32.
        _r_update = net_out["r_update"]
        if _r_update.dtype != noised_atom_coords.dtype:
            _r_update = _r_update.to(noised_atom_coords.dtype)

        denoised_coords = (
            self.c_skip(padded_sigma) * noised_atom_coords
            + self.c_out(padded_sigma) * _r_update
        )"""
t = t.replace(old, new, 1)
p.write_text(t)
print("patched", p)

# ------------------------------------------------------------- attention.py
p = SRC / "model/layers/attention.py"
t = p.read_text()
assert "_SAMPLER_BF16" not in t
t = t.replace(
    "class AttentionPairBias(nn.Module):",
    'import os as _os\n'
    '_SAMPLER_BF16 = _os.environ.get("BOLTZGEN_SAMPLER_BF16") == "1"\n\n\n'
    "class AttentionPairBias(nn.Module):",
    1,
)
old = """        with torch.autocast("cuda", enabled=False):
            # Compute attention weights
            o = torch.nn.functional.scaled_dot_product_attention(
                q.float(),
                k.float(),
                v.float(),
                attn_mask=attn_mask,
            )"""
assert t.count(old) == 1
new = """        if _SAMPLER_BF16 and q.dtype == torch.bfloat16:
            # fp32 q/k/v force SDPA onto the cutlass mem-efficient path
            # (fmha_cutlassF_f32_aligned in the profile); bf16 lets it pick a
            # fused kernel. The mask is cast with it so the dtypes agree.
            o = torch.nn.functional.scaled_dot_product_attention(
                q, k, v, attn_mask=attn_mask.to(q.dtype)
            )
        else:
            with torch.autocast("cuda", enabled=False):
                # Compute attention weights
                o = torch.nn.functional.scaled_dot_product_attention(
                    q.float(),
                    k.float(),
                    v.float(),
                    attn_mask=attn_mask,
                )"""
t = t.replace(old, new, 1)
p.write_text(t)
print("patched", p)
