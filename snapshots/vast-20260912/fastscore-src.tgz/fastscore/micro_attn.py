"""Microbenchmark of AttentionPairBias as the diffusion sampler calls it.

Shapes come from the live nanobody job: target P20809 clipped [31,199] (168
tokens) + a 127-residue VHH = 295 tokens, folding step with
diffusion_samples=5, and the Boltz-2 diffusion token transformer.

Four variants, all producing the same attention output:
  base      exactly what attention.py does today
  nobcast   same math, but the per-sample bias is broadcast instead of
            materialised with repeat_interleave  (bit-identical)
  premask   same, and the padding mask is pre-added into the bias once
            instead of every layer of every denoising step (bit-identical)
  bf16      premask, with q/k/v/bias in bf16 so SDPA can pick a fused
            kernel  (NOT bit-identical -- measured against base)
"""
import os, time, torch, torch.nn.functional as F

torch.manual_seed(0)
dev = "cuda"
N, H, D, M, L, STEPS = 295, 16, 48, 5, 24, 200   # tokens, heads, head_dim, samples, layers, steps
INF = 1e6
CS = H * D

def make():
    s = torch.randn(M, N, CS, device=dev)
    z = torch.randn(1, N, N, H, device=dev)          # per-layer slice of token_trans_bias
    mask = torch.ones(M, N, device=dev)
    mask[:, -12:] = 0                                 # some padding, as in a real batch
    return s, z, mask

def qkv(s):
    q = s.view(M, N, H, D).transpose(1, 2)
    return q, q.clone(), q.clone()

def base(s, z, mask):
    q, k, v = qkv(s)
    bias = z.permute(0, 3, 1, 2)                      # Rearrange("b ... h -> b h ...")
    bias = bias.repeat_interleave(M, 0)
    am = (1 - mask[:, None, None].float()) * -INF
    am = am + bias.float()
    with torch.autocast("cuda", enabled=False):
        return F.scaled_dot_product_attention(q.float(), k.float(), v.float(), attn_mask=am)

def nobcast(s, z, mask):
    q, k, v = qkv(s)
    q, k, v = (t.view(1, M, H, N, D) for t in (q, k, v))
    bias = z.permute(0, 3, 1, 2)[:, None]             # [1,1,H,N,N] -> broadcasts over M
    am = (1 - mask[:1, None, None].float())[:, None] * -INF + bias.float()
    with torch.autocast("cuda", enabled=False):
        o = F.scaled_dot_product_attention(q.float(), k.float(), v.float(), attn_mask=am)
    return o.view(M, H, N, D)

def premask(s, z, mask, cached):
    q, k, v = qkv(s)
    q, k, v = (t.view(1, M, H, N, D) for t in (q, k, v))
    with torch.autocast("cuda", enabled=False):
        o = F.scaled_dot_product_attention(q.float(), k.float(), v.float(), attn_mask=cached)
    return o.view(M, H, N, D)

def premask_bf16(s, z, mask, cached16):
    q, k, v = qkv(s)
    q, k, v = (t.view(1, M, H, N, D).bfloat16() for t in (q, k, v))
    o = F.scaled_dot_product_attention(q, k, v, attn_mask=cached16)
    return o.view(M, H, N, D).float()

def timeit(fn, n=30):
    for _ in range(5): fn()
    torch.cuda.synchronize(); t = time.perf_counter()
    for _ in range(n): fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - t) / n * 1e3          # ms per call

s, z, mask = make()
cached = ((1 - mask[:1, None, None].float())[:, None] * -INF + z.permute(0,3,1,2)[:, None].float())
cached16 = cached.bfloat16()

ref = base(s, z, mask)
for name, out in [("nobcast", nobcast(s, z, mask)),
                  ("premask", premask(s, z, mask, cached)),
                  ("bf16",    premask_bf16(s, z, mask, cached16))]:
    d = (out - ref).abs()
    print(f"  {name:8s} max|diff| {d.max().item():.3e}  mean|diff| {d.mean().item():.3e}  "
          f"exact={torch.equal(out, ref)}")

print(f"\nper-call (ms), N={N} H={H} D={D} samples={M}")
tb = timeit(lambda: base(s, z, mask))
tn = timeit(lambda: nobcast(s, z, mask))
tp = timeit(lambda: premask(s, z, mask, cached))
t16 = timeit(lambda: premask_bf16(s, z, mask, cached16))
for n, t in [("base", tb), ("nobcast", tn), ("premask", tp), ("bf16", t16)]:
    print(f"  {n:8s} {t:7.3f} ms   speedup {tb/t:5.2f}x")

print(f"\nextrapolated to one folding call ({L} layers x {STEPS} steps):")
for n, t in [("base", tb), ("nobcast", tn), ("premask", tp), ("bf16", t16)]:
    print(f"  {n:8s} {t*L*STEPS/1000:7.2f} s")
