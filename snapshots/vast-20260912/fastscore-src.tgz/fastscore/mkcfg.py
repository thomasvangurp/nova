"""Derive a folding config variant from a real materialized one.

Rewrites only design_dir/output and any explicitly requested scalar overrides,
so the variant differs from the production config in exactly the ways named on
the command line -- a hand-written config would silently drift from whatever
`boltzgen configure` actually emits.
"""
import sys, pathlib

src, dst = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
overrides = dict(kv.split("=", 1) for kv in sys.argv[3:])

out = []
for line in src.read_text().splitlines():
    stripped = line.strip()
    key = stripped.split(":")[0].strip() if ":" in stripped else None
    if key in overrides:
        indent = line[: len(line) - len(line.lstrip())]
        out.append(f"{indent}{key}: {overrides[key]}")
        del overrides[key]
    else:
        out.append(line)
for k, v in overrides.items():
    out.append(f"{k}: {v}")
dst.write_text("\n".join(out) + "\n")
print(f"wrote {dst}")
