#!/usr/bin/env bash
# Cross synthesis: design i's SEQUENCE grafted onto design (i+1)'s backbone.
# This is the production case -- the reference backbone does not belong to the
# sequence -- and it perturbs chain B far harder than a same-backbone regraft.
# The library omits both the sequence's own design and the backbone donor.
set -euo pipefail
cd /root/fastscore
D=work_base4/outputs/intermediate_designs
mapfile -t F < <(ls $D/*_input.cif)
mkdir -p synth_cross
n=${#F[@]}
for ((i=0;i<n;i++)); do
  j=$(( (i+1) % n ))
  src="${F[$i]}"; ref="${F[$j]}"
  b=$(basename "$src" .cif)
  seq=$(./fast_python.sh -c "
import sys; sys.path.insert(0,'/root/fastscore')
from pathlib import Path
from synth_fullatom import sequence_of
print(sequence_of(Path('$src')))")
  lib=()
  for ((k=0;k<n;k++)); do [[ $k -ne $i && $k -ne $j ]] && lib+=("${F[$k]}"); done
  ./fast_python.sh synth_fullatom.py --ref-cif "$ref" --ref-npz "${ref%.cif}.npz" \
    --sequence "$seq" --out-prefix "synth_cross/$b" --library "${lib[@]}" --seed 4321
done
