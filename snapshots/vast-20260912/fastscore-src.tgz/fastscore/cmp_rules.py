"""Do BoltzGen's two 'best sample' rules pick the same diffusion sample?

There are two, on different metrics:

  writer.py:72          0.8 * iptm                  + 0.2 * ptm
     -> chooses the structure written to refold_cif/, which the analysis step
        uses for plip_hbonds_refolded, plip_saltbridge_refolded,
        delta_sasa_refolded

  analyze_utils.py:98   0.8 * design_to_target_iptm + 0.2 * design_ptm
     -> chooses the sample whose design_iiptm / design_ptm /
        design_to_target_iptm / min_design_to_target_pae / interaction_pae are
        reported

`iptm`/`ptm` are whole-complex; `design_*` are restricted to the designed
chain. When the two rules disagree, a design's ten scored metrics describe two
different structures.
"""
from __future__ import annotations
import glob, sys
import numpy as np

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]

paths = []
for d in sys.argv[1:]:
    paths += sorted(glob.glob(f"{d}/*.npz"))

n_disagree = 0
rows = []
for p in paths:
    f = np.load(p, allow_pickle=True)
    if "iptm" not in f or "design_to_target_iptm" not in f:
        continue
    writer_rule = 0.8 * np.asarray(f["iptm"], float) + 0.2 * np.asarray(f["ptm"], float)
    analyze_rule = (0.8 * np.asarray(f["design_to_target_iptm"], float)
                    + 0.2 * np.asarray(f["design_ptm"], float))
    iw, ia = int(np.argmax(writer_rule)), int(np.argmax(analyze_rule))
    rows.append((p.split("/")[-3] if "/" in p else p, iw, ia,
                 {k: np.asarray(f[k], float) for k in KEYS}))
    n_disagree += iw != ia

print(f"{len(rows)} folding outputs, rules disagree on {n_disagree} "
      f"({100*n_disagree/max(len(rows),1):.0f}%)\n")

print(f"{'run':10s} {'writer':>7s} {'analyze':>8s}   "
      f"{'d_iiptm(a)':>11s} {'d_iiptm(w)':>11s} {'int_pae(a)':>11s} {'int_pae(w)':>11s}")
for run, iw, ia, m in rows:
    flag = "  <-- differ" if iw != ia else ""
    print(f"{run[:10]:10s} {iw:7d} {ia:8d}   "
          f"{m['design_iiptm'][ia]:11.4f} {m['design_iiptm'][iw]:11.4f} "
          f"{m['interaction_pae'][ia]:11.3f} {m['interaction_pae'][iw]:11.3f}{flag}")
