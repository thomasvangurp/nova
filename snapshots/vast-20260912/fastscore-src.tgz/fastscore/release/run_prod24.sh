#!/usr/bin/env bash
# Fast-path arm against the harvested production reference.
#
# 24 sequences that the LIVE production scorer already scored 5-26 times each,
# spanning design_iiptm 0.198-0.788. The reference arm therefore costs no GPU
# time and carries a real per-sequence spread, which is what a stochastic
# scorer comparison needs. 4 fast-path repeats per sequence, fanned across 4
# GPUs within each repeat (never across repeats -- repeats must stay
# independent invocations).
cd /root/fastscore/release
export CUDA_VISIBLE_DEVICES=2,3,5,7
REF=$(ls refdesign/*.cif | head -1)
rm -f prod24.done
for r in 0 1 2 3; do
  rm -rf p24_work_$r
  ./release_python.sh fast_score_batch.py \
    --sequences prod24.json \
    --config /root/config/config.yaml --target P20809 \
    --gpus 0,1,2,3 --shards-per-gpu 1 --batch-size 6 \
    --synth-reference "$REF" \
    --shard-root /root/fastscore/release/p24_work_$r \
    --out /root/fastscore/release/prod24_fast_rep$r.json > prod24_rep$r.log 2>&1
  echo "repeat $r: $(grep -o 'TOTAL.*' prod24_rep$r.log | tail -1)"
done
touch prod24.done
