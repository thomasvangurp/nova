import json, sys
d = json.load(open(sys.argv[1]))
print("top keys:", sorted(d.keys()))
print("scorer_protocol:", d["scorer_protocol"],
      "| predict_batch_size:", d["predict_batch_size"],
      "| observation_id:", d["observation_id"][:12])
structs = d["structures"]
print(f"structures captured for {len(structs)} of {d['n']} sequences")
disagree = 0
first = True
for seq, by_t in structs.items():
    for t, rec in by_t.items():
        s = rec["sample_selection"]
        disagree += bool(s["sample_selection_disagrees"])
        if first:
            print("  record keys:", sorted(rec.keys()))
            print(f"  sample_count={s['sample_count']} "
                  f"writer#{s['writer_sample_index']} "
                  f"analyze#{s['analyze_sample_index']} "
                  f"disagrees={s['sample_selection_disagrees']}")
            print(f"  confidence sha {rec['confidence_sha256'][:16]}")
            print(f"  writer     sha {rec['writer_sha256'][:16]}")
            print(f"  poses differ on disk: "
                  f"{rec['confidence_sha256'] != rec['writer_sha256']}")
            first = False
print(f"the two argmax rules disagreed on {disagree} of {len(structs)} designs")
