"""Equivalence test: production scorer vs the fast scorer, as distributions.

Both arms score the SAME sequence list, N independent repeats each. The scorer
is stochastic and not reproducible even at a fixed seed, so "equivalent" cannot
mean "equal". It means:

  * no SYSTEMATIC shift -- a difference that is small on average but has the
    same sign on nearly every sequence is a bias, and a bias survives averaging
    no matter how many repeats a selector buys;
  * the per-sequence difference is small relative to each arm's own spread;
  * and, because the live selector ranks candidates rather than reading
    absolute values, the two arms RANK the sequences the same.

Reference floors (measured on this box):
  same config, same seed, twice : design_iiptm 0.0048   min_design_to_target_pae 0.175
  different seeds               : design_iiptm ~0.042   min_design_to_target_pae ~1.24

Usage: cmp_arms.py --ref ref*.json --fast fast*.json [--label-a prod --label-b fast]
"""
from __future__ import annotations
import argparse, glob, json
from collections import defaultdict

import numpy as np

METRICS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
           "min_design_to_target_pae", "interaction_pae",
           "plip_hbonds_refolded", "plip_saltbridge_refolded",
           "delta_sasa_refolded", "liability_score", "liability_num_violations"]


def load(paths):
    """-> {sequence: {metric: [values across repeats]}}"""
    out = defaultdict(lambda: defaultdict(list))
    for p in paths:
        d = json.load(open(p))
        comp = d.get("per_nanobody_components", d)
        for _uid, by_seq in comp.items():
            for seq, by_target in by_seq.items():
                for _t, m in by_target.items():
                    for k in METRICS:
                        if k in m and m[k] is not None:
                            out[seq][k].append(float(m[k]))
    return out


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    d = np.sqrt((ra**2).sum() * (rb**2).sum())
    return float((ra * rb).sum() / d) if d else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref", nargs="+", required=True)
    ap.add_argument("--fast", nargs="+", required=True)
    ap.add_argument("--label-a", default="prod")
    ap.add_argument("--label-b", default="fast")
    a = ap.parse_args()

    A = load([p for g in a.ref for p in glob.glob(g)])
    B = load([p for g in a.fast for p in glob.glob(g)])
    seqs = sorted(set(A) & set(B))
    if not seqs:
        raise SystemExit(f"no overlapping sequences ({len(A)} vs {len(B)})")
    only_a, only_b = set(A) - set(B), set(B) - set(A)
    if only_a or only_b:
        print(f"WARNING: {len(only_a)} sequences only in {a.label_a}, "
              f"{len(only_b)} only in {a.label_b}\n")

    nrep_a = len(next(iter(A.values()))[METRICS[0]])
    nrep_b = len(next(iter(B.values()))[METRICS[0]])
    print(f"{len(seqs)} sequences   {a.label_a}: {nrep_a} repeats   "
          f"{a.label_b}: {nrep_b} repeats\n")

    for k in METRICS:
        rows = []
        for s in seqs:
            va, vb = np.array(A[s].get(k, [])), np.array(B[s].get(k, []))
            if len(va) == 0 or len(vb) == 0:
                continue
            sa = va.std(ddof=1) if len(va) > 1 else np.nan
            sb = vb.std(ddof=1) if len(vb) > 1 else np.nan
            pooled = np.sqrt(np.nansum([sa**2, sb**2]) / 2)
            rows.append((s, va.mean(), sa, vb.mean(), sb,
                         vb.mean() - va.mean(),
                         (vb.mean() - va.mean()) / pooled if pooled else np.nan))
        if not rows:
            print(f"--- {k}: absent from one arm ---\n")
            continue
        diffs = np.array([r[5] for r in rows])
        norms = np.array([r[6] for r in rows])
        same_sign = abs(np.sign(diffs).sum()) == len(diffs)
        rho = spearman([r[1] for r in rows], [r[3] for r in rows])
        print(f"--- {k} ---")
        print(f"{'seq':10s} {a.label_a+' mean+-sd':>20s} {a.label_b+' mean+-sd':>20s} "
              f"{'diff':>10s} {'diff/sd':>8s}")
        for s, ma, sa, mb, sb, d, n in rows:
            print(f"{s[:10]:10s} {ma:12.4f}+-{sa:7.4f} {mb:12.4f}+-{sb:7.4f} "
                  f"{d:+10.4f} {n:+8.2f}")
        print(f"{'':10s} mean diff {diffs.mean():+.4f}   "
              f"median |diff|/sd {np.nanmedian(np.abs(norms)):.2f}   "
              f"rho {rho:.3f}   "
              f"all same sign: {'YES  <-- BIAS' if same_sign else 'no'}\n")


if __name__ == "__main__":
    main()
