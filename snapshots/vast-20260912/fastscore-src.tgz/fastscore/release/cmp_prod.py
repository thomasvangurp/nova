"""Fast scorer vs the LIVE production scorer, using production's own history.

The reference arm is harvested from `/root/live/epoch*/**/wave_*_exact.json`:
sequences the unmodified production path already scored 5-26 times each. That
costs no GPU time and, more importantly, carries production's REAL per-sequence
spread -- which is the yardstick, because this scorer is not reproducible even
at a fixed seed.

Three questions, in order of importance for a selector that ranks candidates:

  1. RANK      does the fast path order the sequences the way production does?
  2. BIAS      is there a shift that survives averaging? A small mean difference
               with the SAME SIGN on nearly every sequence is a bias; a larger
               one with mixed signs is noise.
  3. SCALE     is each sequence's difference small relative to PRODUCTION'S OWN
               spread across its repeats? That is the only fair denominator.
"""
from __future__ import annotations
import argparse, glob, json
from collections import defaultdict

import numpy as np

METRICS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
           "min_design_to_target_pae", "interaction_pae",
           "plip_hbonds_refolded", "plip_saltbridge_refolded",
           "delta_sasa_refolded", "liability_score", "liability_num_violations"]


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    d = np.sqrt((ra**2).sum() * (rb**2).sum())
    return float((ra * rb).sum() / d) if d else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reference", required=True, help="harvested production json")
    ap.add_argument("--fast", nargs="+", required=True)
    a = ap.parse_args()

    ref = json.load(open(a.reference))
    fast = defaultdict(lambda: defaultdict(list))
    for g in a.fast:
        for p in sorted(glob.glob(g)):
            d = json.load(open(p))
            for _uid, by_seq in d.get("per_nanobody_components", d).items():
                for seq, by_t in by_seq.items():
                    for _t, m in by_t.items():
                        for k in METRICS:
                            if k in m and m[k] is not None:
                                fast[seq][k].append(float(m[k]))

    seqs = [s for s in ref if s in fast]
    print(f"{len(seqs)} sequences   production: "
          f"{min(ref[s]['design_iiptm']['n'] for s in seqs)}-"
          f"{max(ref[s]['design_iiptm']['n'] for s in seqs)} observations each   "
          f"fast: {len(fast[seqs[0]]['design_iiptm'])} repeats each\n")

    for k in METRICS:
        rows = []
        for s in seqs:
            if k not in ref[s] or k not in fast[s]:
                continue
            pm, ps, pn = ref[s][k]["mean"], ref[s][k]["sd"], ref[s][k]["n"]
            fv = np.array(fast[s][k])
            fm = fv.mean()
            fs = fv.std(ddof=1) if len(fv) > 1 else np.nan
            # production's own spread is the fair denominator
            rows.append((s, pm, ps, pn, fm, fs, fm - pm,
                         (fm - pm) / ps if ps else np.nan))
        if len(rows) < 3:
            print(f"--- {k}: too few ---\n")
            continue
        diffs = np.array([r[6] for r in rows])
        norms = np.array([r[7] for r in rows])
        rho = spearman([r[1] for r in rows], [r[4] for r in rows])
        npos = int((diffs > 0).sum())
        print(f"--- {k} ---")
        print(f"{'seq':10s} {'prod mean+-sd (n)':>26s} {'fast mean+-sd':>20s} "
              f"{'diff':>10s} {'diff/prod_sd':>13s}")
        for s, pm, ps, pn, fm, fs, d, n in rows:
            print(f"{s[:10]:10s} {pm:14.4f}+-{ps:7.4f} ({pn:2d}) "
                  f"{fm:12.4f}+-{fs:7.4f} {d:+10.4f} {n:+13.2f}")
        print(f"{'':10s} rho {rho:.3f}   mean diff {diffs.mean():+.4f}   "
              f"median |diff|/prod_sd {np.nanmedian(np.abs(norms)):.2f}   "
              f"sign split {npos}+/{len(diffs)-npos}-"
              + ("   <-- consistent sign, possible bias" if npos in (0, len(diffs)) else "")
              + "\n")


if __name__ == "__main__":
    main()
