"""The control I omitted: how well does production agree with ITSELF?

Comparing a new scorer to production with a rank correlation is meaningless
without knowing what rho production scores against its own repeats. This
scorer is not reproducible, so that ceiling is well below 1.0 -- reading
"rho 0.85" as degradation, when the ceiling is 0.86, is a mistake.

Production's per-sequence observations are split into two disjoint halves,
many times, to estimate the ceiling at a given averaging depth. The fast arm
is then graded at the SAME depth so the comparison is like-for-like: rho rises
with the number of repeats averaged, so an unmatched depth flatters whichever
side had more.
"""
from __future__ import annotations
import argparse, glob, json, random
from collections import defaultdict

import numpy as np

METRICS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
           "min_design_to_target_pae", "interaction_pae"]


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    d = np.sqrt((ra**2).sum() * (rb**2).sum())
    return float((ra * rb).sum() / d) if d else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reference", required=True)
    ap.add_argument("--fast", nargs="+", required=True)
    ap.add_argument("--depth", type=int, default=2,
                    help="observations averaged per side")
    ap.add_argument("--trials", type=int, default=200)
    a = ap.parse_args()

    ref = json.load(open(a.reference))
    fast = defaultdict(lambda: defaultdict(list))
    for g in a.fast:
        for p in sorted(glob.glob(g)):
            d = json.load(open(p))
            for _u, by in d.get("per_nanobody_components", d).items():
                for s, bt in by.items():
                    for _t, m in bt.items():
                        for k in METRICS:
                            if k in m and m[k] is not None:
                                fast[s][k].append(float(m[k]))

    seqs = [s for s in ref if s in fast]
    rng = random.Random(0)
    print(f"{len(seqs)} sequences, averaging depth {a.depth} per side, "
          f"{a.trials} splits\n")
    print(f"{'metric':26s} {'prod-vs-prod ceiling':>22s} {'fast-vs-prod':>14s} {'verdict':>12s}")

    for k in METRICS:
        usable = [s for s in seqs
                  if len(ref[s].get(k, {}).get("values", [])) >= 2 * a.depth
                  and len(fast[s].get(k, [])) >= a.depth]
        if len(usable) < 5:
            print(f"{k:26s}   (too few sequences with enough observations)")
            continue

        ceil = []
        for _ in range(a.trials):
            A, B = [], []
            for s in usable:
                v = ref[s][k]["values"][:]
                rng.shuffle(v)
                A.append(np.mean(v[:a.depth]))
                B.append(np.mean(v[a.depth:2 * a.depth]))
            ceil.append(spearman(A, B))

        cross = []
        for _ in range(a.trials):
            P, F = [], []
            for s in usable:
                v = ref[s][k]["values"][:]
                rng.shuffle(v)
                P.append(np.mean(v[:a.depth]))
                w = fast[s][k][:]
                rng.shuffle(w)
                F.append(np.mean(w[:a.depth]))
            cross.append(spearman(P, F))

        c_m, c_s = np.mean(ceil), np.std(ceil)
        x_m = np.mean(cross)
        verdict = "AT CEILING" if x_m >= c_m - c_s else "below"
        print(f"{k:26s} {c_m:14.3f}+-{c_s:6.3f} {x_m:14.3f} {verdict:>12s}")


if __name__ == "__main__":
    main()
