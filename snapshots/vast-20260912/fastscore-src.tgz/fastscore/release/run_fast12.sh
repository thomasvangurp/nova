#!/usr/bin/env bash
# Fast-path arm of the equivalence test.
#
# Scores the SAME 12 sequences the reference arm uses (refbase/seqs12.json is
# the contract), 4 independent repeats. The scorer is stochastic and not
# reproducible even at a fixed seed, so equivalence is a comparison of
# DISTRIBUTIONS, not of values -- 4 repeats per arm per sequence.
cd /root/fastscore/release
export CUDA_VISIBLE_DEVICES=6
REF=$(ls refdesign/*.cif | head -1)
rm -f fast12.done
for r in 0 1 2 3; do
  rm -rf fast12_work_$r
  ./release_python.sh fast_score_batch.py \
    --sequences /root/fastscore/refbase/seqs12.json \
    --config /root/config/config.yaml --target P20809 \
    --gpus 0 --batch-size 12 --synth-reference "$REF" \
    --shard-root /root/fastscore/release/fast12_work_$r \
    --out /root/fastscore/release/fast12_rep$r.json > fast12_rep$r.log 2>&1
  echo "repeat $r done: $(grep -o 'TOTAL.*' fast12_rep$r.log | tail -1)"
done
touch fast12.done
