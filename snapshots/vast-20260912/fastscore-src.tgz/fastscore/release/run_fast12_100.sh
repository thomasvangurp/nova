#!/usr/bin/env bash
# Combined-bias arm: synthesized design stage AND folding at 100x5, together.
#
# The two changes each carry a small bias in the same (flattering) direction --
# the synthesizer ~+0.001-0.004 design_iiptm, and the sampler cut ~+0.0003 at
# 100x5. Measuring them separately does not tell you whether they compound, and
# the number that matters for the publisher's thresholds is the combined one.
cd /root/fastscore/release
export CUDA_VISIBLE_DEVICES=6
REF=$(ls refdesign/*.cif | head -1)
rm -f fast12_100.done
for r in 0 1 2 3; do
  rm -rf f12_100_work_$r
  ./release_python.sh fast_score_batch.py \
    --sequences /root/fastscore/refbase/seqs12.json \
    --config /root/config/config.yaml --target P20809 \
    --gpus 0 --batch-size 12 --synth-reference "$REF" \
    --fold-sampling-steps 100 \
    --shard-root /root/fastscore/release/f12_100_work_$r \
    --out /root/fastscore/release/fast12_100_rep$r.json > fast12_100_rep$r.log 2>&1
  echo "100x5 repeat $r: $(grep -o 'TOTAL.*' fast12_100_rep$r.log | tail -1)"
done
touch fast12_100.done
