#!/usr/bin/env bash
# Does the 100x5 sampler cut carry a bias IN THE SHIPPED CONFIGURATION?
#
# Two measurements disagree:
#   sampler sweep, 20 designs from the REAL design stage : +0.0053 design_iiptm, -0.22 PAE
#   fast pipeline, 12 designs from the SYNTHESIZER       : +0.0008 design_iiptm, +0.04 PAE
# The inputs differ (real vs grafted structures) AND the sequences differ, so
# the two are confounded. This run removes the sequence confound: the same 24
# sequences already scored by production AND already scored by the fast path at
# 200x5, now at 100x5. Comparing against prod24_fast_rep*.json isolates the
# step count with synthesized inputs held fixed.
cd /root/fastscore/release
export CUDA_VISIBLE_DEVICES=2,3,5,7
REF=$(ls refdesign/*.cif | head -1)
rm -f prod24_100.done
for r in 0 1 2 3; do
  rm -rf p24_100_work_$r
  ./release_python.sh fast_score_batch.py \
    --sequences prod24.json \
    --config /root/config/config.yaml --target P20809 \
    --gpus 0,1,2,3 --shards-per-gpu 1 --batch-size 6 \
    --synth-reference "$REF" --fold-sampling-steps 100 \
    --shard-root /root/fastscore/release/p24_100_work_$r \
    --out /root/fastscore/release/prod24_100_rep$r.json > prod24_100_rep$r.log 2>&1
  echo "100x5 repeat $r: $(grep -o 'TOTAL.*' prod24_100_rep$r.log | tail -1)"
done
touch prod24_100.done
