"""Compare a scorer's output against the REAL validator's recorded scores.

/root/P20809_nanobodies.csv is the public submission archive: 34,024 sequences
with all ten metrics as the actual NOVA validator computed them. For any
sequence we score locally, that file holds an independent ground-truth
observation that costs no GPU time.

It is ONE observation per sequence, drawn from a scorer whose seed-to-seed
spread is large (design_iiptm 0.353 vs 0.311 on the same input), so the
absolute agreement is bounded by that noise and is NOT the interesting number.
The interesting number is the RANK correlation: the live selector ranks
candidates, so what matters is whether our scorer orders sequences the way the
validator does.
"""
from __future__ import annotations
import argparse, csv, glob, json
from collections import defaultdict

import numpy as np

METRICS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
           "min_design_to_target_pae", "interaction_pae",
           "plip_hbonds_refolded", "plip_saltbridge_refolded",
           "delta_sasa_refolded", "liability_score", "liability_num_violations"]


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    d = np.sqrt((ra**2).sum() * (rb**2).sum())
    return float((ra * rb).sum() / d) if d else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scored", nargs="+", required=True)
    ap.add_argument("--archive", default="/root/P20809_nanobodies.csv")
    ap.add_argument("--label", default="fast")
    a = ap.parse_args()

    ours = defaultdict(lambda: defaultdict(list))
    for g in a.scored:
        for p in glob.glob(g):
            d = json.load(open(p))
            for _uid, by_seq in d.get("per_nanobody_components", d).items():
                for seq, by_t in by_seq.items():
                    for _t, m in by_t.items():
                        for k in METRICS:
                            if k in m and m[k] is not None:
                                ours[seq][k].append(float(m[k]))

    arch = {}
    for row in csv.DictReader(open(a.archive)):
        if row["sequence"] in ours:
            arch[row["sequence"]] = row

    seqs = sorted(set(ours) & set(arch))
    missing = sorted(set(ours) - set(arch))
    print(f"{len(seqs)} of {len(ours)} scored sequences found in the archive"
          + (f" ({len(missing)} absent)" if missing else "") + "\n")
    if not seqs:
        return

    nrep = len(ours[seqs[0]][METRICS[0]])
    print(f"{a.label}: {nrep} repeats per sequence, compared against one real "
          f"validator observation each\n")
    print(f"{'metric':28s} {'rho':>7s} {'our mean':>10s} {'val mean':>10s} "
          f"{'bias':>9s} {'our sd':>8s}")
    for k in METRICS:
        if k not in arch[seqs[0]]:
            print(f"{k:28s}  (absent from archive)")
            continue
        o, v, sds = [], [], []
        for s in seqs:
            vals = ours[s].get(k, [])
            if not vals:
                continue
            try:
                av = float(arch[s][k])
            except (ValueError, KeyError):
                continue
            o.append(np.mean(vals)); v.append(av)
            if len(vals) > 1:
                sds.append(np.std(vals, ddof=1))
        if len(o) < 3:
            print(f"{k:28s}  (too few)")
            continue
        print(f"{k:28s} {spearman(o, v):7.3f} {np.mean(o):10.3f} {np.mean(v):10.3f} "
              f"{np.mean(o)-np.mean(v):+9.3f} {np.mean(sds) if sds else float('nan'):8.4f}")

    print("\nrho is the number that matters: the selector ranks candidates.")
    print("The bias column is bounded below by the validator's own single-draw "
          "noise, so a small bias here is not evidence of a scoring error.")


if __name__ == "__main__":
    main()
