"""Where does a sequence's 8.3 s actually go, at the CURRENT settings?

Earlier breakdowns were taken with the design stage still running and folding
at 200 steps. Both are gone, so the mix has shifted: cutting the sampler to 50
steps makes the parts that do NOT scale with step count (the trunk's four
recycles, the confidence head, analysis, per-chunk configure) the majority.
Guessing the new split would just repeat the mistake of optimising the wrong
thing, so measure it.
"""
from __future__ import annotations
import json, os, sys, time
from pathlib import Path

for v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(v, "4")

sys.path.insert(0, "/root/fastscore/release")
sys.path.insert(0, "/root")

import torch
from omegaconf import OmegaConf
import hydra

T = {}


def mark(name, t0):
    T[name] = T.get(name, 0.0) + (time.time() - t0)


def main():
    seqs = json.load(open("/root/fastscore/seqs8.json"))[:4]
    cfg_yaml = "/root/config/config.yaml"

    import yaml
    from fast_score_batch import _flatten_config
    subnet = _flatten_config(yaml.safe_load(open(cfg_yaml)), "P20809")

    import boltzgen.boltzgen_wrapper as bw
    from boltzgen.cli.boltzgen import build_parser, configure_command
    from boltzgen.task.task import Task
    from resident import ResidentStage
    from synth_fullatom import TemplateLibrary, synthesize
    from utils import seq_hash
    import rdkit.Chem
    rdkit.Chem.SetDefaultPickleProperties(rdkit.Chem.PropertyPickleOptions.AllProps)

    work = Path("/root/fastscore/release/phase_work")
    import shutil
    shutil.rmtree(work, ignore_errors=True)
    (work / "inputs").mkdir(parents=True)
    (work / "outputs").mkdir(parents=True)
    bw.BOLTZGEN_TMP_FILES_DIR = str(work)

    t0 = time.time()
    w = bw.BoltzgenWrapper()
    w.tmp_dir, w.input_dir, w.output_dir = str(work), str(work / "inputs"), str(work / "outputs")
    w.subnet_config = subnet
    w.unique_sequences = w._deduplicate_nanobodies({0: {"sequences": seqs}})
    w._write_yaml_files()
    mark("write_yaml", t0)

    t0 = time.time()
    parser = build_parser()
    argv = ["configure", w.input_dir, "--output", w.output_dir,
            "--protocol", w.boltzgen_config["protocol"],
            "--num_designs", str(w.boltzgen_config["num_designs"]),
            "--skip_inverse_folding",
            "--step_scale", str(w.boltzgen_config["step_scale"]),
            "--noise_scale", str(w.boltzgen_config["noise_scale"])]
    configure_command(parser.parse_args(argv))
    mark("configure", t0)

    cfg_dir = Path(w.output_dir) / "config"
    designs = Path(w.output_dir) / "intermediate_designs"
    designs.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    ref = sorted(Path("/root/fastscore/release/refdesign").glob("*.cif"))[0]
    lib = TemplateLibrary.from_cifs(sorted(Path("/root/fastscore/release/refdesign").glob("*.cif")))
    mark("rotamer_library", t0)

    t0 = time.time()
    for s in seqs:
        stem = f"{seq_hash(s)}_P20809_input"
        synthesize(ref, s, designs / f"{stem}.cif", lib)
        shutil.copyfile(ref.with_suffix(".npz"), designs / f"{stem}.npz")
    mark("synthesize", t0)

    t0 = time.time()
    stage = ResidentStage(cfg_dir / "folding.yaml", overrides={"matmul_precision": "high"})
    mark("folding_model_load", t0)

    t0 = time.time()
    stage.run_batch({"data.design_dir": str(designs), "output": str(designs)},
                    predict_args={"sampling_steps": 50, "diffusion_samples": 5})
    mark("folding_predict", t0)

    t0 = time.time()
    acfg = OmegaConf.load(cfg_dir / "analysis.yaml")
    OmegaConf.update(acfg, "design_dir", str(designs), merge=False)
    OmegaConf.update(acfg, "num_processes", 1, merge=False)
    task = hydra.utils.instantiate(acfg)
    task.run(acfg)
    mark("analysis", t0)

    n = len(seqs)
    print(f"\n==== per sequence, n={n}, synth + 50x5 + TF32 ====")
    load = T.pop("folding_model_load")
    total = sum(T.values())
    for k, v in sorted(T.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v/n:7.3f} s/seq   {100*v/total:5.1f}%")
    print(f"  {'-'*22} {total/n:7.3f} s/seq  (excl. one-time model load {load:.1f}s)")


if __name__ == "__main__":
    main()
