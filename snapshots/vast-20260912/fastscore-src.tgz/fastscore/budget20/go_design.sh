#!/usr/bin/env bash
set -euo pipefail
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=8
/root/fastscore/fast_python.sh /root/fastscore/budget20/run_design20.py \
  /root/fastscore/work_base4/outputs/config/design.yaml \
  --input-dir /root/fastscore/budget20/inputs \
  --out-dir /root/fastscore/budget20/designs \
  --steps 500 > /root/fastscore/budget20/design.log 2>&1
touch /root/fastscore/budget20/design.done
