"""The hardest ranking case: designs that are all of SIMILAR quality.

The 20 designs turned out bimodal in our own re-folded scores (5 good binders
near 0.78, 15 poor near 0.24). Separating those two modes is easy, so a rho
over all 20 could flatter a cheap scorer. The question that decides a selector
is whether it ranks correctly WITHIN a mode, where the differences are small
relative to the scorer's own noise. This recomputes the ceiling and the
candidate rho on the 15-design low cluster alone.
"""
import json, math, itertools
import numpy as np
from collections import defaultdict

KEYS=["design_iiptm","design_ptm","design_to_target_iptm",
      "min_design_to_target_pae","interaction_pae"]

def spearman(a,b):
    a,b=np.asarray(a,float),np.asarray(b,float)
    ra=np.argsort(np.argsort(a)).astype(float); rb=np.argsort(np.argsort(b)).astype(float)
    ra-=ra.mean(); rb-=rb.mean()
    d=math.sqrt((ra**2).sum()*(rb**2).sum())
    return (ra*rb).sum()/d if d else float("nan")

rows=json.load(open("/root/fastscore/budget20/sweep20.json"))
tab=defaultdict(lambda: defaultdict(dict))
for r in rows:
    tab[f"{r['steps']}x{r['samples']}"][r["repeat"]][r["design"]]={k:r[k] for k in KEYS}

ref="200x5"
designs=sorted({d for rep in tab[ref].values() for d in rep})
mean_ii={d:np.mean([tab[ref][r][d]["design_iiptm"] for r in tab[ref]]) for d in designs}
low=[d for d in designs if mean_ii[d]<0.5]
high=[d for d in designs if mean_ii[d]>=0.5]
print(f"low cluster n={len(low)} (design_iiptm {min(mean_ii[d] for d in low):.3f}"
      f"..{max(mean_ii[d] for d in low):.3f})")
print(f"high cluster n={len(high)} (design_iiptm {min(mean_ii[d] for d in high):.3f}"
      f"..{max(mean_ii[d] for d in high):.3f})\n")

def rho_pw(sa,sb,key,subset):
    out=[]
    for i in sorted(tab[sa]):
        for j in sorted(tab[sb]):
            if sa==sb and j<=i: continue
            out.append(spearman([tab[sa][i][d][key] for d in subset],
                                [tab[sb][j][d][key] for d in subset]))
    return float(np.mean(out)), float(np.std(out,ddof=1))

print(f"=== SPEARMAN within the LOW cluster only (n={len(low)}) ===")
print(f"{'metric':28s} {'ceiling(ref,ref)':>18s} {'100x5':>18s} {'50x5':>18s}")
for key in KEYS:
    c,cs=rho_pw(ref,ref,key,low)
    a,as_=rho_pw("100x5",ref,key,low)
    b,bs=rho_pw("50x5",ref,key,low)
    print(f"{key:28s} {c:9.3f}+-{cs:<6.3f} {a:9.3f}+-{as_:<6.3f} {b:9.3f}+-{bs:<6.3f}")
