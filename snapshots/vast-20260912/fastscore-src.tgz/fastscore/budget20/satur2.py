"""Is r(delta_100, delta_50) real, or an artifact of a shared reference?

delta_100(d) = mean_100(d) - mean_ref(d) and delta_50(d) = mean_50(d) - mean_ref(d)
share the SAME mean_ref(d). Noise in mean_ref is therefore common to both and
induces positive correlation even if 100 and 50 deviate independently. With 6
repeats the reference's own standard error is sd/sqrt(6) ~ 0.41 sd, which is
the same order as the deviations themselves -- so the confound is not small.

Fix: split the six 200x5 repeats into two disjoint halves. Grade delta_100
against half A and delta_50 against half B. The reference noise is then
independent between the two deltas, and any surviving correlation is a real
shared per-design effect. Averaged over all 10 disjoint 3+3 splits.
"""
import json, math, itertools
import numpy as np
from collections import defaultdict

KEYS=["design_iiptm","min_design_to_target_pae","interaction_pae",
      "design_to_target_iptm","design_ptm"]
rows=json.load(open("/root/fastscore/budget20/sweep20.json"))
tab=defaultdict(lambda: defaultdict(dict))
for r in rows:
    tab[f"{r['steps']}x{r['samples']}"][r["repeat"]][r["design"]]={k:r[k] for k in KEYS}
designs=sorted({d for rep in tab["200x5"].values() for d in rep})
reps=sorted(tab["200x5"])

def pearson(a,b):
    a,b=np.asarray(a,float),np.asarray(b,float); a=a-a.mean(); b=b-b.mean()
    d=math.sqrt((a**2).sum()*(b**2).sum())
    return (a*b).sum()/d if d else float("nan")

print(f"{'metric':26s} {'r shared-ref':>13s} {'r split-ref':>12s} {'control r(A,B)':>15s}")
for key in KEYS:
    refall={d:np.mean([tab['200x5'][r][d][key] for r in reps]) for d in designs}
    m100={d:np.mean([tab['100x5'][r][d][key] for r in tab['100x5']]) for d in designs}
    m50 ={d:np.mean([tab['50x5'][r][d][key]  for r in tab['50x5']])  for d in designs}
    r_shared=pearson([m100[d]-refall[d] for d in designs],
                     [m50[d]-refall[d]  for d in designs])
    rs, ctrl = [], []
    for A in itertools.combinations(reps,3):
        B=tuple(r for r in reps if r not in A)
        if A>B: continue                      # each split once
        refA={d:np.mean([tab['200x5'][r][d][key] for r in A]) for d in designs}
        refB={d:np.mean([tab['200x5'][r][d][key] for r in B]) for d in designs}
        rs.append(pearson([m100[d]-refA[d] for d in designs],
                          [m50[d]-refB[d]  for d in designs]))
        # control: split the REFERENCE against itself the same way.
        # 200x5 has no step-count effect, so this is the pure-noise baseline.
        ctrl.append(pearson([refB[d]-refA[d] for d in designs],
                            [refB[d]-refA[d] for d in designs]))
    print(f"{key:26s} {r_shared:13.3f} {np.mean(rs):12.3f} {'n/a':>15s}")

print("\nIf r stays high with independent reference halves, the per-design")
print("deviation at 100 and at 50 is a REAL shared effect, already saturated")
print("at 100 steps. If it collapses toward 0, the shared-ref value was an")
print("artifact of common reference noise.")
