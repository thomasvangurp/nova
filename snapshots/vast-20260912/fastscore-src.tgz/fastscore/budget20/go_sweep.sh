#!/usr/bin/env bash
set -euo pipefail
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=8
/root/fastscore/fast_python.sh /root/fastscore/budget20/sweep20.py \
  /root/fastscore/fold_res.yaml \
  --source-dir /root/fastscore/budget20/designs \
  --work-root /root/fastscore/budget20/work \
  --variants 200x5,100x5,50x5 \
  --repeats 6 \
  --out /root/fastscore/budget20/sweep20.json > /root/fastscore/budget20/sweep.log 2>&1
touch /root/fastscore/budget20/sweep.done
