"""Supplement to analyze_sweep.py for the 20-design confirmation run.

analyze_sweep.py already gives cost, pooled bias, sd across repeats and
sd*sqrt(s). This adds the four things the 4-design pilot could not support:

1. PAIRED BIAS with SIGN CONSISTENCY. A mean bias near zero can hide a real
   systematic shift if it is small relative to design-to-design spread. The
   test that survives averaging is whether the per-design delta has the SAME
   SIGN on nearly all designs. Under no bias, signs are a coin flip, so k of n
   same-sign has an exact binomial p-value.

2. A NOISE CEILING for the rank correlation. rho(cheap, reference) is
   meaningless without knowing what rho(reference, reference) is, because the
   scorer is not reproducible: independent repeats of the SAME setting
   disagree. So every rho here is computed between single repeats at matched
   averaging depth, and the reference-vs-itself value is printed as the
   ceiling. A cheap setting that reaches the ceiling has lost nothing.

3. TOP-K AGREEMENT and SELECTION REGRET. Rank correlation over all designs is
   not what a selector does; a selector takes the top few. Regret is the
   quantity that actually costs score: pick argmax by the cheap scorer, then
   look up what the reference says that design is really worth, and compare to
   the reference's own best. Reported in the metric's own units, next to the
   reference's self-regret (picking by one reference repeat and grading by
   another) which is the floor.

4. Everything split by the BULK subset, so a flattering rho cannot be an
   artifact of the two tail anchors dragging the correlation up.
"""
from __future__ import annotations

import argparse, json, math, itertools
from collections import defaultdict

import numpy as np

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]
# metrics where LOWER is better (PAEs are errors)
LOWER_BETTER = {"min_design_to_target_pae", "interaction_pae"}
# measured same-config same-seed reproducibility floor (two runs)
REPRO_FLOOR = {"design_iiptm": 0.0048, "min_design_to_target_pae": 0.175}


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    d = math.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / d) if d else float("nan")


def binom_two_sided(k, n):
    """P(at least as extreme a sign imbalance as k of n) under p=0.5."""
    k = max(k, n - k)
    tail = sum(math.comb(n, i) for i in range(k, n + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sweep_json")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--ref", default="200x5")
    ap.add_argument("--topk", type=int, default=5)
    a = ap.parse_args()

    rows = json.load(open(a.sweep_json))
    bulk = None
    if a.manifest:
        man = json.load(open(a.manifest))
        # sweep design ids are the yaml stems; manifest 'design' is the same stem
        bulk = {m["design"] for m in man if m.get("bulk")}

    # tab[setting][repeat][design][key]
    tab = defaultdict(lambda: defaultdict(dict))
    secs = defaultdict(list)
    secs_by_rep = defaultdict(dict)   # setting -> repeat -> s/design (one batch)
    for r in rows:
        s = f"{r['steps']}x{r['samples']}"
        tab[s][r["repeat"]][r["design"]] = {k: r[k] for k in KEYS}
        secs_by_rep[s][r["repeat"]] = r["seconds"]
    for s, d in secs_by_rep.items():
        secs[s] = list(d.values())

    settings = sorted(tab, key=lambda s: -np.mean(secs[s]))
    ref = a.ref
    designs = sorted({d for rep in tab[ref].values() for d in rep})
    reps = sorted(tab[ref])
    n_bulk = len([d for d in designs if bulk and d in bulk]) if bulk else 0
    print(f"{len(rows)} rows | {len(designs)} designs | repeats {reps} | "
          f"settings {settings} | reference {ref}")
    if bulk:
        print(f"bulk subset (archive pct 5-95): {n_bulk} of {len(designs)} designs")
    print()

    # ---- 1. cost, with spread -------------------------------------------
    print("=== COST (s/design, from batch wall time / n designs) ===")
    print(f"{'setting':10s} {'mean':>8s} {'sd':>7s} {'min':>7s} {'max':>7s} "
          f"{'speedup':>8s} {'n batches':>10s}")
    ref_s = float(np.mean(secs[ref]))
    for s in settings:
        v = np.array(sorted(secs_by_rep[s].values()), float)  # one per batch
        print(f"{s:10s} {v.mean():8.2f} {v.std(ddof=1):7.2f} {v.min():7.2f} "
              f"{v.max():7.2f} {ref_s/np.mean(secs[s]):7.2f}x {len(v):10d}")
    print()

    # ---- 2. paired bias with sign consistency ---------------------------
    print("=== PAIRED BIAS vs reference (per-design mean over repeats) ===")
    for key in KEYS:
        floor = REPRO_FLOOR.get(key)
        ftxt = f"  [repro floor {floor}]" if floor else ""
        print(f"--- {key}{ftxt}")
        print(f"{'setting':10s} {'mean d':>10s} {'sd(d)':>9s} {'SE':>9s} "
              f"{'t':>7s} {'same-sign':>10s} {'p(binom)':>9s} {'design sd':>10s}")
        refm = {d: np.mean([tab[ref][r][d][key] for r in reps if d in tab[ref][r]])
                for d in designs}
        design_sd = np.std(list(refm.values()), ddof=1)
        for s in settings:
            sreps = sorted(tab[s])
            m = {d: np.mean([tab[s][r][d][key] for r in sreps if d in tab[s][r]])
                 for d in designs}
            delta = np.array([m[d] - refm[d] for d in designs], float)
            if s == ref:
                print(f"{s:10s} {'(reference)':>10s} {'':9s} {'':9s} {'':7s} "
                      f"{'':10s} {'':9s} {design_sd:10.4f}")
                continue
            sd = delta.std(ddof=1)
            se = sd / math.sqrt(len(delta))
            t = delta.mean() / se if se else float("nan")
            pos = int((delta > 0).sum())
            same = max(pos, len(delta) - pos)
            p = binom_two_sided(pos, len(delta))
            print(f"{s:10s} {delta.mean():+10.4f} {sd:9.4f} {se:9.4f} "
                  f"{t:7.2f} {same:6d}/{len(delta):<3d} {p:9.2e} {design_sd:10.4f}")
        print()

    # ---- 3. precision per GPU-second ------------------------------------
    print("=== PRECISION: within-design sd across repeats, and sd*sqrt(s) ===")
    print("(sd*sqrt(s) = standard error per GPU-second; LOWER IS BETTER)")
    hdr = f"{'metric':28s}" + "".join(f"{s:>22s}" for s in settings)
    print(hdr)
    for key in KEYS:
        cells = []
        for s in settings:
            sreps = sorted(tab[s])
            sds = []
            for d in designs:
                v = [tab[s][r][d][key] for r in sreps if d in tab[s][r]]
                if len(v) > 1:
                    sds.append(np.std(v, ddof=1))
            sd = float(np.mean(sds))
            sec = float(np.mean(secs[s]))
            cells.append(f"{sd:9.4f} /{sd*math.sqrt(sec):9.4f}")
        print(f"{key:28s}" + "".join(f"{c:>22s}" for c in cells))
    print(f"{'':28s}" + "".join(f"{'sd / sd*sqrt(s)':>22s}" for _ in settings))
    print()

    # ---- 4. rank correlation at matched averaging depth ------------------
    def rho_pairwise(sa, sb, key, subset):
        ra, rb = sorted(tab[sa]), sorted(tab[sb])
        out = []
        for i in ra:
            for j in rb:
                if sa == sb and j <= i:
                    continue
                va = [tab[sa][i][d][key] for d in subset if d in tab[sa][i]]
                vb = [tab[sb][j][d][key] for d in subset if d in tab[sb][j]]
                if len(va) == len(vb) == len(subset):
                    out.append(spearman(va, vb))
        return (float(np.mean(out)), float(np.std(out, ddof=1)) if len(out) > 1
                else float("nan"), len(out))

    for label, subset in [("ALL designs", designs)] + (
            [("BULK only (archive pct 5-95)",
              [d for d in designs if d in bulk])] if bulk else []):
        print(f"=== SPEARMAN vs {ref}, single repeat vs single repeat "
              f"-- {label}, n={len(subset)} ===")
        print("the ref-vs-ref row is the NOISE CEILING: the scorer's own "
              "disagreement with itself")
        print(f"{'metric':28s} {'ceiling(ref,ref)':>18s}" +
              "".join(f"{s:>18s}" for s in settings if s != ref))
        for key in KEYS:
            c, csd, cn = rho_pairwise(ref, ref, key, subset)
            line = f"{key:28s} {c:9.3f}+-{csd:<6.3f}"
            for s in settings:
                if s == ref:
                    continue
                r_, rsd, rn = rho_pairwise(s, ref, key, subset)
                line += f" {r_:9.3f}+-{rsd:<6.3f}"
            print(line)
        print()

    # ---- 5. top-k agreement and selection regret -------------------------
    print(f"=== SELECTOR BEHAVIOUR: top-{a.topk} of {len(designs)} "
          f"and argmax regret ===")
    print("regret: pick by the candidate setting (one repeat), grade with a "
          "HELD-OUT reference repeat.\nthe ref-vs-ref column is the floor: "
          "the cost of the scorer's own noise.")
    for key in KEYS:
        sign = -1.0 if key in LOWER_BETTER else 1.0
        print(f"--- {key} ({'lower' if sign < 0 else 'higher'} is better)")
        print(f"{'setting':10s} {'top-k overlap':>14s} {'regret':>10s} "
              f"{'regret sd':>10s}")
        for s in settings:
            ov, reg = [], []
            for i in sorted(tab[s]):
                for j in sorted(tab[ref]):
                    if s == ref and i == j:
                        continue  # must grade with a held-out repeat
                    sel = {d: sign * tab[s][i][d][key] for d in designs
                           if d in tab[s][i]}
                    tru = {d: sign * tab[ref][j][d][key] for d in designs
                           if d in tab[ref][j]}
                    common = sorted(set(sel) & set(tru))
                    if len(common) < len(designs):
                        continue
                    ks = sorted(common, key=lambda d: -sel[d])[:a.topk]
                    kt = sorted(common, key=lambda d: -tru[d])[:a.topk]
                    ov.append(len(set(ks) & set(kt)) / a.topk)
                    pick = max(common, key=lambda d: sel[d])
                    reg.append(max(tru.values()) - tru[pick])
            tag = "  <- floor" if s == ref else ""
            print(f"{s:10s} {np.mean(ov):13.2f}  {np.mean(reg):10.4f} "
                  f"{np.std(reg, ddof=1):10.4f}{tag}")
        print()


if __name__ == "__main__":
    main()
