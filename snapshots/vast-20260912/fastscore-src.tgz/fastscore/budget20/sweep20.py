"""The 20-design confirmation of the sampler-budget result.

Same engine as sweep_budget.py -- same ResidentStage, same best_sample scoring
(argmax of 0.8*design_to_target_iptm + 0.2*design_ptm over diffusion samples),
same per-repeat seeding -- with two changes the larger run needs:

1. LOOP ORDER. sweep_budget.py runs all repeats of one setting before moving
   to the next. Over a ~45 min sweep on a box shared with a live miner, that
   confounds setting with drift in machine load: whichever setting happened to
   run while the miner was busy looks slower. Here the settings are
   INTERLEAVED inside each repeat, and their order is rotated between repeats,
   so load drift spreads across settings instead of loading onto one.

2. The seed is set once per (repeat) and the same seed serves every setting in
   that repeat -- common random numbers, so the settings are compared on the
   same draw rather than on independent ones. This makes the paired per-design
   bias a cleaner estimate; it does not affect the across-repeat spread, which
   is what sd*sqrt(s) is computed from.

Everything is checkpointed to the output JSON after every batch.
"""
from __future__ import annotations

import argparse, json, shutil, sys, time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/root/fastscore")
from resident import ResidentStage, seed_all
from sweep_budget import KEYS, best_sample


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--source-dir", required=True)
    ap.add_argument("--work-root", required=True)
    ap.add_argument("--variants", default="200x5,100x5,50x5")
    ap.add_argument("--repeats", type=int, default=6)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    src = Path(a.source_dir)
    srcfiles = sorted(list(src.glob("*.cif")) + list(src.glob("*.npz")))
    designs = sorted(p.stem for p in src.glob("*.cif"))
    print(f"{len(designs)} designs from {src}", flush=True)
    if not designs:
        raise SystemExit("no designs")

    variants = []
    for tok in a.variants.split(","):
        s, m = tok.lower().split("x")
        variants.append((int(s), int(m)))

    stage = ResidentStage(a.config)
    print(f"model load: {stage.load_seconds:.1f}s", flush=True)

    root = Path(a.work_root)
    results = []
    t_start = time.time()
    for rep in range(a.repeats):
        # rotate the within-repeat order so no setting always runs first
        order = variants[rep % len(variants):] + variants[:rep % len(variants)]
        for steps, samples in order:
            d = root / f"s{steps}_m{samples}_r{rep}"
            shutil.rmtree(d, ignore_errors=True)
            d.mkdir(parents=True, exist_ok=True)
            for p in srcfiles:
                shutil.copyfile(p, d / p.name)

            seed_all(1000 + rep)     # common random numbers across settings
            secs = stage.run_batch(
                {"data.design_dir": str(d), "output": str(d)},
                predict_args={"sampling_steps": steps,
                              "diffusion_samples": samples},
            )

            npzs = sorted((d / "fold_out_npz").glob("*.npz"))
            for npz_path in npzs:
                m = best_sample(np.load(npz_path, allow_pickle=True))
                m.update(design=npz_path.stem, steps=steps, samples=samples,
                         repeat=rep, seconds=secs / len(designs),
                         batch_seconds=secs, t_offset=time.time() - t_start)
                results.append(m)
            print(f"  rep={rep} steps={steps:3d} samples={samples}: "
                  f"{secs:6.1f}s for {len(npzs)}/{len(designs)} designs "
                  f"({secs/len(designs):5.2f}s/design)  "
                  f"[elapsed {(time.time()-t_start)/60:.1f} min]", flush=True)
            if len(npzs) != len(designs):
                print(f"  WARNING: {len(designs)-len(npzs)} designs missing",
                      flush=True)
            shutil.rmtree(d, ignore_errors=True)
            json.dump(results, open(a.out, "w"), indent=1)

    json.dump(results, open(a.out, "w"), indent=1)
    print(f"wrote {a.out} ({len(results)} rows) in "
          f"{(time.time()-t_start)/60:.1f} min", flush=True)


if __name__ == "__main__":
    main()
