"""Pick N length-127 nanobody sequences stratified across the archive's own
quality range, and write BoltzGen design input yamls for them.

Why stratify: the headline question is whether a cheap scorer RANKS candidates
the same as the expensive one. A Spearman rho over designs that are all
equally good is meaningless -- rank noise with no signal to rank. So the
designs have to genuinely span the quality range the selector will see.

Axis: design_iiptm from the archive (one of the five scored metrics, and the
one the pilot found most sensitive).

The length-127 archive is tightly packed: the 5th-95th percentile of
design_iiptm spans only 0.668..0.791, and everything below 0.62 lives in the
bottom 1%. Two competing requirements follow:

  * a rho that means anything needs designs that genuinely differ, which
    argues for reaching into the tail;
  * a rho that predicts live selector behaviour needs designs drawn like the
    ones the selector will actually see, which is the tight bulk.

So the grid does both: 16 picks evenly spaced in percentile over the realistic
5th-95th band, plus 4 tail anchors at percentiles 0.2, 1, 99 and 99.9. rho is
reported over all 20 and, separately, over the 16-design bulk, so an inflated
"the cheap scorer ranks fine" driven purely by the anchors cannot hide.
Picks are the row nearest each target percentile: deterministic, not random.

The yaml is byte-identical to the four existing work_base4 inputs except the
sequence line; the filename stem is sha256(sequence), which is the archive's
own sequence_hash convention (verified against an existing input).
"""
from __future__ import annotations

import argparse, csv, hashlib, json
from pathlib import Path

import numpy as np

TEMPLATE = '''entities:
- file:
    path: /root/data/structures/6O4O.cif
    include:
        - chain:
            id: A
            res_index: 2..169
            msa: /root/data/msa_files/P20809.a3m
    binding_types:
        - chain:
            id: A
            binding: 31..35,37..38,40,88,135..138,142
- protein:
    id: B
    sequence: "{seq}"
    msa: empty
'''

METRICS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
           "min_design_to_target_pae", "interaction_pae"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="/root/P20809_nanobodies.csv")
    ap.add_argument("--length", type=int, default=127)
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--axis", default="design_iiptm")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--manifest", required=True)
    a = ap.parse_args()

    rows = []
    with open(a.csv) as fh:
        for r in csv.DictReader(fh):
            if len(r["sequence"]) != a.length:
                continue
            try:
                for k in METRICS:
                    r[k] = float(r[k])
            except (ValueError, KeyError):
                continue
            rows.append(r)
    print(f"{len(rows)} rows of length {a.length}")

    rows.sort(key=lambda r: r[a.axis])
    vals = np.array([r[a.axis] for r in rows])
    print(f"{a.axis} range {vals.min():.4f} .. {vals.max():.4f}, "
          f"median {np.median(vals):.4f}")

    # 16 evenly spaced percentiles over the realistic bulk + 4 tail anchors
    n_bulk = a.n - 4
    pcts = ([0.2, 1.0] + list(np.linspace(5.0, 95.0, n_bulk)) + [99.0, 99.9])
    pcts = sorted(pcts)
    picks, seen = [], set()
    for q in pcts:
        i = int(round(q / 100.0 * (len(rows) - 1)))
        while i in seen:            # never pick the same row twice
            i += 1
        seen.add(i)
        r = dict(rows[i])
        r["_pct"] = float(q)
        r["_bulk"] = bool(5.0 <= q <= 95.0)
        picks.append(r)

    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    manifest = []
    for p in picks:
        seq = p["sequence"]
        h = hashlib.sha256(seq.encode()).hexdigest()
        if p.get("sequence_hash") and p["sequence_hash"] != h:
            raise SystemExit(f"hash convention mismatch for {seq[:12]}...")
        path = out / f"{h}_P20809_input.yaml"
        path.write_text(TEMPLATE.format(seq=seq))
        manifest.append({"design": path.stem, "hash": h, "sequence": seq,
                         "yaml": str(path), "archive_pct": p["_pct"],
                         "bulk": p["_bulk"],
                         **{k: p[k] for k in METRICS}})

    json.dump(manifest, open(a.manifest, "w"), indent=1)
    print(f"\nwrote {len(manifest)} yamls to {out}")
    print(f"{'pct':>6s} {'bulk':>5s} {'design_iiptm':>13s} {'design_ptm':>11s} "
          f"{'d2t_iptm':>9s} {'min_d2t_pae':>12s} {'inter_pae':>10s}  hash")
    for m in manifest:
        print(f"{m['archive_pct']:6.1f} {str(m['bulk']):>5s} "
              f"{m['design_iiptm']:13.4f} {m['design_ptm']:11.4f} "
              f"{m['design_to_target_iptm']:9.4f} "
              f"{m['min_design_to_target_pae']:12.4f} "
              f"{m['interaction_pae']:10.4f}  {m['hash'][:12]}")


if __name__ == "__main__":
    main()
