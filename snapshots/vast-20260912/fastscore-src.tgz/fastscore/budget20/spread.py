import json, numpy as np
from collections import defaultdict
rows=json.load(open("/root/fastscore/budget20/sweep20.json"))
man={m["design"]:m for m in json.load(open("/root/fastscore/budget20/manifest.json"))}
by=defaultdict(list)
for r in rows:
    if r["steps"]==200: by[r["design"]].append(r)
print(f"{'pct':>6s} {'bulk':>5s} {'archive_iiptm':>13s} {'OUR 200x5 iiptm':>16s} {'sd(rep)':>8s} {'OUR min_d2t_pae':>16s}")
d_arch=[];d_ours=[]
for d in sorted(by, key=lambda x: man[x]["archive_pct"]):
    v=[r["design_iiptm"] for r in by[d]]; p=[r["min_design_to_target_pae"] for r in by[d]]
    m=man[d]
    print(f"{m['archive_pct']:6.1f} {str(m['bulk']):>5s} {m['design_iiptm']:13.4f} "
          f"{np.mean(v):16.4f} {np.std(v,ddof=1):8.4f} {np.mean(p):16.3f}")
    d_arch.append(m["design_iiptm"]); d_ours.append(np.mean(v))
d_arch=np.array(d_arch); d_ours=np.array(d_ours)
ra=np.argsort(np.argsort(d_arch)).astype(float); rb=np.argsort(np.argsort(d_ours)).astype(float)
ra-=ra.mean(); rb-=rb.mean()
print(f"\nOUR 200x5 design_iiptm across the 20 designs: min {d_ours.min():.4f} max {d_ours.max():.4f} sd {d_ours.std(ddof=1):.4f}")
print(f"rho(archive design_iiptm, our 200x5 design_iiptm) = {(ra*rb).sum()/np.sqrt((ra**2).sum()*(rb**2).sum()):.3f}")
