"""Does the 100x5 and 50x5 bias come from the SAME per-design effect?

If reducing steps saturates immediately below 200 (a real structural effect),
then the per-design deviation from 200x5 should be the SAME design-by-design at
100 and at 50: delta_100(d) and delta_50(d) correlate across designs.

If instead both are just independent draws of the scorer's noise around zero,
the two delta vectors are uncorrelated. The settings share a seed per repeat
(common random numbers), so this is a fair paired comparison.

Also reports, per design, how far the deviation sits in units of that design's
OWN across-repeat sd -- the only scale on which "bias" means anything here.
"""
import json, math
import numpy as np
from collections import defaultdict

KEYS=["design_iiptm","min_design_to_target_pae","interaction_pae",
      "design_to_target_iptm","design_ptm"]
rows=json.load(open("/root/fastscore/budget20/sweep20.json"))
tab=defaultdict(lambda: defaultdict(dict))
for r in rows:
    tab[f"{r['steps']}x{r['samples']}"][r["repeat"]][r["design"]]={k:r[k] for k in KEYS}
designs=sorted({d for rep in tab["200x5"].values() for d in rep})

def pearson(a,b):
    a,b=np.asarray(a,float),np.asarray(b,float)
    a=a-a.mean(); b=b-b.mean()
    d=math.sqrt((a**2).sum()*(b**2).sum())
    return (a*b).sum()/d if d else float("nan")

print(f"{'metric':26s} {'r(d100,d50)':>12s} {'mean|d100|/sd':>14s} {'mean|d50|/sd':>13s}")
for key in KEYS:
    ref={d:np.mean([tab['200x5'][r][d][key] for r in tab['200x5']]) for d in designs}
    sdw={d:np.mean([np.std([tab[s][r][d][key] for r in tab[s]],ddof=1)
                    for s in ('200x5','100x5','50x5')]) for d in designs}
    d100=[np.mean([tab['100x5'][r][d][key] for r in tab['100x5']])-ref[d] for d in designs]
    d50 =[np.mean([tab['50x5'][r][d][key]  for r in tab['50x5']])-ref[d]  for d in designs]
    n100=np.mean([abs(x)/sdw[d] for x,d in zip(d100,designs)])
    n50 =np.mean([abs(x)/sdw[d] for x,d in zip(d50,designs)])
    print(f"{key:26s} {pearson(d100,d50):12.3f} {n100:14.2f} {n50:13.2f}")

print("\nr near 0 => the two settings deviate in unrelated directions per design,")
print("i.e. noise, not a shared structural effect that saturates below 200 steps.")
print("|delta|/sd near or below ~1 => the deviation is within the scorer's own")
print("repeat-to-repeat scatter for that design.")
