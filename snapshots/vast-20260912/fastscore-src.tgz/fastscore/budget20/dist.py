import csv, numpy as np
rows=[r for r in csv.DictReader(open("/root/P20809_nanobodies.csv")) if len(r["sequence"])==127]
v=np.array([float(r["design_iiptm"]) for r in rows])
p=np.array([float(r["min_design_to_target_pae"]) for r in rows])
print("n",len(v))
for q in [0,0.1,0.5,1,2,5,10,20,30,40,50,60,70,80,90,95,99,100]:
    print(f"  pct {q:5.1f}: iiptm {np.percentile(v,q):.4f}   min_d2t_pae {np.percentile(p,q):8.3f}")
