"""Run the BoltzGen design stage once, at its production 500 steps, for the
selected input yamls -- producing the .cif/.npz design outputs the folding
sweep then scores.

This stage is NOT the thing under test. It is run once, at production settings,
so that every folding setting in the sweep scores exactly the same structures
and any difference observed is attributable to the folding sampler alone.
"""
from __future__ import annotations

import argparse, sys, time
from pathlib import Path

sys.path.insert(0, "/root/fastscore")   # resident.py lives beside the sweep tools

from resident import ResidentStage, seed_all


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--input-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--seed", type=int, default=31337)
    a = ap.parse_args()

    yamls = sorted(str(p) for p in Path(a.input_dir).glob("*_input.yaml"))
    print(f"{len(yamls)} input yamls", flush=True)

    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    stage = ResidentStage(a.config, overrides={"data.cfg.yaml_path": yamls})
    print(f"model load: {stage.load_seconds:.1f}s", flush=True)

    seed_all(a.seed)
    t0 = time.time()
    secs = stage.run_batch({"data.cfg.yaml_path": yamls, "output": str(out)},
                           predict_args={"sampling_steps": a.steps})
    cifs = sorted(out.glob("*.cif"))
    print(f"design steps={a.steps}: {secs:.1f}s for {len(cifs)} designs "
          f"({secs/max(len(cifs),1):.1f}s/design), wall {time.time()-t0:.1f}s",
          flush=True)
    for c in cifs:
        npz = c.with_suffix(".npz")
        print(f"  {c.name}  npz={'ok' if npz.exists() else 'MISSING'}")
    if len(cifs) != len(yamls):
        raise SystemExit(f"expected {len(yamls)} designs, got {len(cifs)}")


if __name__ == "__main__":
    main()
