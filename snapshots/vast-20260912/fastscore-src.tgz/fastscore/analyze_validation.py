"""Per-design real-vs-synth distributions, plus the paired difference.

A consistent same-sign shift across all four designs is a failure even when
each individual difference sits inside the seed-to-seed spread, so the paired
column matters more than any single row.
"""
from __future__ import annotations
import argparse, json
import numpy as np

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]

# measured on this box, same config
FLOOR_SAME_SEED = {"design_iiptm": 0.0048, "min_design_to_target_pae": 0.175}
FLOOR_DIFF_SEED = {"design_iiptm": 0.042, "min_design_to_target_pae": 1.24}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    a = ap.parse_args()
    res = json.loads(open(a.results).read())

    variants = sorted({v for r in res.values() for v in r})
    base = "real"
    others = [v for v in variants if v != base]
    per_design_delta = {(v, k): [] for v in others for k in KEYS}
    for name in sorted(res):
        r = res[name]
        seeds = sorted(set.intersection(*[set(r[v]) for v in variants]), key=int)
        print(f"=== {name[:16]}  ({len(seeds)} seeds: {', '.join(seeds)}) ===")
        hdr = f"{'metric':26s}"
        for v in variants:
            hdr += f" {v+' mean+-sd':>19s} {v+' range':>17s}"
        for v in others:
            hdr += f" {'d('+v+')':>9s}"
        print(hdr)
        for k in KEYS:
            col = {var: np.array([r[var][s][k] for s in seeds]) for var in variants}
            line = f"{k:26s}"
            for v in variants:
                line += (f" {col[v].mean():11.4f}+-{col[v].std(ddof=1):<6.4f}"
                         f" {col[v].min():8.3f}..{col[v].max():<7.3f}")
            for v in others:
                d = col[v].mean() - col[base].mean()
                per_design_delta[(v, k)].append(d)
                line += f" {d:+9.4f}"
            print(line)
        print()

    for v in others:
        print(f"=== paired across designs ({v} - {base}, means over seeds) ===")
        print(f"{'metric':26s} {'per-design deltas':>40s} {'mean':>9s} {'sd':>8s} "
              f"{'t':>7s} {'same sign?':>11s}")
        for k in KEYS:
            d = np.array(per_design_delta[(v, k)])
            t = (d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))
                 if d.std(ddof=1) else float("nan"))
            same = "YES" if np.all(d > 0) or np.all(d < 0) else "no"
            print(f"{k:26s} {' '.join(f'{x:+7.3f}' for x in d):>40s} "
                  f"{d.mean():+9.4f} {d.std(ddof=1):8.4f} {t:7.2f} {same:>11s}")
        print()

    print()
    print("noise floors measured on this box, for scale:")
    for k, v in FLOOR_SAME_SEED.items():
        print(f"  {k:26s} identical seed twice: {v:.4f}   "
              f"different seeds: {FLOOR_DIFF_SEED[k]:.4f}")


if __name__ == "__main__":
    main()
