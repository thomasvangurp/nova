set -e
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=4
./fast_python.sh bt_run.py bt_b1.yaml --runs warm1:A --seed 7 --out /root/fastscore/bt/res_warm.json
./fast_python.sh bt_run.py bt_b4.yaml --runs warm4:ABCD --seed 7 --out /root/fastscore/bt/res_warm4.json
