#!/usr/bin/env bash
# Does a 50-step design stage change the SCORE, not just the template?
#
# Chain A's internal geometry -- the only thing folding consumes from the
# design output -- is reproduced at 50 steps to 0.145 A, inside the 0.13 A
# spread of independent 500-step runs. That is necessary but not sufficient:
# confirm it downstream by folding both design sets with repeats and comparing
# the score DISTRIBUTIONS, because the scorer is not reproducible even at a
# fixed seed (design_iiptm floor 0.0048, seed-to-seed spread 0.04).
cd /root/fastscore
rm -f dstest.done
export CUDA_VISIBLE_DEVICES=5

./fast_python.sh sweep_budget.py fold_res.yaml \
  --source-dir design_sweep/steps500 --work-root /root/fastscore/ds_work500 \
  --variants 200x5 --repeats 4 --out /root/fastscore/ds500.json > run_ds500.log 2>&1

./fast_python.sh sweep_budget.py fold_res.yaml \
  --source-dir design_sweep/steps50 --work-root /root/fastscore/ds_work50 \
  --variants 200x5 --repeats 4 --out /root/fastscore/ds50.json > run_ds50.log 2>&1

touch dstest.done
