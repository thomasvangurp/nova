"""Hoist loop-invariant work out of BoltzGen's 200-step denoising loop.

Every change here is value-identical, not merely close. The kernel profile of
one folding call (11.54s CUDA) motivates each one:

  aten::copy_                 2.323s  20.1%  61,760 calls
  Memcpy DtoH (-> Pageable)   0.874s   7.6%   7,107 calls

1. `.item()` x3 per step (600 blocking device->host reads). The sampling
   schedule is computed once, on device, then read back one scalar at a time
   inside the loop. Reading the whole schedule to python floats up front gives
   the same float32 values with no per-step sync.

2. The conditioning tensors (`q`, `c`, `atom_enc_bias`, `atom_dec_bias`,
   `token_trans_bias`) come out of the trunk in bf16 and are `.float()`-cast
   inside DiffusionModule.forward on every step. Casting once before the loop
   makes those calls no-ops -- `Tensor.to` returns `self` when the dtype
   already matches -- so the identical float32 values reach the network
   without being rebuilt 200 times.

3. `s_trunk`, `s_inputs` and `token_pad_mask` are `repeat_interleave`d to the
   diffusion multiplicity on every step from tensors that never change. Cached
   per sample() call, keyed on object identity, with the source tensor held in
   the cache so an id cannot be recycled while the entry lives.

4. `coords_traj` / `x0_coords_traj` retain all 201 intermediate coordinate
   tensors. The folding writer does not read them; retaining them only denies
   the caching allocator the reuse.

Guarded by BOLTZGEN_NO_HOIST=1 for an A/B against the unpatched path.
"""
import pathlib, sys

SRC = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(
    "/root/fastscore/bgen_fast/src/boltzgen")
p = SRC / "model/modules/diffusion.py"
t = p.read_text()
orig = t

# ---------------------------------------------------------------- helper block
HELPERS = '''

# --- loop-invariant hoisting (see patch_hoist.py) ----------------------------
import os as _os

_HOIST = _os.environ.get("BOLTZGEN_NO_HOIST") != "1"


def _hoist_float(cond):
    """float32 copies of the conditioning tensors, made once per sample()."""
    if not _HOIST or cond is None:
        return cond
    out = {}
    for k, v in cond.items():
        out[k] = v.float() if torch.is_tensor(v) and v.is_floating_point() else v
    return out


def _rep(cache, x, multiplicity):
    """repeat_interleave(x, multiplicity, 0), memoised for one sample() call.

    The source tensor is stored alongside the result so its id stays live for
    as long as the cache entry does; without that, a freed tensor's id could be
    reused by a different tensor and silently return the wrong expansion.
    """
    if cache is None or multiplicity == 1:
        return x.repeat_interleave(multiplicity, 0)
    key = (id(x), multiplicity)
    hit = cache.get(key)
    if hit is not None:
        return hit[1]
    out = x.repeat_interleave(multiplicity, 0)
    cache[key] = (x, out)
    return out

'''

anchor = "class DiffusionModule(Module):"
assert t.count(anchor) == 1
t = t.replace(anchor, HELPERS + "\n" + anchor, 1)

# ------------------------------------------------- 3. cached repeat_interleave
for old, new in [
    ("                s_trunk.repeat_interleave(multiplicity, 0),\n"
     "                s_inputs.repeat_interleave(multiplicity, 0),\n"
     "            )\n"
     "        else:\n"
     "            s, normed_fourier = self.single_conditioner(\n"
     "                times,\n"
     "                s_trunk.repeat_interleave(multiplicity, 0),\n"
     "                s_inputs.repeat_interleave(multiplicity, 0),\n"
     "            )",
     "                _rep(getattr(self, '_rep_cache', None), s_trunk, multiplicity),\n"
     "                _rep(getattr(self, '_rep_cache', None), s_inputs, multiplicity),\n"
     "            )\n"
     "        else:\n"
     "            s, normed_fourier = self.single_conditioner(\n"
     "                times,\n"
     "                _rep(getattr(self, '_rep_cache', None), s_trunk, multiplicity),\n"
     "                _rep(getattr(self, '_rep_cache', None), s_inputs, multiplicity),\n"
     "            )"),
    ('        mask = feats["token_pad_mask"].repeat_interleave(multiplicity, 0)',
     '        mask = _rep(getattr(self, "_rep_cache", None), feats["token_pad_mask"], multiplicity)'),
]:
    assert t.count(old) == 1, f"anchor not unique/found:\n{old[:120]}"
    t = t.replace(old, new, 1)

# ------------------------------------------------------ 1. schedule off-device
old = "            sigma_tm, sigma_t, gamma = sigma_tm.item(), sigma_t.item(), gamma.item()"
assert t.count(old) == 1
t = t.replace(old, "            # values already python floats: see the schedule hoist below\n"
                   "            if torch.is_tensor(sigma_tm):\n"
                   "                sigma_tm, sigma_t, gamma = sigma_tm.item(), sigma_t.item(), gamma.item()", 1)

old = """        sigmas_gammas_ss_ns = list(
            zip(
                sigmas[:-1],
                sigmas[1:],
                gammas[1:],
                step_scales,
                noise_scales,
            )
        )"""
assert t.count(old) == 1
new = """        if _HOIST:
            # One device->host transfer for the whole schedule instead of three
            # per step. Same float32 values; .item() and .tolist() both widen a
            # float32 to a python float identically.
            _sig = sigmas.tolist()
            _gam = gammas.tolist()
            _ss = step_scales.tolist()
            _ns = noise_scales.tolist()
            sigmas_gammas_ss_ns = list(
                zip(_sig[:-1], _sig[1:], _gam[1:], _ss, _ns)
            )
        else:
            sigmas_gammas_ss_ns = list(
                zip(
                    sigmas[:-1],
                    sigmas[1:],
                    gammas[1:],
                    step_scales,
                    noise_scales,
                )
            )"""
t = t.replace(old, new, 1)

# --------------------------------- 2 + 3 setup: prepare conditioning per sample
old = """        # atom position is noise at the beginning
        init_sigma = sigmas[0]"""
assert t.count(old) == 1
new = """        if _HOIST:
            network_condition_kwargs["diffusion_conditioning"] = _hoist_float(
                network_condition_kwargs.get("diffusion_conditioning")
            )
            self.net._rep_cache = {}

        # atom position is noise at the beginning
        init_sigma = sigmas[0]"""
t = t.replace(old, new, 1)

# ------------------------------------------------ 4. drop unused trajectories
old = """            coords_traj.append(atom_coords_next)
            x0_coords_traj.append(atom_coords_denoised)
            atom_coords = atom_coords_next
        coords_traj.append(atom_coords)"""
assert t.count(old) == 1
new = """            if not _HOIST:
                coords_traj.append(atom_coords_next)
                x0_coords_traj.append(atom_coords_denoised)
            atom_coords = atom_coords_next
        if not _HOIST:
            coords_traj.append(atom_coords)
        else:
            # the folding writer reads sample_atom_coords only; keeping 201
            # intermediates alive just denies the allocator their reuse
            coords_traj = [atom_coords]
            x0_coords_traj = [atom_coords_denoised]"""
t = t.replace(old, new, 1)

# release the per-sample cache
old = """        result = dict(
            sample_atom_coords=atom_coords,"""
assert t.count(old) == 1
t = t.replace(old, """        if _HOIST:
            self.net._rep_cache = None

        result = dict(
            sample_atom_coords=atom_coords,""", 1)

assert t != orig
p.write_text(t)
print(f"patched {p}")
