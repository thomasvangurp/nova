"""Pool the two independent validation rounds (disjoint seed sets).

Each round folds every design under every variant at 5 seeds. Within a round
all designs share the same seeds, so their deltas are correlated and a
"same sign across 4 designs" test inside one round is weaker than it looks.
Pooling two rounds run on disjoint seeds gives 8 independent-ish design-rounds
and lets the sign test mean something.

The reference scale for every metric is taken from the data itself: the
seed-to-seed sd of the REAL variant, which is the irreducible scorer noise.
"""
from __future__ import annotations
import argparse, json
import numpy as np

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results", nargs="+")
    a = ap.parse_args()

    deltas = {}          # (variant, metric) -> list of per design-round deltas
    real_sd = {k: [] for k in KEYS}
    for path in a.results:
        res = json.loads(open(path).read())
        for name, r in res.items():
            seeds = sorted(set.intersection(*[set(v) for v in r.values()]), key=int)
            real = {k: np.array([r["real"][s][k] for s in seeds]) for k in KEYS}
            for k in KEYS:
                real_sd[k].append(real[k].std(ddof=1))
            for var in r:
                if var == "real":
                    continue
                for k in KEYS:
                    v = np.array([r[var][s][k] for s in seeds])
                    deltas.setdefault((var, k), []).append(v.mean() - real[k].mean())

    variants = sorted({v for v, _ in deltas})
    print(f"pooled over {len(a.results)} rounds x 4 designs\n")
    for var in variants:
        print(f"=== {var} - real ===")
        print(f"{'metric':26s} {'real seed sd':>13s} {'mean delta':>11s} "
              f"{'sd':>8s} {'|delta|/sd':>11s} {'t':>7s} {'signs':>9s}")
        for k in KEYS:
            d = np.array(deltas[(var, k)])
            sd_noise = float(np.mean(real_sd[k]))
            t = d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))
            signs = f"{int((d > 0).sum())}+/{int((d < 0).sum())}-"
            print(f"{k:26s} {sd_noise:13.4f} {d.mean():+11.4f} {d.std(ddof=1):8.4f} "
                  f"{abs(d.mean())/sd_noise:11.2f} {t:7.2f} {signs:>9s}")
        print()


if __name__ == "__main__":
    main()
