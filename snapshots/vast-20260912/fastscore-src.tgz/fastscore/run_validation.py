"""Fold real vs synthesized design outputs over several seeds and compare.

The scorer is not bit-reproducible: same config and seed twice moves
design_iiptm by ~0.005 and min_design_to_target_pae by ~0.18, and different
seeds move them by ~0.04 and ~1.2. A single paired fold therefore proves
nothing, so this runs every design under both variants at N seeds from ONE
resident model and reports distributions.

Each (variant, seed) gets its own directory because the FoldingWriter writes
fold_out_npz/ and refold_cif/ inside design_dir.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/root/fastscore")
from resident import ResidentStage, seed_all

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def best_sample(d) -> dict:
    """The validator scores ONE diffusion sample, chosen by this argmax."""
    conf = 0.8 * np.asarray(d["design_to_target_iptm"], float) \
         + 0.2 * np.asarray(d["design_ptm"], float)
    i = int(np.argmax(conf))
    return {k: float(np.asarray(d[k], float)[i]) for k in KEYS}


def stage_dir(root: Path, variant: str, seed: int, srcs: list[Path]) -> Path:
    d = root / f"{variant}_s{seed}"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for cif in srcs:
        shutil.copy(cif, d / cif.name)
        shutil.copy(cif.with_suffix(".npz"), d / (cif.stem + ".npz"))
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variants", nargs="+", required=True,
                    help="name=dir; the first is the baseline")
    ap.add_argument("--work", required=True)
    ap.add_argument("--config", default="/root/fastscore/fold_res.yaml")
    ap.add_argument("--seeds", type=int, nargs="+", default=[11, 22, 33, 44, 55])
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    variants = dict(v.split("=", 1) for v in a.variants)
    srcs = {k: sorted(Path(d).glob("*_input.cif")) for k, d in variants.items()}
    names = [[p.name for p in v] for v in srcs.values()]
    assert all(n == names[0] for n in names), "design sets differ across variants"
    print(f"{len(names[0])} designs x {len(a.seeds)} seeds x "
          f"{len(variants)} variants {list(variants)}", flush=True)

    root = Path(a.work)
    dirs = {(v, s): stage_dir(root, v, s, srcs[v])
            for v in variants for s in a.seeds}

    stage = ResidentStage(a.config)
    print(f"model load: {stage.load_seconds:.1f}s", flush=True)

    results = {}
    for seed in a.seeds:
        for variant in variants:
            d = dirs[(variant, seed)]
            seed_all(seed)
            t = stage.run_batch({"data.design_dir": str(d), "output": str(d)})
            got = 0
            for f in sorted((d / "fold_out_npz").glob("*.npz")):
                with np.load(f, allow_pickle=True) as z:
                    results.setdefault(f.name, {}).setdefault(variant, {})[str(seed)] = \
                        best_sample(dict(z))
                got += 1
            print(f"{variant} seed {seed}: {t:.1f}s, {got} folded", flush=True)
            Path(a.out).write_text(json.dumps(results, indent=1))

    Path(a.out).write_text(json.dumps(results, indent=1))
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
