"""Let the folding step predict more than one design per forward.

`AtomDiffusion.sample` draws its per-step random augmentation with
`compute_random_augmentation(multiplicity, ...)`, but applies it to
`atom_coords`, whose leading dimension is batch * multiplicity. At the
production `data.cfg.batch_size: 1` those are equal, so the bug is invisible;
at batch_size 4 the einsum fails outright:

    RuntimeError: einsum(): subscript b has size 5 for operand 1
                  which does not broadcast with previously seen size 20

Using the actual leading dimension gives every design in the batch its own
augmentation, which is what a batch of independent designs should get, and is
a no-op at batch_size 1 -- the production path draws the same number of
rotations from the same generator in the same order.
"""
import pathlib, sys

SRC = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(
    "/root/fastscore/bgen_fast/src/boltzgen")
p = SRC / "model/modules/diffusion.py"
t = p.read_text()

old = """                random_R, random_tr = compute_random_augmentation(
                    multiplicity, device=atom_coords.device, dtype=atom_coords.dtype
                )"""
assert t.count(old) == 1, "anchor not found"
new = """                random_R, random_tr = compute_random_augmentation(
                    # atom_coords is (batch * multiplicity, m, 3); passing
                    # `multiplicity` only matches when batch == 1
                    atom_coords.shape[0],
                    device=atom_coords.device,
                    dtype=atom_coords.dtype,
                )"""
t = t.replace(old, new, 1)
p.write_text(t)
print("patched", p)
