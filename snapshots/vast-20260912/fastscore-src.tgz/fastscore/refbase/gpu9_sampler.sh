#!/usr/bin/env bash
# Read-only contention sampler for GPU 9.  The live miner also schedules onto
# GPU 9, so the reference arm's wall-clock is not a clean-machine number and the
# amount of foreign load has to be recorded alongside it.
OUT=/root/fastscore/refbase/out/gpu9_samples.csv
UUID=$(nvidia-smi --query-gpu=index,uuid --format=csv,noheader | awk -F', ' '$1==9{print $2}')
echo "epoch,util_pct,mem_used_mib,n_compute_procs,n_foreign_procs,foreign_mem_mib" > "$OUT"
while true; do
  read -r util mem < <(nvidia-smi -i 9 --query-gpu=utilization.gpu,memory.used --format=csv,noheader,nounits | tr -d ',')
  apps=$(nvidia-smi --query-compute-apps=pid,gpu_uuid,used_memory --format=csv,noheader,nounits | awk -F', ' -v u="$UUID" '$2==u{print $1" "$3}')
  mine=$(ps -ef | grep "[r]efbase/bin/score_boltzgen_batch.py" | awk '{print $2}' | tr '\n' ' ')
  n=0; nf=0; fm=0
  while read -r pid m; do
    [ -z "$pid" ] && continue
    n=$((n+1))
    case " $mine " in *" $pid "*) ;; *) nf=$((nf+1)); fm=$((fm+m));; esac
  done <<< "$apps"
  echo "$(date +%s),$util,$mem,$n,$nf,$fm" >> "$OUT"
  sleep 20
done
