#!/usr/bin/env python3
"""Read-only contention sampler for GPU 9.

GPU 9 is not ours alone: the live miner schedules onto --gpus 0..9, and
nvidia-smi also reports PIDs that do not exist in this container's PID
namespace, i.e. other vast.ai tenants on the same host.  The reference arm's
wall-clock is therefore not a clean-machine number, and the foreign load has to
be recorded next to it.  Samples only; touches nothing.
"""
import csv
import os
import subprocess
import sys
import time

OUT = "/root/fastscore/refbase/out/gpu9_samples.csv"
MARKER = "refbase/bin/score_boltzgen_batch.py"


def smi(args):
    try:
        return subprocess.run(["nvidia-smi"] + args, capture_output=True,
                              text=True, timeout=30).stdout.strip()
    except Exception:
        return ""


def uuid9():
    for line in smi(["--query-gpu=index,uuid", "--format=csv,noheader"]).splitlines():
        idx, _, uid = line.partition(", ")
        if idx.strip() == "9":
            return uid.strip()
    return None


def proc_table():
    """pid -> (ppid, cmdline); only PIDs visible in this container."""
    table = {}
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        pid = int(name)
        try:
            with open(f"/proc/{pid}/stat") as fh:
                fields = fh.read().rsplit(") ", 1)[1].split()
            ppid = int(fields[1])
            with open(f"/proc/{pid}/cmdline", "rb") as fh:
                cmd = fh.read().replace(b"\0", b" ").decode("utf-8", "replace")
        except Exception:
            continue
        table[pid] = (ppid, cmd)
    return table


def my_tree(table):
    """Every PID descended from (or being) a refbase scorer invocation."""
    roots = {pid for pid, (_, cmd) in table.items() if MARKER in cmd}
    children = {}
    for pid, (ppid, _) in table.items():
        children.setdefault(ppid, []).append(pid)
    mine, stack = set(roots), list(roots)
    while stack:
        pid = stack.pop()
        for child in children.get(pid, []):
            if child not in mine:
                mine.add(child)
                stack.append(child)
    return mine


def main():
    uid = uuid9()
    new = not os.path.exists(OUT)
    with open(OUT, "a", newline="") as fh:
        writer = csv.writer(fh)
        if new:
            writer.writerow(["epoch", "util_pct", "mem_used_mib", "n_procs",
                             "n_mine", "mine_mem_mib", "n_foreign_container",
                             "foreign_container_mem_mib", "n_other_tenant",
                             "other_tenant_mem_mib"])
            fh.flush()
        while True:
            util_mem = smi(["-i", "9",
                            "--query-gpu=utilization.gpu,memory.used",
                            "--format=csv,noheader,nounits"])
            parts = [p.strip() for p in util_mem.split(",")] if util_mem else ["", ""]
            table = proc_table()
            mine = my_tree(table)
            n = n_mine = n_foreign = n_other = 0
            m_mine = m_foreign = m_other = 0
            for line in smi(["--query-compute-apps=pid,gpu_uuid,used_memory",
                             "--format=csv,noheader,nounits"]).splitlines():
                bits = [b.strip() for b in line.split(", ")]
                if len(bits) != 3 or bits[1] != uid:
                    continue
                pid, mem = int(bits[0]), int(bits[2] or 0)
                n += 1
                if pid in mine:
                    n_mine += 1
                    m_mine += mem
                elif pid in table:
                    n_foreign += 1
                    m_foreign += mem
                else:
                    n_other += 1
                    m_other += mem
            writer.writerow([int(time.time()), parts[0], parts[1], n,
                             n_mine, m_mine, n_foreign, m_foreign,
                             n_other, m_other])
            fh.flush()
            time.sleep(15)


if __name__ == "__main__":
    sys.exit(main())
