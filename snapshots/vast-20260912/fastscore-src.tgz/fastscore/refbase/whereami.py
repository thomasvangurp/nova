#!/usr/bin/env python3
"""Which GPU is the reference run actually on, and is the tree walk seeing it?"""
import os
import subprocess

MARKER = "refbase/bin/score_boltzgen_batch.py"

table = {}
for name in os.listdir("/proc"):
    if not name.isdigit():
        continue
    pid = int(name)
    try:
        fields = open(f"/proc/{pid}/stat").read().rsplit(") ", 1)[1].split()
        ppid = int(fields[1])
        cmd = open(f"/proc/{pid}/cmdline", "rb").read().replace(b"\0", b" ").decode(
            "utf-8", "replace")
    except Exception:
        continue
    table[pid] = (ppid, cmd)

roots = {p for p, (_, c) in table.items() if MARKER in c}
children = {}
for p, (pp, _) in table.items():
    children.setdefault(pp, []).append(p)
mine, stack = set(roots), list(roots)
while stack:
    p = stack.pop()
    for k in children.get(p, []):
        if k not in mine:
            mine.add(k)
            stack.append(k)

print("roots:", sorted(roots))
print("descendants:", len(mine))
for p in sorted(mine):
    try:
        cvd = [v.split("=", 1)[1] for v in
               open(f"/proc/{p}/environ").read().split("\0")
               if v.startswith("CUDA_VISIBLE_DEVICES=")]
    except Exception:
        cvd = ["?"]
    print(f"  {p:>8} CUDA_VISIBLE_DEVICES={cvd or ['<unset>']} :: {table[p][1][:120]}")

uuid_of = {}
for line in subprocess.run(
        ["nvidia-smi", "--query-gpu=index,uuid", "--format=csv,noheader"],
        capture_output=True, text=True).stdout.splitlines():
    idx, _, uid = line.partition(", ")
    uuid_of[uid.strip()] = idx.strip()

print("compute apps:")
for line in subprocess.run(
        ["nvidia-smi", "--query-compute-apps=pid,gpu_uuid,used_memory",
         "--format=csv,noheader,nounits"],
        capture_output=True, text=True).stdout.splitlines():
    bits = [b.strip() for b in line.split(", ")]
    if len(bits) != 3:
        continue
    pid = int(bits[0])
    who = "MINE" if pid in mine else ("this-container" if pid in table
                                      else "other-tenant")
    cmd = table.get(pid, (0, ""))[1][:90]
    print(f"  gpu{uuid_of.get(bits[1], '?'):>3} pid {pid:>8} {bits[2]:>7} MiB "
          f"[{who}] {cmd}")
