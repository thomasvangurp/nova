"""Pick 12 length-127 archive sequences stratified across the quality range.

Quality is the validator's own statistic: the dense per-metric rank sum over the
ten scored metrics (lower = better), computed WITHIN the length-127 subset so the
strata are comparable.  The subset is sorted by (rank_sum, sequence_hash), split
into 12 contiguous equal-size strata, and the median element of each stratum is
taken.  Deterministic, no RNG.
"""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, "/root")
from nanobody_opt.simulate_round import METRICS, METRIC_CATEGORIES, dense_rank_sums

CSV = "/root/P20809_nanobodies.csv"
OUT_DIR = Path("/root/fastscore/refbase")
LENGTH = 127
N_PICK = 12

df = pd.read_csv(CSV)
print(f"archive rows: {len(df)}")
df["length"] = df["sequence"].str.len()
modal = df["length"].value_counts()
print("top lengths:")
print(modal.head(5).to_string())
assert modal.idxmax() == LENGTH, f"modal length is {modal.idxmax()}, not {LENGTH}"

sub = df[df["length"] == LENGTH].copy()
print(f"length-{LENGTH} rows: {len(sub)}")
# drop duplicate sequences and any row with a non-finite metric
sub = sub.drop_duplicates(subset="sequence")
sub = sub.dropna(subset=list(METRICS))
sub = sub.reset_index(drop=True)
print(f"after dedupe/dropna: {len(sub)}")

sub["rank_sum"] = dense_rank_sums(sub, METRICS)
for cat, names in METRIC_CATEGORIES.items():
    sub[f"{cat}_rank_sum"] = dense_rank_sums(sub, {m: METRICS[m] for m in names})

sub = sub.sort_values(["rank_sum", "sequence_hash"], kind="mergesort").reset_index(drop=True)

n = len(sub)
picked_idx = []
for k in range(N_PICK):
    lo = (k * n) // N_PICK
    hi = ((k + 1) * n) // N_PICK
    picked_idx.append(lo + (hi - lo) // 2)
picked = sub.loc[picked_idx].copy()
picked["stratum"] = range(1, N_PICK + 1)
picked["percentile_of_rank_sum"] = [
    100.0 * i / (n - 1) for i in picked_idx
]

seqs = picked["sequence"].tolist()
assert len(set(seqs)) == N_PICK
assert all(len(s) == LENGTH for s in seqs)

(OUT_DIR / "seqs12.json").write_text(json.dumps(seqs, indent=2) + "\n")

cols = ["stratum", "sequence_hash", "rank_sum", "percentile_of_rank_sum",
        "confidence_rank_sum", "physical_interaction_rank_sum",
        "developability_rank_sum"] + list(METRICS)
meta = picked[["sequence"] + cols].copy()
meta["sha256"] = [hashlib.sha256(s.encode()).hexdigest() for s in seqs]
meta.to_csv(OUT_DIR / "seqs12_archive_metrics.csv", index=False)

pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 50)
print()
print(f"selected {N_PICK} of {n} length-{LENGTH} sequences "
      f"(rank_sum range over subset: {sub['rank_sum'].min():.0f}..{sub['rank_sum'].max():.0f})")
print(picked[cols].to_string(index=False))
print()
print("prefixes:")
for i, s in enumerate(seqs, 1):
    print(f"  stratum {i:2d}  {hashlib.sha256(s.encode()).hexdigest()[:12]}  {s[:24]}...{s[-10:]}")
