#!/usr/bin/env bash
# Reference arm: 4 independent invocations of the UNMODIFIED production scorer
# (copy differing only in the shard-root path) over the same 12 sequences.
# Strictly sequential: one GPU process at a time, GPU 9 only.
set -u
R=/root/fastscore/refbase

echo "host $(hostname) start $(date -Is)" > "$R/out/timing.txt"
for i in 1 2 3 4; do
  echo "=== repeat $i start $(date -Is) ==="
  rm -rf "$R/shards"
  mkdir -p "$R/shards"
  s=$(date +%s.%N)
  /root/bgen_python.sh "$R/bin/score_boltzgen_batch.py" \
    --sequences "$R/seqs12.json" \
    --config /root/config/config.yaml \
    --target P20809 \
    --gpus 9 --shards-per-gpu 1 --batch-size 4 \
    --work-root "$R/shards" \
    --out "$R/out/rep${i}.json" > "$R/out/rep${i}.log" 2>&1
  rc=$?
  e=$(date +%s.%N)
  awk -v s="$s" -v e="$e" -v i="$i" -v rc="$rc" \
    'BEGIN{printf "repeat %d rc=%d wall_seconds=%.2f sec_per_seq=%.2f\n", i, rc, e-s, (e-s)/12}' \
    >> "$R/out/timing.txt"
  tail -1 "$R/out/timing.txt"
  if [ "$rc" -ne 0 ]; then echo "repeat $i FAILED (rc=$rc); continuing"; fi
done
echo "end $(date -Is)" >> "$R/out/timing.txt"
echo "ALL_REPEATS_DONE"
