#!/usr/bin/env python3
"""Is the local/archive gap on strata 1-8 our run, or the archive's scoring era?

Cross-checks the reference arm against base4.json -- a pre-existing run of the
same production path made before this task -- and against the archive's own era
marker (delta_sasa_refolded ~1220 for old rows, ~717 for recent ones, per the
note in nanobody_opt/simulate_round.py).
"""
import csv
import json
import statistics

arch = {r["sequence"]: r for r in csv.DictReader(open("/root/P20809_nanobodies.csv"))}


def flat(path):
    d = json.load(open(path))
    return {s: v["P20809"] for by in (d.get("per_nanobody_components") or d["components"]).values()
            for s, v in by.items()}


print("base4.json -- pre-existing run of the SAME production path:")
for s, m in flat("/root/fastscore/base4.json").items():
    a = arch.get(s)
    av = f'{float(a["design_iiptm"]):.4f}' if a else "NOT-IN-ARCHIVE"
    asa = f'{float(a["delta_sasa_refolded"]):.0f}' if a else "-"
    print(f"  local iiptm {m['design_iiptm']:.4f} sasa {m['delta_sasa_refolded']:>7.0f}"
          f"   archive iiptm {av} sasa {asa:>7}")

print()
print("reference arm, local mean vs archive, with the era marker:")
seqs = json.load(open("/root/fastscore/refbase/seqs12.json"))
reps = [flat(f"/root/fastscore/refbase/out/rep{i}.json") for i in (1, 2, 3, 4)]
print(f"{'str':>3} {'local_iiptm':>12} {'arch_iiptm':>11} {'delta':>8} "
      f"{'local_sasa':>11} {'arch_sasa':>10} {'era':>8}")
loc, arc = [], []
for k, s in enumerate(seqs, 1):
    li = statistics.fmean(r[s]["design_iiptm"] for r in reps)
    ls = statistics.fmean(r[s]["delta_sasa_refolded"] for r in reps)
    a = arch[s]
    ai, asa = float(a["design_iiptm"]), float(a["delta_sasa_refolded"])
    era = "old" if asa > 1000 else "recent"
    loc.append(li)
    arc.append(ai)
    print(f"{k:>3} {li:>12.4f} {ai:>11.4f} {li - ai:>8.4f} "
          f"{ls:>11.0f} {asa:>10.0f} {era:>8}")


def spearman(x, y):
    def rank(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        r = [0.0] * len(v)
        for pos, i in enumerate(order):
            r[i] = pos + 1.0
        return r
    rx, ry = rank(x), rank(y)
    mx, my = statistics.fmean(rx), statistics.fmean(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = (sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry)) ** 0.5
    return num / den if den else float("nan")


print()
print(f"spearman(local mean design_iiptm, archive design_iiptm) over 12 = "
      f"{spearman(loc, arc):.3f}")
old = [i for i, s in enumerate(seqs) if float(arch[s]['delta_sasa_refolded']) > 1000]
new = [i for i, s in enumerate(seqs) if float(arch[s]['delta_sasa_refolded']) <= 1000]
print(f"  old-era rows (n={len(old)}): local mean "
      f"{statistics.fmean(loc[i] for i in old):.4f} vs archive "
      f"{statistics.fmean(arc[i] for i in old):.4f}")
print(f"  recent-era rows (n={len(new)}): local mean "
      f"{statistics.fmean(loc[i] for i in new):.4f} vs archive "
      f"{statistics.fmean(arc[i] for i in new):.4f}")

print()
print("archive-wide era check over the length-127 subset:")
rows = [r for r in arch.values() if len(r["sequence"]) == 127]
hi = [float(r["design_iiptm"]) for r in rows if float(r["delta_sasa_refolded"]) > 1000]
lo = [float(r["design_iiptm"]) for r in rows if float(r["delta_sasa_refolded"]) <= 1000]
print(f"  delta_sasa>1000 (old era): n={len(hi)} mean design_iiptm "
      f"{statistics.fmean(hi):.4f}")
print(f"  delta_sasa<=1000 (recent): n={len(lo)} mean design_iiptm "
      f"{statistics.fmean(lo):.4f}")
