#!/usr/bin/env bash
# Block until the runner reports all four repeats done, then summarize.
R=/root/fastscore/refbase
for i in $(seq 1 200); do
  if grep -q "ALL_REPEATS_DONE" "$R/out/runner.log" 2>/dev/null; then break; fi
  sleep 20
done
if ! grep -q "ALL_REPEATS_DONE" "$R/out/runner.log" 2>/dev/null; then
  echo "STILL RUNNING after wait; current timing:"
  cat "$R/out/timing.txt"
  exit 3
fi
# stop the contention sampler (started by us, nothing else)
for p in $(ps -ef | awk '/[g]pu9_sampler\.py/{print $2}'); do kill "$p" 2>/dev/null; done
echo "=== timing.txt ==="
cat "$R/out/timing.txt"
echo "=== summarize ==="
/root/bgen_python.sh "$R/summarize.py"
