"""Collapse the 4 reference repeats into a distribution per sequence per metric.

The production scorer is stochastic, so the reference arm is a mean and a
sample sd (ddof=1) over 4 independent invocations, not a single number.
"""
from __future__ import annotations
import hashlib
import json
import math
import re
import statistics
from pathlib import Path

import pandas as pd

R = Path("/root/fastscore/refbase")
OUT = R / "out"
TARGET = "P20809"
METRICS = [
    "design_iiptm", "design_ptm", "design_to_target_iptm",
    "min_design_to_target_pae", "interaction_pae",
    "plip_hbonds_refolded", "plip_saltbridge_refolded", "delta_sasa_refolded",
    "liability_score", "liability_num_violations",
]
CONFIDENCE = METRICS[:5]

seqs = json.loads((R / "seqs12.json").read_text())
arch = pd.read_csv(R / "seqs12_archive_metrics.csv").set_index("sequence")

# ---- timings -------------------------------------------------------------
timings = {}
for line in (OUT / "timing.txt").read_text().splitlines():
    m = re.match(r"repeat (\d+) rc=(\d+) wall_seconds=([\d.]+) sec_per_seq=([\d.]+)", line)
    if m:
        timings[int(m.group(1))] = {
            "rc": int(m.group(2)),
            "wall_seconds": float(m.group(3)),
            "gpu_seconds_per_sequence": float(m.group(4)),
        }

# ---- GPU 9 contention ----------------------------------------------------
# GPU 9 is not ours alone: the live miner schedules onto --gpus 0..9 and
# nvidia-smi reports PIDs outside this container (other vast.ai tenants on the
# same host).  Record how much foreign load each repeat ran against.
starts = {}
for line in (OUT / "runner.log").read_text().splitlines():
    m = re.match(r"=== repeat (\d+) start (\S+) ===", line)
    if m:
        starts[int(m.group(1))] = pd.Timestamp(m.group(2)).timestamp()

samples = None
sample_path = OUT / "gpu9_samples.csv"
if sample_path.is_file():
    samples = pd.read_csv(sample_path)
    for col in samples.columns:
        samples[col] = pd.to_numeric(samples[col], errors="coerce")


def contention(repeat: int, wall: float | None) -> dict | None:
    if samples is None or repeat not in starts or wall is None:
        return None
    t0 = starts[repeat]
    window = samples[(samples["epoch"] >= t0) & (samples["epoch"] <= t0 + wall)]
    if window.empty:
        return None
    procs = window["n_procs"]
    return {
        "n_samples": int(len(window)),
        "gpu9_util_pct_mean": float(window["util_pct"].mean()),
        "gpu9_util_pct_max": float(window["util_pct"].max()),
        "gpu9_mem_used_mib_mean": float(window["mem_used_mib"].mean()),
        "gpu9_mem_used_mib_max": float(window["mem_used_mib"].max()),
        "n_compute_procs_mean": float(procs.mean()),
        "n_compute_procs_max": int(procs.max()),
        "frac_samples_multi_proc": float((procs > 1).mean()),
        "attribution_caveat": (
            "nvidia-smi inside this container reports HOST pids, which do not "
            "resolve in our /proc; per-process attribution is therefore "
            "impossible from here and these totals include our own work. "
            "Samples with >1 compute process on GPU 9 are the ones where "
            "something else was definitely sharing the device."
        ),
    }


# ---- load repeats --------------------------------------------------------
repeats = []
for i in (1, 2, 3, 4):
    path = OUT / f"rep{i}.json"
    if not path.is_file():
        repeats.append({"repeat": i, "file": str(path), "present": False})
        continue
    d = json.loads(path.read_text())
    comp = d["per_nanobody_components"]
    by_seq = {}
    for uid, per_seq in comp.items():
        for seq, per_target in per_seq.items():
            by_seq[seq] = per_target.get(TARGET, {})
    rec = {
        "repeat": i,
        "file": str(path),
        "present": True,
        "scorer_wall_seconds_internal": d.get("wall_seconds"),
        "observation_id": d.get("observation_id"),
        "predict_batch_size": d.get("predict_batch_size"),
        "scorer_protocol": d.get("scorer_protocol"),
        "n_scored": len(by_seq),
        "_by_seq": by_seq,
    }
    rec.update(timings.get(i, {}))
    rec["gpu9_contention"] = contention(i, rec.get("wall_seconds"))
    repeats.append(rec)

# ---- per-sequence distributions -----------------------------------------
problems = []
sequences = {}
for k, seq in enumerate(seqs, 1):
    h = hashlib.sha256(seq.encode()).hexdigest()
    row = arch.loc[seq]
    entry = {
        "stratum": k,
        "sha256": h,
        "sequence": seq,
        "length": len(seq),
        "archive_rank_sum": float(row["rank_sum"]),
        "archive_rank_sum_percentile": float(row["percentile_of_rank_sum"]),
        "archive_metrics": {m: float(row[m]) for m in METRICS},
        "metrics": {},
    }
    present_repeats = []
    for rep in repeats:
        if not rep.get("present"):
            continue
        got = rep["_by_seq"].get(seq)
        if got is None:
            problems.append(f"repeat {rep['repeat']}: sequence {h[:12]} (stratum {k}) ABSENT")
            continue
        present_repeats.append((rep["repeat"], got))
    for metric in METRICS:
        vals, reps = [], []
        for rnum, got in present_repeats:
            if metric not in got:
                problems.append(
                    f"repeat {rnum}: sequence {h[:12]} (stratum {k}) missing metric {metric}")
                continue
            v = got[metric]
            try:
                v = float(v)
            except (TypeError, ValueError):
                problems.append(
                    f"repeat {rnum}: sequence {h[:12]} metric {metric} non-numeric: {v!r}")
                continue
            if not math.isfinite(v):
                problems.append(
                    f"repeat {rnum}: sequence {h[:12]} metric {metric} non-finite: {v!r}")
                continue
            vals.append(v)
            reps.append(rnum)
        mean = statistics.fmean(vals) if vals else None
        sd = statistics.stdev(vals) if len(vals) > 1 else None
        entry["metrics"][metric] = {
            "repeats": reps,
            "values": vals,
            "n": len(vals),
            "mean": mean,
            "sd": sd,
            "cv": (sd / abs(mean)) if (sd is not None and mean not in (None, 0.0)) else None,
            "min": min(vals) if vals else None,
            "max": max(vals) if vals else None,
            "range": (max(vals) - min(vals)) if vals else None,
        }
    entry["all_ten_metrics_present"] = all(
        entry["metrics"][m]["n"] == len([r for r in repeats if r.get("present")])
        for m in METRICS
    )
    sequences[h] = entry

for rep in repeats:
    rep.pop("_by_seq", None)

walls = [r["wall_seconds"] for r in repeats if r.get("wall_seconds") is not None]
summary = {
    "schema_version": 1,
    "arm": "reference (unmodified production scorer)",
    "target": TARGET,
    "config": "/root/config/config.yaml",
    "scorer": "/root/fastscore/refbase/bin/score_boltzgen_batch.py",
    "scorer_source": "/root/nanobody_opt/score_boltzgen_batch.py",
    "scorer_diff": "work-root default /root/bgen_shards -> /root/fastscore/refbase/shards (path literal only)",
    "runtime": "/root/bgen_python.sh (pixi env bgen, LIVE vendored BoltzGen at /root/external_tools/boltzgen/src)",
    "gpus": "9",
    "batch_size": 4,
    "n_sequences": len(seqs),
    "n_repeats": sum(1 for r in repeats if r.get("present")),
    "metrics": METRICS,
    "confidence_metrics": CONFIDENCE,
    "timing": {
        "per_repeat": repeats,
        "wall_seconds_mean": statistics.fmean(walls) if walls else None,
        "wall_seconds_sd": statistics.stdev(walls) if len(walls) > 1 else None,
        "wall_seconds_min": min(walls) if walls else None,
        "wall_seconds_max": max(walls) if walls else None,
        "gpu_seconds_per_sequence_mean": (statistics.fmean(walls) / len(seqs)) if walls else None,
        "note": "wall-clock on a shared box; the live miner ran concurrently on other GPUs",
    },
    "problems": problems,
    "sequences": sequences,
}
(R / "reference.json").write_text(json.dumps(summary, indent=2) + "\n")

# ---- readable tables -----------------------------------------------------
lines = []
lines.append("REFERENCE ARM -- unmodified production scorer, 4 independent repeats, batch-size 4, GPU 9")
lines.append(f"target {TARGET}   sequences {len(seqs)}   repeats "
             f"{summary['n_repeats']}")
lines.append("")
lines.append("TIMING")
lines.append(f"{'repeat':>7} {'rc':>3} {'wall_s':>10} {'gpu_s/seq':>11} {'scorer_internal_s':>18}")
for rep in repeats:
    if not rep.get("present"):
        lines.append(f"{rep['repeat']:>7} {'--':>3} {'MISSING':>10}")
        continue
    lines.append(f"{rep['repeat']:>7} {rep.get('rc', -1):>3} "
                 f"{rep.get('wall_seconds', float('nan')):>10.1f} "
                 f"{rep.get('gpu_seconds_per_sequence', float('nan')):>11.2f} "
                 f"{rep.get('scorer_wall_seconds_internal') or float('nan'):>18.1f}")
lines.append("")
lines.append("GPU 9 OCCUPANCY DURING EACH REPEAT")
lines.append("  GPU 9 is NOT exclusively ours: the live miner schedules onto "
             "--gpus 0,..,9, and other vast.ai")
lines.append("  tenants share the physical device. nvidia-smi inside this container "
             "reports HOST pids that do")
lines.append("  not resolve in our /proc, so per-process attribution is impossible "
             "from here -- these totals")
lines.append("  include our own work. Samples showing >1 compute process are ones "
             "where something else was")
lines.append("  definitely sharing GPU 9 with us.")
lines.append(f"{'repeat':>7} {'util%_mean':>11} {'util%_max':>10} {'mem_MiB_mean':>13} "
             f"{'mem_MiB_max':>12} {'procs_mean':>11} {'procs_max':>10} "
             f"{'%samples>1proc':>15}")
for rep in repeats:
    c = rep.get("gpu9_contention")
    if not c:
        lines.append(f"{rep['repeat']:>7} {'no samples':>11}")
        continue
    lines.append(f"{rep['repeat']:>7} {c['gpu9_util_pct_mean']:>11.1f} "
                 f"{c['gpu9_util_pct_max']:>10.0f} "
                 f"{c['gpu9_mem_used_mib_mean']:>13.0f} "
                 f"{c['gpu9_mem_used_mib_max']:>12.0f} "
                 f"{c['n_compute_procs_mean']:>11.2f} "
                 f"{c['n_compute_procs_max']:>10d} "
                 f"{100 * c['frac_samples_multi_proc']:>15.1f}")
lines.append("")

if walls:
    lines.append(f"  wall mean {statistics.fmean(walls):.1f}s  "
                 f"sd {statistics.stdev(walls) if len(walls) > 1 else 0:.1f}s  "
                 f"min {min(walls):.1f}s  max {max(walls):.1f}s  "
                 f"spread {(max(walls) - min(walls)) / min(walls) * 100:.1f}%")
    lines.append(f"  GPU-seconds per sequence: mean {statistics.fmean(walls)/len(seqs):.2f}s "
                 f"(range {min(walls)/len(seqs):.2f}..{max(walls)/len(seqs):.2f})")
lines.append("")

for group_name, group in (("CONFIDENCE METRICS", CONFIDENCE),
                          ("REMAINING METRICS", METRICS[5:])):
    lines.append(group_name)
    header = f"{'str':>3} {'sha256[:10]':>12}"
    for m in group:
        header += f" {m[:26]:>28}"
    lines.append(header)
    for h, e in sorted(sequences.items(), key=lambda kv: kv[1]["stratum"]):
        row = f"{e['stratum']:>3} {h[:10]:>12}"
        for m in group:
            d = e["metrics"][m]
            if d["mean"] is None:
                row += f" {'n/a':>28}"
            else:
                sd = d["sd"]
                sd_s = "  n/a" if sd is None else f"{sd:.4f}"
                row += f" {d['mean']:>15.4f} +/- {sd_s:>8}"
        lines.append(row)
    lines.append("")

lines.append("ARCHIVE (validator-published) METRICS OF THE SAME 12, FOR THE STRATIFICATION")
lines.append(f"{'str':>3} {'sha256[:10]':>12} {'rank_sum':>10} {'pctile':>7} " +
             " ".join(f"{m[:14]:>15}" for m in METRICS))
for h, e in sorted(sequences.items(), key=lambda kv: kv[1]["stratum"]):
    lines.append(f"{e['stratum']:>3} {h[:10]:>12} {e['archive_rank_sum']:>10.0f} "
                 f"{e['archive_rank_sum_percentile']:>7.2f} " +
                 " ".join(f"{e['archive_metrics'][m]:>15.4f}" for m in METRICS))
lines.append("")

if problems:
    lines.append("PROBLEMS")
    lines.extend("  " + p for p in problems)
else:
    lines.append("PROBLEMS: none -- every sequence scored in every repeat with all ten metrics present.")

text = "\n".join(lines) + "\n"
(R / "reference_table.txt").write_text(text)
print(text)
