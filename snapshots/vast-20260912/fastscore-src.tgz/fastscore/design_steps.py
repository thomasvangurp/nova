"""How many diffusion steps does the design stage actually need?

The design stage runs 500 sampling steps per sequence (design.yaml) and costs
more than the folding stage that produces the score. A coordinate-perturbation
trace showed the folding stage consumes exactly one thing from the design
output: the TARGET chain's geometry, used as an SE(3)-invariant template. The
designed chain's coordinates reach no module the folding checkpoint contains.

So the fidelity criterion for cutting design steps is not "do the designs look
the same" -- it is "does the target chain's internal geometry survive". The
bar: across four independent 500-step designs the target's CA-CA distance
matrix is reproducible to 0.13 A, and matches the 6O4O crystal to 0.15-0.19 A.
A cheaper setting has to stay in that band.

One model load serves every setting; predict_step reads sampling_steps out of
predict_args at call time.
"""
from __future__ import annotations

import argparse, shutil
from pathlib import Path

from resident import ResidentStage, seed_all


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config", help="a materialized design.yaml")
    ap.add_argument("--steps", default="500,200,100,50,25")
    ap.add_argument("--work-root", required=True)
    ap.add_argument("--seed", type=int, default=31337)
    a = ap.parse_args()

    stage = ResidentStage(a.config)
    print(f"model load: {stage.load_seconds:.1f}s", flush=True)

    root = Path(a.work_root)
    for steps in [int(s) for s in a.steps.split(",")]:
        d = root / f"steps{steps}"
        shutil.rmtree(d, ignore_errors=True)
        d.mkdir(parents=True, exist_ok=True)
        # same seed for every setting: the comparison is step count, not draw
        seed_all(a.seed)
        secs = stage.run_batch({"output": str(d)},
                               predict_args={"sampling_steps": steps})
        n = len(list(d.glob("*.cif")))
        print(f"  steps={steps:4d}: {secs:6.1f}s for {n} designs "
              f"({secs/max(n,1):5.1f}s/design)  -> {d}", flush=True)


if __name__ == "__main__":
    main()
