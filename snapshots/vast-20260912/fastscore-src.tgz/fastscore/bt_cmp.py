"""Per-design scored metrics across several folding runs.

The validator scores ONE diffusion sample per design -- the argmax of
0.8 * design_to_target_iptm + 0.2 * design_ptm (analyze_utils.
get_best_folding_sample) -- so that is what is compared here, not a per-sample
mean. Columns are runs; the first run listed is the reference.

  bt_cmp.py ref_run other_run ...
"""
from __future__ import annotations
import argparse, glob, os
import numpy as np

ROOT = "/root/fastscore/bt"
KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def best(path):
    d = dict(np.load(path, allow_pickle=True))
    conf = 0.8 * np.asarray(d["design_to_target_iptm"], float) \
         + 0.2 * np.asarray(d["design_ptm"], float)
    i = int(np.argmax(conf))
    return {k: float(np.asarray(d[k], float)[i]) for k in KEYS}, i


def load_run(run):
    out = {}
    for f in sorted(glob.glob(os.path.join(ROOT, run, "fold_out_npz", "*.npz"))):
        out[os.path.splitext(os.path.basename(f))[0]] = best(f)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+")
    ap.add_argument("--designs", default=None)
    a = ap.parse_args()

    data = {r: load_run(r) for r in a.runs}
    ref = a.runs[0]
    designs = a.designs.split(",") if a.designs else sorted(
        set().union(*[set(v) for v in data.values()]))

    worst = {k: 0.0 for k in KEYS}
    for name in designs:
        present = [r for r in a.runs if name in data[r]]
        if len(present) < 2:
            continue
        print(f"\n=== design {name} ===")
        hdr = "".join(f"{r:>16s}" for r in present)
        print(f"  {'metric':26s}{hdr}")
        print(f"  {'best sample #':26s}" +
              "".join(f"{data[r][name][1]:>16d}" for r in present))
        for k in KEYS:
            row = "".join(f"{data[r][name][0][k]:16.4f}" for r in present)
            print(f"  {k:26s}{row}")
            if name in data[ref]:
                base = data[ref][name][0][k]
                d = max(abs(data[r][name][0][k] - base) for r in present)
                worst[k] = max(worst[k], d)
                print(f"  {'  max |delta| vs ' + ref:26s}{d:16.4f}")

    print("\n=== worst |delta| vs %s over all designs ===" % ref)
    for k in KEYS:
        print(f"  {k:26s} {worst[k]:10.4f}")


if __name__ == "__main__":
    main()
