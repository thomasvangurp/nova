set -e
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=4
./fast_python.sh bt_run.py bt_b1.yaml --out /root/fastscore/bt/res_main.json --seed 7 --runs \
  warm:A+B+C+D:4 \
  p1_A:A:1 p1_B:B:1 p1_C:C:1 p1_D:D:1 \
  p2_AB:A+B:2 p2_CD:C+D:2 \
  p4_ABCD:A+B+C+D:4 \
  p8_ALL:A+B+C+D+E+F+G+H:8 \
  c_AEFG:A+E+F+G:4 \
  c_ADCB:A+D+C+B:4 \
  p1_A2:A:1 \
  m1_S20:S20:1 m1_S40:S40:1 \
  m3_mixed:A+S20+S40:3 \
  m3_mixed2:S40+A+S20:3
