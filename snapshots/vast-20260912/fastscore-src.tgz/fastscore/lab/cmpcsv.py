"""Compare two aggregate_metrics_analyze.csv files column-by-column, keyed on id.

The liability_* block comes out in a different column ORDER on every run (it is
built from an unordered set), so a byte diff is meaningless; only a keyed
comparison says anything about whether a metric actually changed.
"""
import sys
import pandas as pd
import numpy as np

VALIDATOR_COLS = [
    "design_iiptm", "design_ptm", "design_to_target_iptm",
    "min_design_to_target_pae", "interaction_pae",
    "plip_hbonds_refolded", "plip_saltbridge_refolded", "delta_sasa_refolded",
    "liability_score", "liability_num_violations",
]

a = pd.read_csv(sys.argv[1]).set_index("id").sort_index()
b = pd.read_csv(sys.argv[2]).set_index("id").sort_index()

print(f"A: {a.shape[1]+1} cols, {len(a)} rows   B: {b.shape[1]+1} cols, {len(b)} rows")
assert list(a.index) == list(b.index), "row ids differ"

only_a = [c for c in a.columns if c not in b.columns]
only_b = [c for c in b.columns if c not in a.columns]
print(f"\ncolumns only in A ({len(only_a)}): {only_a}")
print(f"columns only in B ({len(only_b)}): {only_b}")

common = [c for c in a.columns if c in b.columns]
diffs = []
for c in common:
    x, y = a[c], b[c]
    if pd.api.types.is_numeric_dtype(x) and pd.api.types.is_numeric_dtype(y):
        if not np.allclose(x.to_numpy(float), y.to_numpy(float),
                           rtol=0, atol=0, equal_nan=True):
            d = np.nanmax(np.abs(x.to_numpy(float) - y.to_numpy(float)))
            diffs.append((c, d))
    else:
        if not (x.astype(str) == y.astype(str)).all():
            diffs.append((c, "str"))
print(f"\ncommon columns: {len(common)};  differing: {len(diffs)}")
for c, d in diffs:
    print(f"  DIFF {c}: max|delta|={d}")

print("\n=== TEN VALIDATOR COLUMNS ===")
for c in VALIDATOR_COLS:
    if c not in a.columns or c not in b.columns:
        print(f"  {c}: MISSING (A={c in a.columns}, B={c in b.columns})")
        continue
    for i in a.index:
        va, vb = a.loc[i, c], b.loc[i, c]
        same = "OK " if (va == vb or (pd.isna(va) and pd.isna(vb))) else "MISMATCH"
        print(f"  {same} {c:<28} {i[:12]}  A={va!r:<24} B={vb!r}")
