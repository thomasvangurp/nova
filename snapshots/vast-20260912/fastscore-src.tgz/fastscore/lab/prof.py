"""Profile only the per-design metric loop, so import cost does not swamp it."""
import cProfile, pstats, sys, time, io
import omegaconf, hydra

cfg = omegaconf.OmegaConf.load(sys.argv[1])
task = hydra.utils.instantiate(cfg)
task.data.init_dataset(task.design_dir, skip_specific_ids=task.skip_specific_ids)
n = len(task.data.predict_set)
print("designs:", n)

# warm one design so first-call lazies (plip, molecule cache) are not attributed
task.compute_metrics(0)

pr = cProfile.Profile()
pr.enable()
for i in range(n):
    task.compute_metrics(i)
pr.disable()
s = io.StringIO()
pstats.Stats(pr, stream=s).sort_stats("cumulative").print_stats(400)
print(s.getvalue())
