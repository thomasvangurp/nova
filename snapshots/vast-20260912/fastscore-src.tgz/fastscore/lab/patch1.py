import pathlib, sys

base = pathlib.Path("/root/fastscore/bgen_fast/src/boltzgen/task/analyze")

# --- 1. make_histograms only feeds the wandb block ------------------------
p = base / "analyze.py"
s = p.read_text()
old = """        _, histograms = self.make_histograms(all_metrics)

        # Log to Wandb
        if self.wandb is not None and not self.debug:
"""
new = """        # Only the wandb block below reads `histograms`; building it draws ~38
        # matplotlib figures that are never closed, so skip it when wandb is off.
        histograms = {}

        # Log to Wandb
        if self.wandb is not None and not self.debug:
            _, histograms = self.make_histograms(all_metrics)
"""
assert s.count(old) == 1, "histogram anchor not unique"
s = s.replace(old, new)
p.write_text(s)

# --- 2. sklearn is only needed by largest_hydrophobic_patch_area ----------
p = base / "analyze_utils.py"
s = p.read_text()
old = "from sklearn.cluster import DBSCAN\n"
assert s.count(old) == 1, "sklearn import anchor not unique"
s = s.replace(old, "")
old2 = """def largest_hydrophobic_patch_area(cif_path, distance_cutoff=6.0):
    result = compute_sasa(cif_path)
"""
new2 = """def largest_hydrophobic_patch_area(cif_path, distance_cutoff=6.0):
    # Imported here rather than at module scope: sklearn costs ~2.6s of import
    # time in every analyze process, and DBSCAN is reached only from this
    # function, which runs only under largest_hydrophobic[_refolded].
    from sklearn.cluster import DBSCAN

    result = compute_sasa(cif_path)
"""
assert s.count(old2) == 1, "hydrophobic anchor not unique"
s = s.replace(old2, new2)
p.write_text(s)
print("patched")
