import pathlib
p = pathlib.Path("/root/fastscore/bgen_fast/src/boltzgen/data/data.py")
s = p.read_text()

old = '''def numeric_to_string(
    name: Union[Tuple[int, int, int, int], Tuple[int, int, int, int, int]],
) -> str:
    name = [chr(c + 32) for c in name if c != 0]
    name = "".join(name)
    return name
'''
new = '''@lru_cache(maxsize=8192)
def _numeric_to_string(name: Tuple[int, ...]) -> str:
    return "".join([chr(c + 32) for c in name if c != 0])


def numeric_to_string(
    name: Union[Tuple[int, int, int, int], Tuple[int, int, int, int, int]],
) -> str:
    # Called once per atom and once per residue. `name` is normally a torch
    # tensor row, and iterating one element-wise costs more than the whole
    # decode; only a few dozen distinct atom/residue codes ever occur, so
    # normalise to a tuple once and memoise the decode.
    if hasattr(name, "tolist"):
        name = name.tolist()
    return _numeric_to_string(tuple(name))
'''
assert s.count(old) == 1, "numeric_to_string anchor not unique"
s = s.replace(old, new)

if "from functools import lru_cache" not in s:
    # put it next to the other stdlib imports
    lines = s.split("\n")
    for i, ln in enumerate(lines):
        if ln.startswith("import ") or ln.startswith("from "):
            lines.insert(i, "from functools import lru_cache")
            break
    s = "\n".join(lines)
p.write_text(s)
print("patched data.py")
