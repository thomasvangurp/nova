import pathlib
p = pathlib.Path("/root/fastscore/bgen_fast/src/boltzgen/data/parse/mmcif.py")
s = p.read_text()
old = "from sklearn.neighbors import KDTree\n"
assert s.count(old) == 1
s = s.replace(old, "")
old2 = """    # Compute the distance matrix
    tree = KDTree(coords, metric="euclidean")
"""
new2 = """    # Compute the distance matrix
    # Imported here rather than at module scope: sklearn costs ~2.6s to import
    # and this module is pulled in transitively by every analyze process, none
    # of which parse an mmCIF and so none of which reach this function.
    from sklearn.neighbors import KDTree

    tree = KDTree(coords, metric="euclidean")
"""
assert s.count(old2) == 1
s = s.replace(old2, new2)
p.write_text(s)
print("patched mmcif")
