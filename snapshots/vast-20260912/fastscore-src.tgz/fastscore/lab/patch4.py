import pathlib
root = pathlib.Path("/root/fastscore/bgen_fast/src/boltzgen")

p = root / "data/parse/mmcif.py"
s = p.read_text()
old = """    # Imported here rather than at module scope: sklearn costs ~2.6s to import
    # and this module is pulled in transitively by every analyze process, none
    # of which parse an mmCIF and so none of which reach this function.
"""
new = """    # Imported here rather than at module scope: this module is pulled in
    # transitively by every analyze process, none of which parse an mmCIF and so
    # none of which reach this function. Keeps ~170 sklearn modules unloaded.
"""
assert s.count(old) == 1
p.write_text(s.replace(old, new))

p = root / "task/analyze/analyze_utils.py"
s = p.read_text()
old = """    # Imported here rather than at module scope: sklearn costs ~2.6s in every
    # analyze process, and DBSCAN is reached only from this
    # function, which runs only under largest_hydrophobic[_refolded].
"""
old_alt = """    # Imported here rather than at module scope: sklearn costs ~2.6s of import
    # time in every analyze process, and DBSCAN is reached only from this
    # function, which runs only under largest_hydrophobic[_refolded].
"""
new = """    # Imported here rather than at module scope: DBSCAN is reached only from
    # this function, which runs only under largest_hydrophobic[_refolded].
"""
use = old if s.count(old) == 1 else old_alt
assert s.count(use) == 1, s[s.find("Imported here")-200:s.find("Imported here")+400]
p.write_text(s.replace(use, new))
print("comments corrected")
