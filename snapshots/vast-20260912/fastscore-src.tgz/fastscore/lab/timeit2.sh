#!/usr/bin/env bash
# timeit2.sh <runner> <cfg> <design_dir> <tag> <reps>
runner=$1; cfg=$2; ddir=$3; tag=$4; reps=${5:-3}
cd /root/fastscore
for i in $(seq 1 "$reps"); do
  rm -rf "$ddir/metrics_tmp" "$ddir/aggregate_metrics_analyze.csv" \
         "$ddir/per_target_metrics_analyze.csv" "$ddir/ca_coords_sequences.pkl.gz"
  s=$(date +%s%N)
  OMP_NUM_THREADS=4 nice -19 "$runner" bgen_fast/src/boltzgen/resources/main.py "$cfg" \
      > "lab/${tag}_run${i}.log" 2>&1
  rc=$?
  e=$(date +%s%N)
  echo "$tag rep$i rc=$rc wall=$(awk -v a=$s -v b=$e 'BEGIN{printf "%.2f", (b-a)/1e9}')"
  cp "$ddir/aggregate_metrics_analyze.csv" "lab/${tag}_agg_run${i}.csv" 2>/dev/null
done
