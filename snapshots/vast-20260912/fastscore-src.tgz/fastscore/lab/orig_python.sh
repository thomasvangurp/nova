#!/usr/bin/env bash
# Identical to fast_python.sh but points at a pristine checkout of the vendored
# baseline (commit 634652f), so the A/B measures only the analyze-path edits and
# is unaffected by whatever else lands in the shared shadow tree meanwhile.
unset PYTHONPATH
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-4}
export MKL_NUM_THREADS=${MKL_NUM_THREADS:-4}
export OPENBLAS_NUM_THREADS=${OPENBLAS_NUM_THREADS:-4}
export NUMEXPR_NUM_THREADS=${NUMEXPR_NUM_THREADS:-4}
exec /usr/local/bin/pixi run \
  --manifest-path /root/pixi.toml \
  --environment bgen \
  env PYTHONPATH="/root/bgen_shim:/root/fastscore/lab/bgen_orig/src" \
  python "$@"
