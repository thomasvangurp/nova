#!/usr/bin/env bash
# Time N repetitions of an analysis config, wiping metrics_tmp before each rep so
# every rep recomputes all four designs from the same inputs.
cfg=$1; ddir=$2; tag=$3; reps=${4:-3}
cd /root/fastscore
for i in $(seq 1 "$reps"); do
  rm -rf "$ddir/metrics_tmp" "$ddir/aggregate_metrics_analyze.csv" \
         "$ddir/per_target_metrics_analyze.csv" "$ddir/ca_coords_sequences.pkl.gz"
  s=$(date +%s.%N)
  OMP_NUM_THREADS=4 nice -19 ./fast_python.sh bgen_fast/src/boltzgen/resources/main.py "$cfg" \
      > "lab/${tag}_run${i}.log" 2>&1
  rc=$?
  e=$(date +%s.%N)
  echo "$tag rep$i rc=$rc wall=$(awk -v a=$s -v b=$e 'BEGIN{printf "%.2f", b-a}')"
  cp "$ddir/aggregate_metrics_analyze.csv" "lab/${tag}_agg_run${i}.csv"
done
