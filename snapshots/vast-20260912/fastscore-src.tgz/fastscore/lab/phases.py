"""Wall-clock breakdown of the analysis step, phase by phase."""
import time, sys
T0 = time.time()
import omegaconf, hydra
t_imp_cfg = time.time()
import boltzgen.task.analyze.analyze  # noqa: F401  (the expensive one)
t_imp = time.time()

cfg = omegaconf.OmegaConf.load(sys.argv[1])
task = hydra.utils.instantiate(cfg)
t_inst = time.time()

task.data.init_dataset(task.design_dir, skip_specific_ids=task.skip_specific_ids)
n = len(task.data.predict_set)
t_data = time.time()

for i in range(n):
    task.compute_metrics(i)
t_loop = time.time()

task.aggregate_metrics()
t_agg = time.time()

print()
print("PHASES (n=%d designs)" % n)
print("  hydra/omegaconf import : %.2f" % (t_imp_cfg - T0))
print("  boltzgen analyze import: %.2f" % (t_imp - t_imp_cfg))
print("  hydra instantiate      : %.2f" % (t_inst - t_imp))
print("  dataset init           : %.2f" % (t_data - t_inst))
print("  compute_metrics loop   : %.2f  (%.2f/design)" % (t_loop - t_data, (t_loop - t_data) / n))
print("  aggregate_metrics      : %.2f" % (t_agg - t_loop))
print("  TOTAL in-process       : %.2f" % (t_agg - T0))
