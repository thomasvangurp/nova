set -e
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=4
# Why batching does or does not pay: the diffusion sampler already runs at
# multiplicity = diffusion_samples, so the tensors it launches are already
# batched 5x before any design batching. If the per-SAMPLE cost is flat from 1
# to 5, the sampler is latency-bound and design batching should have helped; if
# it is linear, the GPU is already saturated and there is nothing left to win.
./fast_python.sh bt_run.py bt_b1.yaml --out /root/fastscore/bt/res_mult.json --seed 7 \
  --sampling-steps 200 --diffusion-samples 1 --runs w:A:1 m1_1:A+B+C+D:1 m1_2:A+B+C+D:1
./fast_python.sh bt_run.py bt_b1.yaml --out /root/fastscore/bt/res_mult5.json --seed 7 \
  --sampling-steps 200 --diffusion-samples 5 --runs w:A:1 m5_1:A+B+C+D:1 m5_2:A+B+C+D:1
# and: does design batching help when multiplicity is 1 (small tensors)?
./fast_python.sh bt_run.py bt_b1.yaml --out /root/fastscore/bt/res_mult1b.json --seed 7 \
  --sampling-steps 200 --diffusion-samples 1 --runs w:A:1 n1_b1:A+B+C+D:1 n1_b4:A+B+C+D:4 n1_b1b:A+B+C+D:1 n1_b4b:A+B+C+D:4
