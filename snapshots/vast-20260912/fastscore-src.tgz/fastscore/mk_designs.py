"""Extra design inputs for the batching tests.

  E,F,G,H  -- same token count as the reference, different designed sequence
              (via synth_design.retarget, backbone mode).  Needed to reach a
              batch of 8 and to give a design a *different* set of batch-mates.
  S20,S40  -- the designed chain truncated by 20 / 40 residues, so the batch
              has genuinely different token counts and the collator has to pad
              the token axis.  ss_type / binding_type in the metadata npz are
              per-token, so they are truncated by the same amount (they are all
              zero here, but the featurizer reads their length).
"""
from __future__ import annotations
import sys, shutil
from pathlib import Path
import numpy as np

sys.path.insert(0, "/root/fastscore")
from synth_design import retarget

POOL = Path("/root/fastscore/bt/pool")
REF_CIF, REF_NPZ = POOL / "A.cif", POOL / "A.npz"
SEQ = ("DVQLVESGGGLVQPGGSLRLSCAASGFTLASGYYAMGWFRQAPGKQRELVVVISSSGSPFIYY"
       "PDSVKGRFTISRDNAKNSIYLQMNSLRAEDTAVYYCAVSLGTMPIPQTGYWYSWGQGTQITVSA")


def mutate(seq: str, rng) -> str:
    aa = "ACDEFGHIKLMNPQRSTVWY"
    s = list(seq)
    # mutate the CDR-ish middle third; keep the framework so the input stays a
    # plausible nanobody rather than a random coil
    for i in rng.choice(np.arange(30, 110), size=14, replace=False):
        s[i] = aa[rng.integers(len(aa))]
    return "".join(s)


def truncate(k: int, out: Path) -> None:
    """Drop the last k residues of the designed chain (asym B)."""
    lines = REF_CIF.read_text().splitlines()
    cols = [l.strip().split(".", 1)[1] for l in lines if l.strip().startswith("_atom_site.")]
    idx = {n: i for i, n in enumerate(cols)}
    c_asym, c_seq, c_id = idx["label_asym_id"], idx["label_seq_id"], idx["id"]

    seq_ids = []
    for l in lines:
        if l.startswith(("ATOM", "HETATM")):
            f = l.split()
            if f[c_asym] == "B" and f[c_seq] not in seq_ids:
                seq_ids.append(f[c_seq])
    keep = set(seq_ids[: len(seq_ids) - k])
    new_seq = SEQ[: len(SEQ) - k]

    out_lines, serial = [], 0
    for l in lines:
        if not l.startswith(("ATOM", "HETATM")):
            out_lines.append(l)
            continue
        f = l.split()
        if f[c_asym] == "B" and f[c_seq] not in keep:
            continue
        serial += 1
        f[c_id] = str(serial)
        out_lines.append(" ".join(f))
    text = "\n".join(out_lines)
    text = text.replace(f"2 polypeptide(L) ? {SEQ}", f"2 polypeptide(L) ? {new_seq}")
    # _entity_poly_seq rows for the dropped residues of entity 2
    dropped = {sid for sid in seq_ids if sid not in keep}
    text = "\n".join(
        l for l in text.splitlines()
        if not (l.startswith("2 ") and len(l.split()) == 4 and l.split()[1] in dropped)
    )
    out.with_suffix(".cif").write_text(text + "\n")

    meta = dict(np.load(REF_NPZ, allow_pickle=True))
    for key in ("design_mask", "mol_type", "ss_type", "token_resolved_mask", "binding_type"):
        meta[key] = meta[key][: len(meta[key]) - k]
    np.savez(out.with_suffix(".npz"), **meta)
    print(f"{out.name}: dropped {k} designed residues -> {len(new_seq)} aa chain")


def fix_entity_poly_seq(path: Path, seq: str) -> None:
    """retarget() rewrites the ATOM records and the one-letter code but not the
    _entity_poly_seq table; parse_polymer asserts the two agree."""
    from synth_design import ONE_TO_THREE
    three = [ONE_TO_THREE[c] for c in seq]
    out, pos = [], 0
    for line in path.read_text().splitlines():
        f = line.split()
        if len(f) == 4 and f[0] == "2" and f[3] == "?" and f[1].isdigit():
            f[2] = three[pos]
            pos += 1
            out.append(" ".join(f))
        else:
            out.append(line)
    assert pos == len(seq), f"{path}: {pos} entity_poly_seq rows for {len(seq)} residues"
    path.write_text("\n".join(out) + "\n")


rng = np.random.default_rng(12345)
for name in "EFGH":
    seq = mutate(SEQ, rng)
    retarget(REF_CIF, seq, POOL / f"{name}.cif", mode="backbone")
    fix_entity_poly_seq(POOL / f"{name}.cif", seq)
    shutil.copyfile(REF_NPZ, POOL / f"{name}.npz")
    print(f"{name}: retargeted")
truncate(20, POOL / "S20")
truncate(40, POOL / "S40")
