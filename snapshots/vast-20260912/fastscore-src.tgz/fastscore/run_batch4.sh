#!/usr/bin/env bash
# Does folding more than one design per forward pay?
#
# The sampler is latency-bound at these sizes (295 tokens, 2272 atoms): the
# GPU sits at ~85% and the profile is dominated by many small GEMMs. If that
# is right, folding 4 designs in one batch should cost well under 4x one
# design. data.cfg.batch_size is 1 in production.
cd /root/fastscore
rm -f batch4.done
export CUDA_VISIBLE_DEVICES=2

./fast_python.sh profile_fold.py fold_B1.yaml --seed 909 > run_B1.log 2>&1
./fast_python.sh profile_fold.py fold_B4.yaml --seed 909 > run_B4.log 2>&1

touch batch4.done
