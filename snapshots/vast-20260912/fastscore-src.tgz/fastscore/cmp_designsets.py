"""Compare scores from two design-stage settings, per design, over repeats.

A single paired comparison proves nothing here: the scorer is not reproducible
even at a fixed seed (design_iiptm floor 0.0048) and the seed-to-seed spread is
an order of magnitude larger (0.353 vs 0.311). So each design is folded N times
under each setting and the DISTRIBUTIONS are compared.

The failure mode to watch for is not a large difference on one design -- it is a
CONSISTENT SAME-SIGN difference across all designs. That is a bias, and a bias
survives averaging no matter how many repeats the selector buys.
"""
from __future__ import annotations
import argparse, json
from collections import defaultdict

import numpy as np

KEYS = ["design_iiptm", "design_ptm", "design_to_target_iptm",
        "min_design_to_target_pae", "interaction_pae"]


def group(path):
    out = defaultdict(lambda: defaultdict(list))
    for r in json.load(open(path)):
        for k in KEYS:
            out[r["design"]][k].append(r[k])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("a"); ap.add_argument("b")
    ap.add_argument("--label-a", default="A"); ap.add_argument("--label-b", default="B")
    args = ap.parse_args()

    A, B = group(args.a), group(args.b)
    designs = sorted(set(A) & set(B))
    print(f"{len(designs)} designs, "
          f"{len(next(iter(A.values()))[KEYS[0]])} repeats each\n")

    for key in KEYS:
        print(f"--- {key} ---")
        print(f"{'design':14s} {args.label_a+' mean+-sd':>20s} "
              f"{args.label_b+' mean+-sd':>20s} {'diff':>9s} {'diff/sd':>8s}")
        diffs, norm = [], []
        for d in designs:
            va, vb = np.array(A[d][key]), np.array(B[d][key])
            sa = va.std(ddof=1) if len(va) > 1 else np.nan
            sb = vb.std(ddof=1) if len(vb) > 1 else np.nan
            pooled = np.sqrt((sa**2 + sb**2) / 2)
            diff = vb.mean() - va.mean()
            diffs.append(diff)
            norm.append(diff / pooled if pooled else np.nan)
            print(f"{d[:14]:14s} {va.mean():11.4f}+-{sa:7.4f} "
                  f"{vb.mean():11.4f}+-{sb:7.4f} {diff:+9.4f} {norm[-1]:+8.2f}")
        signs = np.sign(diffs)
        same = abs(signs.sum()) == len(signs)
        print(f"{'':14s} mean diff {np.mean(diffs):+.4f}   "
              f"all same sign: {'YES  <-- possible bias' if same else 'no'}   "
              f"mean |diff|/sd {np.nanmean(np.abs(norm)):.2f}\n")


if __name__ == "__main__":
    main()
