#!/usr/bin/env bash
# Same runtime as bgen_python.sh but with the SHADOW boltzgen tree first on
# PYTHONPATH, so an A/B needs no edit to the live vendored source.
# Thread caps are explicit: the live box runs ~43 torch processes with no
# OMP limit, which is how a 128-core machine reaches load 299.
unset PYTHONPATH
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-4}
export MKL_NUM_THREADS=${MKL_NUM_THREADS:-4}
export OPENBLAS_NUM_THREADS=${OPENBLAS_NUM_THREADS:-4}
export NUMEXPR_NUM_THREADS=${NUMEXPR_NUM_THREADS:-4}
exec /usr/local/bin/pixi run \
  --manifest-path /root/pixi.toml \
  --environment bgen \
  env PYTHONPATH="/root/bgen_shim:/root/fastscore/bgen_fast/src" \
  python "$@"
