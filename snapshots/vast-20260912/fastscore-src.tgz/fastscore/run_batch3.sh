#!/usr/bin/env bash
# Serial variant runs on one GPU. Serial is deliberate: two of these sharing a
# GPU makes every per-step timing meaningless, and the box is live-mining.
cd /root/fastscore
rm -f batch3.done
export CUDA_VISIBLE_DEVICES=2

# hoist A/B: identical seed, identical config, patch toggled by env var.
# These two must agree to the last bit or the patch is not what it claims.
BOLTZGEN_NO_HOIST=1 ./fast_python.sh profile_fold.py fold_H0.yaml --seed 777 > run_H0.log 2>&1
                    ./fast_python.sh profile_fold.py fold_H1.yaml --seed 777 > run_H1.log 2>&1

# design-bypass: folding a SYNTHESIZED design output (chain A copied, chain B
# backbone-only with the same sequence) against the real one at the same seed.
BOLTZGEN_NO_HOIST=1 ./fast_python.sh profile_fold.py fold_S.yaml --seed 4242 > run_S.log 2>&1

touch batch3.done
