set -e
cd /root/fastscore
export CUDA_VISIBLE_DEVICES=4
# Same 8 designs at every batch size, cycles interleaved so the GPU clock ramp
# and whatever the live run is doing to the box average out instead of landing
# on whichever batch size happened to go first.
S=A+B+C+D+E+F+G+H
./fast_python.sh bt_run.py bt_b1.yaml --out /root/fastscore/bt/res_time.json --seed 7 --runs \
  warm:$S:4 \
  t1_1:$S:1 t2_1:$S:2 t4_1:$S:4 t8_1:$S:8 \
  t1_2:$S:1 t2_2:$S:2 t4_2:$S:4 t8_2:$S:8 \
  t1_3:$S:1 t2_3:$S:2 t4_3:$S:4 t8_3:$S:8
